INSERT INTO public.ma_tipos_baixa (codigo,nome) VALUES
	 ('1','Voluntaria'),
	 ('2','Incumprimento'),
	 ('3','Inserción'),
	 ('4','Outros'),
	 ('6','Ilocalizable'),
	 ('7','Falecemento'),
	 ('8','Non acude a cita do SPE');