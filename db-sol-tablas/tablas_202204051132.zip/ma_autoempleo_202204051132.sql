INSERT INTO public.ma_autoempleo (codigo,nome) VALUES
	 ('01','NO'),
	 ('02','Sí con Asesoramiento'),
	 ('03','Sí con Formación'),
	 ('04','Si Asesoramiento y Formación'),
	 ('05','Desconocido'),
	 ('06','SI');