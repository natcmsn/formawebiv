INSERT INTO public.userfinal_actividad (actividad_id,userfinal_id,fechareserva,pagado) VALUES
	 (8,1,'2011-03-13 17:09:06.578',false),
	 (10,1,'2011-03-13 17:25:56.453',false),
	 (1,12,'2011-03-13 20:11:59.812',false),
	 (9,12,'2011-03-13 20:12:59',false),
	 (11,12,'2011-03-13 20:13:17.687',false),
	 (8,12,'2011-03-13 20:14:00.171',false),
	 (3,1,'2011-03-14 17:26:02.187',false),
	 (3,8,'2011-03-14 17:26:13.968',false),
	 (3,11,'2011-03-14 17:26:18.625',false),
	 (3,9,'2011-03-14 17:26:35.734',false);
INSERT INTO public.userfinal_actividad (actividad_id,userfinal_id,fechareserva,pagado) VALUES
	 (1,8,'2011-02-27 21:56:11.187',true),
	 (1,10,'2011-03-02 21:59:46.843',true),
	 (1,1,'2011-04-03 14:25:30.64',false);