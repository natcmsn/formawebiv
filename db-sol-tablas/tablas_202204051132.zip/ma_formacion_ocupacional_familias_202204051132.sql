INSERT INTO public.ma_formacion_ocupacional_familias (nome) VALUES
	 ('Agraria'),
	 ('Marítimo-pesquero'),
	 ('Industrias alimentarias'),
	 ('Química'),
	 ('Imaxen persoal'),
	 ('Sanidade'),
	 ('Seguridade e medio ambiente'),
	 ('Fabricación mecánica'),
	 ('Instalación e mantemento'),
	 ('Electricidade e electrónica');
INSERT INTO public.ma_formacion_ocupacional_familias (nome) VALUES
	 ('Enerxía e auga'),
	 ('Transporte e mantemento de vehículos'),
	 ('Industrias extractivas'),
	 ('Edificación e obra civil'),
	 ('Vidro e cerámica'),
	 ('Madeira, moble e cortizo'),
	 ('Textil, confección e pel'),
	 ('Artes gráficas'),
	 ('Imaxe e son'),
	 ('Informática e comunicacións');
INSERT INTO public.ma_formacion_ocupacional_familias (nome) VALUES
	 ('Administración e xestión'),
	 ('Comercio e Marketing'),
	 ('Servizos socioculturais e a comunidade'),
	 ('Hostelaría e turismo'),
	 ('Actividades físicas e deportivas'),
	 ('Artesanías');