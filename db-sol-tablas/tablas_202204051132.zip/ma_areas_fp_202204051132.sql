INSERT INTO public.ma_areas_fp (codigo,nome) VALUES
	 ('1','FP I'),
	 ('2','FP II'),
	 ('3','Ciclo Medio'),
	 ('6','FP Continua'),
	 ('7','FP Ocupacional'),
	 ('4','Ciclo Superior'),
	 ('5','Módulo');