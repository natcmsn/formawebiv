INSERT INTO public.roles (code) VALUES
	 ('ROLE_ADMIN'),
	 ('ROLE_USER_AVZDO');