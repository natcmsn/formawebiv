INSERT INTO public.ma_centros (codigo,direccion,nome,poblacion,telefono1,telefono2,idconcello) VALUES
	 ('10        ','Edificio Concello','Concello, 4º andar                                ','Vigo','986810232      ','               ',15),
	 ('01        ','-','Rivera Atienza (CERA)','Vigo','986266320      ','               ',15),
	 ('02        ','-','BIAL','Vigo','986263068      ','               ',15),
	 ('03        ','-','E.O. Mar de Vigo','Vigo','986462090      ','               ',15),
	 ('14        ','Rúa San Vicente nº 3 (esquina Méndez Núñez)','CITIC                                             ','','986442113      ','986442114      ',15),
	 ('15        ','Monte da Madroa','Obradoiro Escola Vigozoo','Vigo','986267783      ','               ',0),
	 ('16        ','Parque Central Sta. Cristina','UTIL','Vigo','986263068      ','               ',0),
	 ('17        ','CITIC','Vigo Empega                                       ','Vigo','986442113      ','               ',15),
	 ('18        ','Oporto, 1 - 2º','Centro Local de Emprego                           ','Vigo','986447400      ','               ',15),
	 ('          ','Valadares','O.E. Vigo Atende','','               ','               ',0);
INSERT INTO public.ma_centros (codigo,direccion,nome,poblacion,telefono1,telefono2,idconcello) VALUES
	 ('18','Parque Central de Servizos do Concello','Vigo Emprega 2013','Vigo','986263068','986263068',41),
	 ('19','Centro Local de Emprego - C/ Oporto 1, 2º','VIGO INTEGRA','Vigo','986447400','986447400',41),
	 ('Capacita1','Camiño do Pedregal, 6','O.E. Vigo Capacita I','Vigo','986800232','986810162',15),
	 ('Capacita2','Camiño do Pedregal, 6','O.E. Vigo Capacita II','Vigo','986810132','986810162',15),
	 ('30','Parque Central de Lavadores','Vigo Emprega - Pq. Central','Vigo','986263068','986810232',15);