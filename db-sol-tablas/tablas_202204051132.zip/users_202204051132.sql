INSERT INTO public.users (login,"name",passwd,bloqueado,borrado,passwdchanged) VALUES
	 ('admin','ADMINISTRADOR','pKiMCHK/ZSu57YA+zl/W6CNUg4qb9Zq0ursdqzIhVOE=',false,false,NULL),
	 ('user','USUARIO','pXADh6C2TwD/X+KO4i6wiML2hKetlkXSMb2sdrlFbH8=',false,false,'2011-04-04'),
	 ('user23','rrr444','SzncrhAmY4akXYcI5cragHKCtCIw7NWdZ3imCJQt/II=',false,true,NULL),
	 ('user2','55555','9J/XyY4CPcrtxlViujVuHrOWLmcaQaGeq4R7w+6uvCU=',false,false,NULL);