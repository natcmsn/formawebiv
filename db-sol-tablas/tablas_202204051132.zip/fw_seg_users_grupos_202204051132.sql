INSERT INTO public.fw_seg_users_grupos (user_id,grupo_id) VALUES
	 (139,1),
	 (81,6),
	 (86,6),
	 (133,6),
	 (88,6),
	 (134,6),
	 (90,6),
	 (135,6),
	 (93,6),
	 (96,6);
INSERT INTO public.fw_seg_users_grupos (user_id,grupo_id) VALUES
	 (140,6),
	 (141,6),
	 (144,6),
	 (145,6),
	 (146,6),
	 (147,6),
	 (148,6),
	 (149,6),
	 (150,6),
	 (122,6);
INSERT INTO public.fw_seg_users_grupos (user_id,grupo_id) VALUES
	 (125,6),
	 (127,6),
	 (129,6),
	 (137,1),
	 (136,6),
	 (142,1),
	 (152,3),
	 (143,6),
	 (151,1),
	 (153,6);
INSERT INTO public.fw_seg_users_grupos (user_id,grupo_id) VALUES
	 (154,6),
	 (155,3),
	 (156,5),
	 (157,4),
	 (158,1),
	 (159,6);