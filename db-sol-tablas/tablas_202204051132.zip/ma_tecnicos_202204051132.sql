INSERT INTO public.ma_tecnicos (codigo,nome) VALUES
	 ('01','ALBERTE');