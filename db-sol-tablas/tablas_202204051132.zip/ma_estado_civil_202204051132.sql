INSERT INTO public.ma_estado_civil (codigo,nome) VALUES
	 ('1','SOLTEIRO/A'),
	 ('2','CASADO/A'),
	 ('3','SEPARADO/A'),
	 ('4','DIVORCIADO/A'),
	 ('5','VIUVO/A'),
	 ('6','PARELLA DE FEITO');