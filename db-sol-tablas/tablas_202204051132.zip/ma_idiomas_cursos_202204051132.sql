INSERT INTO public.ma_idiomas_cursos (nome) VALUES
	 ('Escola Idiomas Nivel 1'),
	 ('Escola Idiomas Nivel 2'),
	 ('Escola Idiomas Nivel 3'),
	 ('Escola Idiomas Nivel 4'),
	 ('Escola Idiomas Nivel 5'),
	 ('Escola Idiomas Nivel 6'),
	 ('No estranxeiro'),
	 ('No definido');