INSERT INTO public.actividad (codigo,coste,costeasoc,datafin,datainicio,description,"name",nummatriculadostotal,nummatriculadosweb,needssanitario,programa_id) VALUES
	 ('',0.0,false,'2011-03-27 00:00:00',NULL,'','Actividad 4',0,0,false,1),
	 ('',0.0,false,'2011-03-27 00:00:00',NULL,'','Actividad 5',0,0,false,1),
	 ('',0.0,false,'2011-03-27 00:00:00',NULL,'','Actividad 6',0,0,false,1),
	 ('',0.0,false,'2011-03-31 23:00:00',NULL,'','Actividad 3',0,0,true,1),
	 ('00001',0.0,true,'2011-04-16 17:30:00','2011-06-01 10:30:00','','Actividad 1',2,0,false,3),
	 ('00002',0.55,true,'2011-04-13 17:15:00','2011-04-03 15:30:00','','Actividad 2',2,0,false,3);