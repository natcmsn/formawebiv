INSERT INTO public.ma_idiomas (codigo,nome) VALUES
	 ('1','Galego'),
	 ('2','Inglés'),
	 ('3','Francés'),
	 ('4','Alemán'),
	 ('5','Árabe'),
	 ('6','Xaponés'),
	 ('7','Italiano'),
	 ('8','Portugués'),
	 ('9','Outros'),
	 ('10','Lingua de Signos');
INSERT INTO public.ma_idiomas (codigo,nome) VALUES
	 ('11','Ruso'),
	 ('12','Ucraniano'),
	 ('13','Holandés'),
	 ('14','Grego'),
	 ('15','Búlgaro'),
	 ('16','Catalán'),
	 ('17','Checo'),
	 ('18','Finlandés'),
	 ('19','Estonio'),
	 ('20','Rumano');
INSERT INTO public.ma_idiomas (codigo,nome) VALUES
	 ('','');