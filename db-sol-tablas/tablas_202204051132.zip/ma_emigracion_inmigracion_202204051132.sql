INSERT INTO public.ma_emigracion_inmigracion (nome) VALUES
	 ('Inmigrante'),
	 ('Emigrante Retornado');