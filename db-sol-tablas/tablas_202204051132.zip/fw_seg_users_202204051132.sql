INSERT INTO public.fw_seg_users (bloqueado,borrado,login,passwd,passwdchanged,datospersoais_id) VALUES
	 (false,false,'axenda','92e2f50fffeea1d6897e685c034123b9',NULL,86),
	 (false,true,'mila.calvino','f562f7f28a039094f7b602c033f106a4',NULL,133),
	 (false,false,'ismael.bernardez','1MQqD61p4mqTSqaWJTTe8zJUBu3KAxwPdeWjaQbN1EI=','2021-12-03',153),
	 (false,true,'chelo.iglesias','f5cfa90df50ae37ab7008dbcb229cbd5',NULL,90),
	 (false,true,'mila.calvino','2a00a17658e6e6fe1a10b8e1c21eb123',NULL,135),
	 (false,false,'maria.nieves','+48rvE3Cw+06IskF2VEcE1WCeVx+4I4QZhdbIlVUUmY=','2021-12-03',154),
	 (false,true,'ricardo.veiga','02afd1cf5f39bd4596d14b0c33a46cf9',NULL,96),
	 (false,false,'admin','pKiMCHK/ZSu57YA+zl/W6CNUg4qb9Zq0ursdqzIhVOE=','2021-09-14',139),
	 (false,true,'montse.soto','0609154fa35b3194026346c9cac2a248',NULL,144),
	 (false,true,'silvana.martinez','33b53de2ab34a52076a2de7cbc666df4',NULL,145);
INSERT INTO public.fw_seg_users (bloqueado,borrado,login,passwd,passwdchanged,datospersoais_id) VALUES
	 (false,true,'ana.castro','fc5901929e1b20384faa81f77a09970a',NULL,146),
	 (false,true,'andrea.casabella','8a7ea291e472486d4ebaa31492bf2775',NULL,147),
	 (false,false,'jlrivas','pKiMCHK/ZSu57YA+zl/W6CNUg4qb9Zq0ursdqzIhVOE=','2021-09-14',151),
	 (false,true,'belen.pineiro','bb071ef20fd87f494bc7c69fd95895f9',NULL,122),
	 (true,false,'tatiana.nunez','j82xo0dIZKMVP4QuWAGffqqShWU8/3HFzvmv1JA7FFs=','2017-08-24',136),
	 (false,false,'elisa.casal','82j7prS8IuM4t6rVjmOU9J1oN2f/anNENhQme4DDTAU=','2022-02-07',93),
	 (false,false,'celia.monasterio','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-09',143),
	 (false,false,'rosa.otero','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-15',155),
	 (false,true,'prueba','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-15',157),
	 (false,true,'empleo','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-15',156);
INSERT INTO public.fw_seg_users (bloqueado,borrado,login,passwd,passwdchanged,datospersoais_id) VALUES
	 (true,false,'paco.orue','SmryJNfOo99mXBXIE3DdiI/3iRddGOYwkx7kW6RBBtU=','2019-03-11',137),
	 (false,true,'super','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-15',158),
	 (false,false,'migra','JECaNjYTXGyTdURSRkDVwmR8PU8m53ft1gJf8hfl/e0=','2022-02-15',159),
	 (true,false,'sonia.martinez','7e4b64eb65e34fdfad79e623c44abd94',NULL,129),
	 (true,false,'sonia.ricart','02b442aec1018958715d784848343f09',NULL,150),
	 (true,false,'blanca.dominguez','zlvAqVW4iFuC5cy8AgRvkU8DLlrV8dtX1aazEdAzkas=','2018-04-20',152),
	 (true,false,'carmen.mouriño','a673d3cefbc2941fd682f1ac8e92e106',NULL,149),
	 (true,false,'susana.glez','dac482cc931c16c4df60c0affcd0898d',NULL,125),
	 (true,false,'alen','2e7f877d6c32bfe4bef6c8814ca36a30',NULL,81),
	 (false,false,'eva.garcia','XdZuMHVZGiKSwIxtbOwCeCruAvSggf0wBL0oIMCApiE=','2021-09-21',88);
INSERT INTO public.fw_seg_users (bloqueado,borrado,login,passwd,passwdchanged,datospersoais_id) VALUES
	 (false,false,'gloria.perez','MkQ1T3SFg/sU72b2T7h54X2lI0FRW0jvT2cVsFIg7N4=','2021-09-21',140),
	 (false,false,'maika.cores','TknoAgq3msxkX9q+ber/t4d8U6n4MjEpGCRDRcB8GXM=','2021-09-21',134),
	 (false,false,'alberte.cea','CMVKZhjxvXcgvT5NbOkdEn0WuRkHY6icEW/uSCRSANs=','2021-10-08',148),
	 (true,false,'sandra.sousa','VR8DXpUHmg4v7VJyn9rlEMm92HbetJPQqpuq5LFusdE=','2019-12-17',127),
	 (true,false,'ana.mouriz','acd21nvEZDl/885vsCxzhiZpJdkiQzHPTDoqBjbB1jU=','2019-12-19',142),
	 (false,false,'carlos.juncal','Ia5GBdN44XQf1L8wy83JWbDkVNU47Q/ZHcfC8C2ZMrY=','2021-03-18',141);