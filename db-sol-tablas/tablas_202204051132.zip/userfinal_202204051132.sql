INSERT INTO public.userfinal (apelido1,apelido2,codpostal,datanacemento,email,enderezo,envioinfo_permiso,estadoprofesional,estudiosactuais,localidade,lopd_datossanitarios,lopd_permiso,nif,nivelformativo,nome,ocupacion,outrosestudios,tfnofixo,tfnomovil,sanitario_id) VALUES
	 ('FLORESCU','7','11','1980-03-15','','',false,1,'','Bertamirans',true,true,'X7523864N','','MIRELA','','','','',10),
	 ('Dominguez','gro','','1977-09-09','','',false,0,'','Bertamirans',true,true,'22222222222','','qqqqqq','ppp','','','',8),
	 ('DOMINGUEZ','GROBA','','1977-09-06','agroba@gmail.com','',false,1,'','Bertamirans',true,true,'44814439C','','ANTONIO','','','981999999','616534018',NULL),
	 ('Dominguez','Groba','15220','1977-10-26','antonio.dominguez@aminet.es','rua Xesteira 23, Bajo B',true,2,'','Bertamirans',true,true,'12345678A','','Antonio','','','981999999','616534018',1),
	 ('groba','rodriguez','','1947-09-09','','',false,0,'','vigo',true,true,'35839778M','','consuelo','','','','',11),
	 ('RIVAS','','','1975-03-26','','',true,0,'','VIGO',true,true,'36132157P','','JOSE LUIS','','','','',12);