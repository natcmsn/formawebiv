INSERT INTO public.programa (description,"name") VALUES
	 ('','Programa 2'),
	 ('Todos los programas de 2011 verano','Programa de Verano 2011');