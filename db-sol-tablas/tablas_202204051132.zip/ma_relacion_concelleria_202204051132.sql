INSERT INTO public.ma_relacion_concelleria (nome) VALUES
	 ('Formación'),
	 ('Axudas á contratación'),
	 ('Oferta de emprego'),
	 ('Solicitude información'),
	 ('Mailing'),
	 ('Proveedor'),
	 ('Prospección'),
	 ('Concesionaria'),
	 ('Asesoramiento SAE'),
	 ('Prácticas');
INSERT INTO public.ma_relacion_concelleria (nome) VALUES
	 ('Desconocida');