INSERT INTO public.fw_seg_grupos (descricion,nome) VALUES
	 ('Descrip grupo superAdministrador','SuperAdministrador'),
	 ('Descrip grupo Administrador','Administrador'),
	 ('Descrip grupo Entrevistador','Entrevistador'),
	 ('Descrip grupo Planificador','Planificador'),
	 ('Descrip grupo Informes','Informes'),
	 ('Descrip grupo UserMigracion','UserMigracion');