INSERT INTO public.ma_vinculacions_laborais (nome) VALUES
	 ('Sen contrato'),
	 ('Tempo parcial'),
	 ('Tempo completo'),
	 ('Bolseiro'),
	 ('Prácticas'),
	 ('Autónomo'),
	 ('No país de orixe'),
	 ('No estranxeiro');