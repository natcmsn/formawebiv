INSERT INTO public.ma_disponibilidade_horaria (codigo,nome) VALUES
	 ('01','Mañás'),
	 ('02','Tardes'),
	 ('03','Noites'),
	 ('04','Fins de semana');