INSERT INTO public.ma_disponibilidade_xeografica (codigo,nome) VALUES
	 ('01','Local'),
	 ('02','Provincial'),
	 ('03','Autonómica'),
	 ('04','Estatal'),
	 ('05','Internacional'),
	 ('06','Desconocida');