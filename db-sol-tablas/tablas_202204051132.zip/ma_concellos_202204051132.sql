INSERT INTO public.ma_concellos (codigo,nome) VALUES
	 ('null','Desconocido'),
	 ('12','Vigo'),
	 ('08','Mos'),
	 ('09','Nigrán'),
	 ('10','Gondomar'),
	 ('11','Baiona'),
	 ('13','Pontevedra'),
	 ('null','Porriño'),
	 ('null','Redondela'),
	 ('null','Moaña');
INSERT INTO public.ma_concellos (codigo,nome) VALUES
	 ('null','Cangas'),
	 ('null','Chapela'),
	 ('null','Bueu'),
	 ('null','Vilaboa'),
	 ('null','Ponteareas'),
	 ('null','Pazos De Borbén'),
	 ('null','Salvaterra De Miño'),
	 ('null','Meira'),
	 ('null','Tui'),
	 ('null','Tomiño');
INSERT INTO public.ma_concellos (codigo,nome) VALUES
	 ('null','Huesca'),
	 ('null','A Guarda'),
	 ('null','Cambados'),
	 ('null','O Carballiño'),
	 ('null','As Neves'),
	 ('null','A Coruña'),
	 ('null','Ferrol'),
	 ('null','Monforte'),
	 ('null','Pontecesures'),
	 ('null','Caldelas De Tui');
INSERT INTO public.ma_concellos (codigo,nome) VALUES
	 ('null','Dozón'),
	 ('null','Arcade'),
	 ('null','Goian'),
	 ('null','Salceda De Caselas'),
	 ('null','Os Anxeles - Brión'),
	 ('null','Alcabre'),
	 ('null','Matamá'),
	 ('null','Valladares'),
	 ('null','Cabral'),
	 ('null','San Miguel De Oia');
INSERT INTO public.ma_concellos (codigo,nome) VALUES
	 ('null','Beade'),
	 ('null','Moledo'),
	 ('null','Bembrive'),
	 ('null','Saians'),
	 ('null','Carril - Vilagarcía Arousa');