INSERT INTO public.ma_tipos_derivacion (codigo,nome) VALUES
	 ('1','TLES CONCELLOS'),
	 ('2','COMITÉ PARTICIPACIÓN'),
	 ('3','PLAN INCLUSIÓN'),
	 ('4','UNIVERSIDADE'),
	 ('5','PLAN MUNICIPAL DE EMPREGO VIGO'),
	 ('6','LABORA'),
	 ('7','ESCOLAS OBRADOIRO/OBRADOIROS EMPREGO'),
	 ('8','PROGRAMAS DE COOPERACIÓN'),
	 ('9','OUTROS'),
	 ('11','Desconocida');
INSERT INTO public.ma_tipos_derivacion (codigo,nome) VALUES
	 ('12','Clube de Emprego'),
	 ('13','Grupos Busca'),
	 ('15','Habilidades Sociais'),
	 ('16','Formación'),
	 ('17','Emprego'),
	 ('18','Cursos con compromiso de contratación'),
	 ('19','Datos remitidos ó SPE para cita de orientación'),
	 ('20','Web 2.0'),
	 ('21','Networking'),
	 ('14','Tbe');
INSERT INTO public.ma_tipos_derivacion (codigo,nome) VALUES
	 ('10','NON DERIVACIÓN');