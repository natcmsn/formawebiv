INSERT INTO public.userfinal_userfinal (userfinal_id,tutorizados_id) VALUES
	 (10,9),
	 (10,11),
	 (10,1);