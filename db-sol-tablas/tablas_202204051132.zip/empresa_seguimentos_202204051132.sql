INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Luis Prados Anaya','2006-05-19','Prospección.','Enteramonos do novo xefe de dpto de selección e formación por unha reunión que temos na Concellaría por tema de Seguros El Corte Inglés. Ampliar datos nesta empresa',20),
	 ('Cecilia Mariño','2003-10-06','Prospección','é a nova responsable de RRHH e veu a entrevista con motivo do curso de Laminador de Poliester para informarse sobre os seus contidos, conocer donde se imparte, ...             ',21),
	 ('Esther Sánchez','2003-02-25','Prospección','O máis frecuente e que tanto no taller como en administración se manteña a plantilla fixa (e persoal con antiguedade na empresa). Nas pontas de traballo solen recurrir a unha empresa auxiliar (Bastos en Chapela). Recolle a información para presentarlla o seu xefe.          ',236),
	 ('Almudena','2006-05-30','Formación','Manteño unha reunión con Almudena e Pablo Pizorno da empresa Gestores de prevención para uncurso de bomberos para o porto,pero neceistan que teñan  curso de prevewnción de riscos laborais',501),
	 ('','2006-03-17','Cursos','Interesado na convocatoria',23),
	 ('Jesús M. Mera','2003-02-26','Prospección','A súa actividade é a fabricación de equipos propulsores para buques.
Teñen concerto co Colexio Hogar para cubrir as súas necesidades de traballo en CNC.               ',237),
	 ('Pedro Rey Vera','2003-02-28','Prospección','- Presentac. axudas a contratación.
- Colaboración dende o SOL para facilitalo seu contacto a empresas que precisen seus servizos.
- Solicitamos  presuposto para un curso de Reparación e mantemto. ordenadores para o noso departamento.
- Presenta 2 ofertas de emprego.
- Solicita axuda á contratación 2003, denegase por non cumprir período contratac. expdte.1792/077',238),
	 ('Pablo Búa Resp. RRHH','2006-07-28','Prácticas Actívate','Asinamos convenio para a realización de practicas de Experto/a en Limpeza. Duas quendas de prácticas de 100 h cada unha con 6 e 5 alumnos respectivamente, nos meses de agosto, setembro e outubro de 2006.
Avaliación Prácticas: Satisfactorias con reservas. Boa acollida. Disposición para os cambios. Pouco seguimento dos supervisores. Máis traballo que formación',262),
	 ('Isabel Piñeiro (Xerente)','2003-02-11','Prospección','Le interesa sempre que os novos contratados teñan os cursos de Prevención de riscos laborais, Medio Ambente e Calidade específicos do sector.
Aunque sempre terá en conta os currícula que le cheguen, poráse en contacto na medida en que xurdan novas contrataciós.
A formación por agora a ten cuberta entre a súa mútua e a subvención da industria aux. do sector naval.     ',226),
	 ('Angel Méndez Veloso','2003-02-17','Prospección','Angel Méndez é tamén Xerente de Admón. de MERCACEVI
O Mercado de Progreso integra unhos 350 traballadores autónomos e unhos 50 contratados por conta allea. O maior problema é a transmisión do negocio de pais a fillos.
Les interesa máis o relativo a axudas e formación para traballadores autónomos.
                                                                                                   ',228);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Angel Méndez Veloso','2003-02-17','Prospección','Angel Méndez é tamén Xerente do Mercado de Progreso
Mercacevi integra integra traballadores autónomos e en menor medida traballadores contratados por conta allea. O maior problema é a transmisión do negocio de pais a fillos.
Les interesa máis o relativo a axudas e formación para traballadores autónomos. Non obstante, queda en dar esta información a través de circular ós seus asociados.',229),
	 ('','2002-01-01','Prospección','Contratos mínimo con BUP',16),
	 ('Angel Pérez Cebrián','2003-02-18','Prospección','Prevén que por prexubilacións e porque van a iniciar unha nova liña de producción podan ter novas contratacións, poráse en contacto na medida no que precisen novos traballadores.
Acolle ben a información pero non amosa demasiado interés.
Ten previsto la contratación de un Deseñador Gráfico (FP Artes gráficas) no 2º semestre do ano. O perfil máis demandado é o de mecánicos de ciclo medio para mantenemento-mecanizado (axuste/reparación)',232),
	 ('Angeles Reboredo','2003-02-18','Prospección','"Hogarlin, s.a." é a maiorista para empresas de droguería e perfumería e os establecementos "Muchas" representan a parte minorista.
Cara a cursos con compromiso de contratación estaría interesada nunha formación de acollida, pero a dificultade é contratar tanto persoal de unha mesma zoa, cando eles van diversificando e abarcan Galicia e Ponferrada.           ',233),
	 ('','2006-05-19','Prospección','Diego Maraña xa non está na empresa agora ten unha consultora de medio ambiente',18),
	 ('Patricia Márquez','2003-02-20','Prospección','Xa teñen acordo de cursos con compromiso de contratación e de realización de prácticas con ASIME e Colexio Hogar.
Na medida que realicen contratacións tendrán en conta este servicio, aunque depende do que considere o Xerente ou dos candidatos que moitas vecen veñen propostos polos encargados. ',234),
	 ('Eva Bello','2003-02-20','Prospección','Pertence G. Pescanova. Elaboran: calamar, rabas, potas e chipirón. Ten unha nova liña de hixienizado (pezas de pescado envoltas en plástico individual) e pasaron a traballar baixo pedido diario, o que conleva manter a plantilla fixa e recurrir a ETT (Micofer-imposto polo G. Pescanova) cando aumenta a producción.
Crearon unha central de compras para Pescanova e Coren na Coruña.',235),
	 ('Concepción Guisande','2003-03-06','Prospección','Instalan cámaras frigoríficas en barcos.
Os perfis profesionais máis solicitados son os de Soldador, Calderero, Tubero e Axustador.
Previo a entrevista envie fax ca información sobre as axudas a contratación. A súa plantilla é fixa e é difícil que teñan que contratar xente pero o terán en conta.                  ',239),
	 ('Julia Insua','2003-02-24','Prospección','A contratación de novos traballadores a fan a través de convocatoria pública polo que non é posible que soliciten esta axudas.        ',240),
	 ('Juan Antonio Pizorno Díaz','2003-02-25','Prospección','Precisa incorporar comerciais a súa empresa con un perfil adecuado, por ello ve necesario dar unha formación específica (non hai bos comerciais no mercado).
Amósase interesado polos cursos con compromiso de contratación pero desconoce como teñe que facer a súa xestión, polo que solicita que se lle facilite a labor de contactar con profesionais de xestión e/ou docentes.                ',241);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Alberto Vázquez / Marcos Alvarez','2006-05-22','Prospección','Grupo JCA integrado por canteras Gravas y áridos del Louro (ponteareas) e 8 plantas de formigón (Pontevedra, Peinador/Redondela, Ponteareas, Hormigons Avia en Ourense, Salvaterra, Folgoso e Tomiño).
Posto de traballo máis ofertado é Chófer de formigoneira, con carne C1 e experiencia; que tamén son candidatos tidos en conta no posto de Dosificador.
Enviarán ofertas.                           ',242),
	 ('Sr. Velasco','2003-03-11','Prospección','Adelanto información por E-Mail e quedamos pendentes de concertar entrevista.                   ',247),
	 ('Miguel Pereiro','2003-06-17','Prospección','Queda ca documentación achegada por si requiren o noso servicio. No obstante, fan a contratación de persoal a través de SIOTTEMP, ETT.             ',333),
	 ('Roberto Rodríguez','2003-03-13','Prospección','Grupo Miñor Galicia, s.l. é a casa matriz na que a plantilla corresponde os Conselleiros da empresa e todo o persoal cuyas funcions teñan efecto en todalas empresas do grupo; tamén, inclue as empresas Granitos y Canteras Miñor, s.a. (Gracami) e Hormigones Valle Miñor, s.a. que é donde está o resto da plantilla.                          ',249),
	 ('Alberto Costas','2003-04-13','Axudas á contratación','Amosa oferta de Emprego de Albanel Oficial de 2ª.
Envíanse por E-Mail Bases e Anexos para solicitude da Axuda á contratación e ponse en contacto a sua xestoría Fisteco para a presentación da documentación.
A axuda á contratación que solicita denegase por falta de documentación. Exp 1759/077          ',258),
	 ('Matilde Pérez Mosteiro','2003-05-16','Prospección/oferta emprego','Amosa oferta de emprego para Graduado Social.
Recibe a información sobre o P.M.E. que lle interesa para poder informar os seus clientes, e non enterarse a través deles, como ocurreu con Servicom a quen estalle xestionando a axuda a contratación.                    ',267),
	 ('Rosa Casal Tielas','2003-03-07','Prospección','Actualmente participados polo Grupo Dragados, por iso no relativo a formación toman as decisións desde Madrid e están dentro do plan de Forcem do grupo.
As contratacións as seguen levando eles directamente e o fan por medio dos C.V. que reciben.
Recolle a documentación que lle entrego e queda en comentarlla co seu Xerente e con Madrid; poráse en contacto en caso de que o precisen.          ',243),
	 ('Alfredo Alcántara','2003-03-11','Prospección','G. empresas constituído por VIDISCO, S.L. (Pizza Mövil) e GALI CONVERTERS S. (Cash Converters) que son empresas independentes.
Sr. Alcántara representa a VIDISCO, centra a súa liña de expansión fora de Galicia (aquí o mercado está máis saturado). Perfil máis requerido é idade 18 a 25 anos, carné A1, xornada 15 horas semanais no fin semana. Nas oficiñas e obrador o persoal é máis estable.',244),
	 ('Ana y Visi Riveiro','2003-03-06','Prospección','Realizan traballos de pintura en barcos en reparación, por iso solen precisar pintores navais (non de brocha gorda) que estén acostumbrados a traballar dentro dos barcos.
Non teñen necesidade de realizar novas incorporacions. No obstante, acollen ben esta información cara os seus proxectos futuros.
                                                                                                  ',245),
	 ('Sres. Vilariño y Díez','2003-03-06','Prospección','IBERCONSA engloba a todalas tendas HIPERXEL.
As súas necesidades de formación estarían na líña de cursos de Atención o Cliente para Dependentas das tendas Hiperxel.
A selección de novos traballadores solen facerla por medio dos c.v. que reciben e dos seus contactos. Comentan que terán en conta o noso servicio.
                                                                                     ',246);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Xurxo Airas Cotobad','2003-03-14','Prospección','G. Maconsi constituído por: Maconsi, Sogalimpi, Gasal, Servimgal, Namarellos, Geriatros y Maconfre.
Para novas contratacións recurren aos CV recibidos, aunque terán en conta o noso servizo que descoñecía. A plantilla é bastante estable polo que non ten necesidade de cursos con compromiso de contratación en este momento. (non dispón de tempo polo que non é posible obtener máis información.)',248),
	 ('Clara Pazos','2003-03-14','Prospección','GOC e IBINCO son empresas de ámbito nacional con presencia en Portugal e América Latina. Actividade:obra civil, edificación e sector industrial de transformac. do metal. Postos de maior rotación e  contratación son Enxeñeiros Industriais e de Camiños. Na selección recurren a cv recibidos e a infoempleo.com. Teñen demanda continua, polo que poderíamos derivar sin necesidade de oferta previa.',250),
	 ('','2005-07-12','Axudas contratación','Información sobre as axudas a contratación 2005',187),
	 ('Gerardo Estévez','2003-02-25','Cambio titular Dtor. Planificación','O sr. Alonso deixa a empresa nesta seman para convertirse no Xerente de ESIPRO. Por ello, solicítame que envíe a información por fax para deixarlla á persoa que ocupe o séu posto e para poder levarse unha copia a nova empresa.
Implica facer seguimento.             ',256),
	 ('Dositeo Amoedo','2003-04-24','Prospección / oferta emprego','Presentan oferta para Junior Executive (equivalente a Asesor Financiero), perfil emprendedor, contrato mercantil, con interés que, tras superar tests psicotécnicos e entrevista, asistan a unha xornada o 14 de maio no Club Financiero.
Ofrecense para colaborar na docencia na  área Financeira. Teñen aula.
Informo a Rosa Amoedo que non temos candidatos disponibles.
                                 ',259),
	 ('Xosé Manuel Romero Rdguez.','2003-04-02','Oferta emprego','Establécese contacto previo con Lourdes Gonzalez da Mancomunidade de Vigo, que é quen envía a oferta por E-Mail.
A oferta é para a selección de carniceiros/as para un posto que van a montar no mercado de progreso en Vigo.
                                                                                                                                                                                ',260),
	 ('Rafael','2003-04-07','oferta emprego','Presentan oferta para ácontratación dun Panadeiro/a, en xornada continua, de 3:00 a 10:00 a.m.
A candidata ID1943 que inicialmente está interesada deixa de estar localizable polo que se chama á empresa informando, como excusa, que a candidata atopou outro traballo.
                                                                                                                                    ',261),
	 ('Angel Molinos Lentijo','2003-04-22','Prospección','Empresa dedicada a Servicio de Prevención Externo de recente creación, está pendente da autorización definitiva da Xunta. Presenta oferta de Emprego dun Comercial que permita incrementala súa cuota de mercado.                 ',263),
	 ('Pablo Núñez Alvarez','2003-04-14','oferta emprego','Dispoñen dunha finca cedida no Porriño na que poden acudir grupos de 12 a 30 persoas, que dividen en 2 grupos e un deles teñe que constituirse no abanderado, mediante o ataque con pistolas de pintura (deporte de paintball, federado en España a partires do seguinte ano).
Precisan crear cuota de mercado en Vigo para poder crear máis postos de traballo.                       ',264),
	 ('Elena Vázquez','2003-05-14','Axudas á contratación','Da referencia un chófer de PROMIL que lle informa das Axudas a sua contratación, agora que o vai a facer indefinido (o contrató por 3 meses en 2002 e por 9 meses en  2003). Explícase que non é posible a subvención xa que a primeira contratación foi antes de novembro de 2002 (data da que parte esta convocatoria).
Non dexesa información das axudas, non vai a contratar máis persoal.',265);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Ignacio Pombo Liria','2003-05-16','Prospección','Contrata frigoristas (que non hai no mercado) e dalles formación específica; dispon de aula de formación e medios específicos para Frío Industrial (con espacio suficente para 10 alumnos).
Non lle interesa que incluyamos beneficiarios nosos dentro dos seus cursos, nin contar co seu profesorado porque non quere  formalos para a competencia, pero pódese alugar o aula.',266),
	 ('Victoria Millán','2006-05-25','Seguimento ofertas','O candidato enviado reunía o perfil demandado pero a oferta para atender a un señor a suspenderon.',1003),
	 ('Oscar Castiñeira','2003-06-30','Axudas á contratación','Tras explicalo P.M.E. fai unha oferta de emprego para atopar un operario para a carga e descarga das máquinas de vending e achégaselle as bases e anexos para a solicitude de axudas á contratación.
Solicita axuda á contratación  2003 polo beneficiario 4063. Exp 1802/077                ',282),
	 ('Fernando Salgueiro','2003-07-01','Solicitude de información','Establecemos contacto xa que é a asesoría de PROMAGAL, S.L. e require da información sobre o PME, concretamente das axudas á contratación para poder informar os seus clientes e poder solicitála para este cliente.',283),
	 ('Maike Vázquez','2003-07-08','Oferta emprego','Restaurante na zoa de Bouzas, de nova creación. Dispón de 36 mesas. Asesorado polo S.A.E. (Rosa). ',288),
	 ('Antonio Núñez','2003-04-23','Prospección','Tendrá en conta o noso servicio, aunque no prevé facer novas contratacións. Coincidimos na visita Lola (Plan Inclusión Xunta) e máis eu, polo que incido nas características dos nosos beneficiarios.   ',289),
	 ('Andrés Sande','2006-03-30','Foro Dinamizac. Area metropolitana Vigo-Oporto','Elisa e Chelo, compromiso de enviarlle información sobre o Plan municipal de emprego.',26),
	 ('Patricia Fernández','2006-06-23','SICO','Nesta feira (Salón internacional da construción) coñecemos persoalmente a Patricia e nos comenta que a súa empresa está nun grupo con Dalfer e ArcevigoDa oferta que fixera quedara contenta polo que de necesitar xente volvería a falar con nós.',666),
	 ('Juan Pérez Parga','2003-07-04','Prospección','G. ENOR constituído por Ascensores Enor, S.A., adicada á distribución e con 180 traballadores aprox., e Electromecánica del Noroeste, S.A., adicada á fabricación de ascensores e 90 traballadores aprox.
Recurren a ETT (Nortempo) no caso de operarios, e para Enxeñeiros/Mecánicas/Eléctricos/ciclos meios a partir de alumnos en prácticas, ou ben, recurren ao anuncio na prensa.',284),
	 ('Juan Pérez Parga','2003-07-04','Prospección','G. ENOR constituído por Ascensores Enor, S.A., adicada á distribución e con 180 traballadores aprox., e Electromecánica del Noroeste, S.A., adicada á fabricación de ascensores e 90 traballadores aprox.
Recurren a ETT (Nortempo) no caso de operarios, e para Enxeñeiros/Mecánicas/Eléctricos/ciclos meios a partir de alumnos en prácticas, ou ben, recurren ao anuncio na prensa.',285);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Judith Pinal','2003-07-09','Prospección','Servizos de limpeza, mantemto. e xardinería (10 anos en Galiza). Central:Valladolid, delegacións: Madrid e Vigo. En Vigo teñen poucos clientes na área de xardinería, pero xestionan máis de 300 traballadores en total.
Experiencia con bolsas de traballo da admón na Coruña e  resultóu mal (inmigrantes que rechazaron o traballo para no perder prestación). Ca Concell. Benestar Social fixeron un ccc.',286),
	 ('Rosana Vila','2003-04-25','Prospección','G.Copo: Cetec, Copo Ibérica e Copo Galicia (fabricac. espumas automoción) con Rosana como Coord. RRHH), Componentes de Vehículos de Galicia (o Rpble. RRHH é Omar e teñen maior autonomía). O Coord. RRHH da central é Gabriel Sánchez. As empresas de Rosana se rixen polo convenio, dispoñen de bolsa de traballo pechada co persoal eventual e tenden a contratos fixos.',290),
	 ('José Antonio García Carrera','2003-04-24','Prospección','G. empresas con unha plantilla entorno a 550 traballadores. En Cillero é a planta de atúnidos máis automatizada. En Vigo está a sede central, con unhos 180 traballadores, e a sua actividade céntrase en calamares, túnidos, berberechos, etc.; Ten previsto  en un plazo de 2 anos trasladar su ubicación ó polígono industrial de Pontevedra. As maior necesidade de persoal é de operarias e mecánicos.',291),
	 ('Patricia Bustamante y Miguel Cazorla','2003-07-21','Prospección','Agradeceron a información transmitida e tendrán en conta o noso servicio, dado que se dedican a tramitar moitas subvencións para suas empresas clientes (también informéilles do S.A.E.).
Os seus clientes son de todos los sectores pero, sobre todo, do sector comercio.
Enviarán información a sus clientes e solicitan que lles manteñamos informados de cualquier novidade.                             ',292),
	 ('Miguel Angel Tejada Fernández','2003-07-18','Prospección','Acolle con agrado a documentación, aunque teñen o cadro de persoal moi estructurado e a maioría dos traballadores son fixos e teñen eventuais habituais (familiares de traballadores, …).       ',293),
	 ('Mª Pilar Da Ponte Tarrío','2003-11-06','Prospección','Empresa de nova creación, con 3 socias,  que precisa de comisionistas que fagan laboura comercial para ampliar cartera de clientes e poder contratar plantilla traballadores. Teñen despacho en Vigo e en Oporto.               ',298),
	 ('Charo Domínguez','2003-09-25','Prospección','Dou a conocer o PME e a impartición do curso de Laminador de Poliester polo que temos persoas debidamente formadas e temos interés en facer unha visita. Informa que neste momento é imposible porque ela vaise de vacacións en outubro e que lle mande información por fax para que poda amosala o seu Xerente.                                                    ',308),
	 ('Sr. Tenoira','2003-09-05','Oferta','informa que vai a contratar un traballador e que se non resulta voltará a chamar.                  ',311),
	 ('Juan Vázquez','2006-03-31','Xestións para BIAL ','Busca de libros de prevención de riscos laborais para BIAL.Falamos sobre as posibilidades de formación, que él comenta que en hostalería podería haber algunha posibilidade',73),
	 ('Carmen Fernández','2003-09-24','Oferta emprego','24/09/03 comunícase que non temos candidatos para a oferta de Repartidor con ciclomotor, pero dí que terán aberta esta oferta durante varios meses polo que podemos enviar os candidatos que xurdan. ',313);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Lilia Iglesias','2003-09-25','Oferta emprego','Fan oferta de emprego dun Técnico de mantemento para o Centro Comercial Travesía, nesta Concellería e no INEM.                                        ',316),
	 ('Fersal Asesores','2003-09-26','Oferta de emprego','Oferta de emprego feita a través de Fersal Asesores. Cando chamei para ampliar datos, dixéronme que tiñan todo resolto (sin máis explicacións). Desde Fersal A. dixéronme que chegaran a un acordo ca cociñeira que xa tiñan.      ',318),
	 ('Nieves Costas (CEP)','2003-10-06','oferta emprego','Oferta feita a través de Nieves Costas Parcero (da CEP) de aprendiz de Dependente.            ',320),
	 ('Roxelio Alvarez','2003-07-04','Prospección','Neste momento, non ten previsto ningunha contratación. En persoal, prima a políitca de prexubilacións. De todos modos, acolle a información remitida.       ',330),
	 ('Ramón Diez','2003-05-27','Solicitude información','Solicita información para clientes que queren crear empresa e relativo a contratación de persoal.     ',331),
	 ('Olga ','2003-06-13','Prospección','Entrégase documentación e infórmase sobre o PME e as axudas á contratación.
Queda en revisar a documentación entregada e chamar en canto requira o noso servicio.
                                                                                                                                                                                                                                            ',332),
	 ('Mª José','2003-08-05','Prospección','Dadas as características das obras é difícil que opten ás axudas á contratación e os cursos de compromiso de contratación. No obstante, terán en conta a bolsa de traballadores.',334),
	 ('Sr. Montenegro','2003-07-16','Sr. Montenegro','Fabrican transmisións para automoción, para FORD e CHRISLER en EEUU, e en menor proporción o grupo PSA Peugeot Citroën. Queren mantener a súa plantilla de máis de 1000 traballadores. Os perfís máis demandados son idade ata 30-35 anos e titulación de ciclo sup. ou FP mecanizado/eléctrico/electrónico e fan selección con Ajilon Consultores (facilita contacto). Adican máis de 40000 h/ano á formación.',335),
	 ('Alba de la Torre','2003-10-17','Prospección','Consultora de RRHH dedicada a: Selección, Formación RRHH, Externalización RRHH, Xestión por competencias, Análise de postos, …
Postos máis demandados nas áreas de Producción e Comercial.
Recollen os CV de Ader ETT cuyas oficiñas están en Vilagarcía.',337),
	 ('Jorge López','2006-05-11','Información','Traenos cartel para colocar no taboleiro.',89);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Eva Ruiz','2005-05-23','Oferta emprego','En España teñen 10 bases e a central é en Barcelona e as instalacións en Vigo son:
Parc. 34-35. Polig. A Granxa. 36400 O Porriño. tfno: 986342191 (datos obtidos na súa páxina web).    ',527),
	 ('Guillermo Lozano','2005-06-23','Prospección','Recepcionan CV desde finais de setembro ata principio de outubro. Para as súas necesidades de persoal ten convenio de colaboración cos colexios Mendiño, Fco. Sánchez e A Guía.
Non traballan con ETT
A contrata que fai a limpeza é Ramel
O seu maior competidor é Centroxogo.',560),
	 ('Pablo Marques','2005-08-04','Prospección','Actividade: Venda e reparación de maquinaria para hostelaría e alimentación (marcas Infrico, Coreco, Vifrío, Fagor, ...)
Son 13 traballadores: xerente, comercial, secretaria, 2 admvos. e mecánicos de frío e calor. Teñen moitas dificultades en atopar persoal polo que están valorando a formación con compromiso de contratación.',561),
	 ('Lucrecia Rodguez.','2003-09-16','Prospección','Realizan Selección de Persoal. Publican anuncios no País, Expansión, e infojobs.
Proceso de selección: cv + entrev. tlfnica. + comentario a cliente + entrev. persoal + comentario a cliente + entrev. final. Postos máis demandados:
- FP electricidade (automoc.)
- Enxeñeiros Técn./Sup.(automoc. - solen ter carencia nocoñecemto. catia v5 e idiomas)
- Lcdos. empres./económ./químicas',336),
	 ('','2003-02-10','Formación ','Reunión Ignacio, Elisa, Chelo, con Jorge (formación) e Sonia (selección) para falar de formación',116),
	 ('Francisco Villanueva','2006-06-23','SICO','Contactamos de novo con él nesta feira de SICO (Salón internacional da construc.), ofrecéndose a colaborar. Segue traballando con BIAL',1047),
	 ('Roberto Janeiro','2004-01-28','Oferta emprego','Empresa integrada por 3 traballadores (Delegado, técnico e administrativa).                      ',426),
	 ('Ana','2003-12-15','Prospección','Revisamos a documentación entregada e informa que os períodos para a recepción de cv son: diciembre-xaneiro e abril-maio; así como, os procesos de selección serán:  finais febreiro e xuño-xullo.
Cada ano fan o proceso de selección nuhna cidade galega distinta e este ano será en Vigo.        ',427),
	 ('Ovidio Sánchez Quiroga','2005-06-23','Prospección','O sr. Sánchez é o Delegado en Galicia do G. Avanza dedicado a actividades de RRHH: forza de vendas, Ett, selección e formación, consultoría xurídica, ... e o Dtor. Xerente de Servicios Empresariales del Atlántico de externalización de servicios e traballa no sector da hostalería centrado nos hoteis (Hotel Lisboa é o principal cliente).
Entrega de cv en mano.
                                     ',444),
	 ('Adriana Iglesias Conde','2004-04-29','Prospección','Actualmente, teñen 3 factorías pero, en breve, van a pechar a do Areal e o director comprometeuse a manter a plantilla co que ten que reubicalos nas outras factorías.
Cando por cargas de traballo precisan manipuladoras de alimentos recurren a ETT (Select, porque permite a incorporación inmediata).
Adriana ofrecese para facilitar toda información que precise.
                                    ',453);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Aran Feijoo','2004-06-28','Ofertas emprego e axudas á contratación','Fai oferta de Aux. Administrativo/a para unha nova oficiña que van a abrir na Avda. Beiramar (frente ao porto pesqueiro).
Axuda contratac 04 4764, 4791 exp. 2593(denegada)
Axuda contratac.05 polos beneficiarios 4791,4764                                                      ',463),
	 ('Pilar Luaces','2005-05-31','Oferta emprego','Solicitou docente para un curso de Inserción laboral e enviouse unha candidata da base de datos de expertos docentes (ID867).                    ',528),
	 ('Karmele Aizpurua','2005-06-08','oferta emprego','Empresa con sede en Irún que ten un comercial autónomo en Vigo para as provincias de Pontevedra e A Coruña e solicítanos 1 técnico de mantenimiento para ditas provincias.            ',529),
	 ('Marta Viana','2005-08-05','Prospección','Seus proveedores son: Grandal Services, sobre todo, para o persoal de sala - Fundación Igualarte - Pedra.
Como fundación ten convenios ca Univ.Santiago para Lcdos.Hª, ca Univ.Pontevedra de CC.Sociais (areas de Prensa, Comunicación e Didáctica) e co Valentín Paz Andrade (FP).
Para completar necesidades de persoal recurren ao Labora (están bastante descontentos).               ',559),
	 ('Berto Comesaña','2005-09-07','Prospección','Organizac. eventos e montaxe exposicións.
Ten convenio ca Universidade para proporcionar modelos de Belas Artes. Colaboran cas concellarías de Cultura e Festas (organizan as Festas do Cristo da Victoria desde fai 15 anos).
Postos eventuais máis solicitados son aux. de organización (carga e descarga e seguridade nos espectáculos).
Forma acceso: ficha, foto, fotocopia DNI e da tarxeta SS.',565),
	 ('Mónica Rico','2005-09-07','Prospección ETT','Tamén oficina en Ourense. Sede central en Bilbao.Traballan áreas de loxística e transporte, frío indust. e hostalería (extras f.semana/catering e restaurac.), anque aún están  definindo o ámbito de traballo.
Acceso: cv (en mano, correos, internet), cubrir ficha e dan cita para unha entrevista previa.
Teñen un servizo de PRL propio, Spril. Ten interese nos ccc para frío industrial.',566),
	 ('Mª Jesús','2006-04-27','Oferta de emprego','Chama para solicitar recepcionistas para un despachpo de abogados "Legalia"',221),
	 ('Manuel Martínez','2003-02-06','Prospección','Visita a empresa Elisa e Chelo para plan de formación e posibles contratacións',230),
	 ('Jesús Morgade','2005-09-13','Oferta emprego','Á oferta de Peón achéganse os datos de 7 candidatos do BIAL polo que non teñen o ID e non constan na oferta.',570),
	 ('Ana Rubio','2005-09-15','Oferta peón/solador','Actividade: Aplicación de pavimento de terrazo continuo
A oferta de Ax.Peón/solador é para traballar no centro comercial Gran Vía.                     ',571);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Sr. Campo Figueroa','2006-03-17','Oferta emprego','Ver oferta en papel, a base de datos non deixa introducir ID superiores ao 5799, polo que os Id dos candidatos enviados a oferta desta empresa non se poden introducir.               ',665),
	 ('Rafael','2003-06-01','Curso con Adecco','2003 Facemos un curso CCC na empresa por intermediación de Adecco de clasificadoras de madeira. 32 horas.
O horario de traballo na empresa e turnos de mañán, tarde e noite, 7 días seguidos e descanso 2 días . E imprescindible ter coche                     ',281),
	 ('Pilar','2004-08-06','Solicitude información','Pilar ven para solicitar información sobre a nosa bolsa de emprego, xa que ela traballa con Cogamni e Intes',478),
	 ('Lois','2004-04-21','Alicerce - itinerario de mediación','Dende a CIG amosaron moi boa disposición para colaborar co itinerario de Mediación do proxecto Alicerce, a única restricción é a do espazo físico e os medios cos que contan.                    ',550),
	 ('Miguel Panete','2005-09-16','Prospección','Horario: 8:30 a 14:30 e 16:30 a 19:30
2 áreas: Consultoría (asesores externos do Plan experimental de emprego do Porrño) e Formación (cursos de pesca para persoas inscritas no ISM; quedan en pasar información da convocatoria de nov/dec 05. Especialidades: Sanidade marítima, PRL, CMA, Inglés(con estadías no extranxeiro para directivos) e Francés (necesitan docentes).',572),
	 ('Fernando e Verónica','2003-06-10','Prospección','A selección para os cursos faise a través do SGC. Farán cursos de caixeiras, repoñedores e dependentes en setembro- outubro, xa que abrirá a finais de outubro, ppios de novembro. Poderemos ter posibilidades de colaboración para mais adiante. ',280),
	 ('Sergio Franco','2006-06-23','Solicita información','Mostránse interesados na solicitude de axudas á contratación pero queren esperar á nova convocatoria para solicitar o noso servizo.       ',574),
	 ('Francisco López','2005-12-16','Axudas contratación','Solicitude de axuda a contratac. ano 2005, pero denegase por falta de documentación unha vez que se lle reclamou por escrito.',632),
	 ('María Rego','2006-02-16','Oferta emprego','Oferta un posto de limpadora e outro de cociñeira,logo paraliza a oferta porque xa esán cubertas',656),
	 ('Marta Rey','2005-11-29','Prospección','Todo centralizado na Coruña. Plantilla:13 persoas na Coruña e Vigo, sen vacantes posibles. Subcontratan con Grandal Services (monitores/as), Sirvent, Catering, Spica, como ppais. proveedores. Comprométense a subcontratar con empresas da cidade e nalgúns casos fan concursos anuais. Non becarios nin voluntarios. Co persoal de Didáctica van a Ett.',625);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Verónica Diego','2006-03-16','Envío listaxe','Enviase listaxe coas persoas dispoñibles para participar nas accións de formación.',658),
	 ('Alfredo Campuzano','2006-07-19','Seguimento oferta operaria producción','Non contrataron a ningunha das candidatas (unha delas refería problemas de espalda ao estar moito tempo en pé); deixa a oferta aberta para sempre que teñamos candidatas con este perfil.
Comuníco que lle vamos a achegar información das axudas á contratación.',227),
	 ('Mª Luisa André','2005-09-15','Prospección','Fundación=Arte e cultura
Obra social=deriva da entidade bancaria
Neste momento ambas están unificadas baixo a dirección de Mª Luisa André en Vigo, aunque todo dirixido desde A Coruña.
As actividades fanse con Ubia Grandal (=Grandal Services) como proveedor e contactan con Mario Viaga.
Están pendentes do remate as obras de rehabilitación do cine Fraga para incrementar a súa actividade.',577),
	 ('Manuel Gonzáez López','2005-10-14','Prospección','Contacto facilitado polo responsable de RR.HH de Caixanova.
Multinacional que leva as áreas de Consultoría (Selección de perfís de alta cualificación), Formación (cursos profesionales a medida) e Productos (administra e comercializa materiais psicométricos).
A forma de acceso aos procesos de selección é a través das páxinas de empleo de Expansión, de infoempleo e da web corporativa (www.shl.es).',588),
	 ('Ainhoa Pérez','2005-11-07','Solicvitude información','Solicita información relativa ás empresas de selección de persoal máis representativas. Envío listado e información do SOL.            ',618),
	 ('','2004-06-01','Prospección','Estableceuse un primer contacto en Sisisfo. Agora volvo a contactar  con ela para soilicitar información sobre as empresas que se emprazarán no Parque Tecnolóxico de Valadares',466),
	 ('Jose Manuel Lago','2004-06-02',' Prospección','Reunión por cursos de palista( os fai cunha empresa de excavacións en Mos) e soldadura (taller proipo en Cabral). Vai falar con ASIME e con algunha empresa mais para cursos CCC. Para o curso de palista necesitase carné B e son sobre 16 horas, estase a elaborar  a normativa sobre este tema.',467),
	 ('Angel Villar','2004-06-29','Prospección ','E tamén dono de Electro Pesca, S.L.  Fan traballos de reparación e mantemento de motores .A formación CCC a ve difícil porque é unha empresa pequena, pero estaría disposto a colaborar se fixeramos algún curso cedendo algún motor. Necesitarían xente de electricidade, mecánica. As veces acuden o Colexio Hogar, pero estos están collidos antes de rematar a formación.
',469),
	 ('Angel Villar','2004-06-29','Prospección','E dono tamén de Krug naval, disposto a colaborar en formación cedendo material. ',470),
	 ('Xurxo  Airas','2006-05-10','Prospección','Chamamos para intentar concertar unha cita, pero pola folga do metal , aplázase',493);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Francisco López','2005-08-18','Información axudas','Ven para informarse sobre a documentación ncesaria para as axudas',632),
	 ('Pablo Pizorno','2005-05-30','Formación','Teño unha entrevista con Pablo e Almudena (Formega) para acción formativa de bomberos para o porto pero é necesario o curso de PRL
Pablopizorno@gestoresdeprevención.com
Chelo',263),
	 ('Ana Belén Moldes','2006-09-27','Solicitude información usuaria ID 6058','Chama para confirmar que a usuaria ID 6058 é de noso servizo e informa que vai a contratala cun contrato de formación por 1 ano desde outubro. Non tiña pensado contratar a ninguén ata semana santa pero gustoulle moito esta autocandidatura.',195),
	 ('Alberto Rodríguez','2005-11-16','Prospección','Concesión das piscinas (Bouzas, Lavadores, Teis e Travesas) e ximnasios municipais. O persoal é fixo e asumido por cada empresa concesionaria (levan 10 anos). Os procedementos de contratación ven recollidos no seu convenio. Acceso: levando cv á oficina das Travesas para baixas ou eventualidades. Os postos que integran son: limpadora, monitor/a natación/musculación/aerobic, admón. e mantemnto.',622),
	 ('Esperanza Santos','2005-12-16',' Prospección','Multinacional con sede en Bruselas, presente en 18 cidades de España e 35 estacionamentos en total. En Vigo xestionan os parking de Porta do Sol e da Praza de Portugal.',629),
	 ('Luis Rego','2006-02-28','Oferta emprego','Inmobiliaria de nova creación, a súa ubicación será en Martín Echegaray. Non ten concretado o nome da inmobiliaria, polo que poño o de a persoa de contacto.        ',661),
	 ('Jaime Fdez. Arrabal','2006-10-02','seguimento oferta colocador pavimentos','Ofreceu o posto de traballo a Bruno Covelo e éste quedou en darlle resposta hoxe.',225),
	 ('Paula Ruas','2006-05-03','Seguimento ofertas','A oferta cancelouse non chamou a ningunha candidata.',1001),
	 ('Miguel Del Río','2006-03-08','Formación con compromiso de contratación','Achego información sobre ccc e facilita datos dos requisitos das persoas a contratar. Quedo en facer unha presondaxe para confirmar a viabilidade desta formación.',1004),
	 ('Angel Helguera','2004-09-01','Información-colaboración Alicerce','Información-colaboración Alicerce (Itinerario de Animación-discapacidade)
O número de traballadores refírese o grupo empresarial CO.GA.MI.
Contacto en Santiago: Francisco Abuín (Responsable de Formación)
R/ Modesto Brocos, 7, baixos. 15704 Santiago de Compostela.981574698.                      ',535);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('María Fernández','2002-02-25','Asiste','Ctro. ensino infantil e primario. Non ten comedor nin transporte.
As activs. extraescolares as organizan os profesores. Recollen c.v. para impartir ensino, se poden achegar por si aumentan os servizos para activs. e festas.
Non recibiron subvencions pola contratación, son indefinidas, coñecian as bonificacions á S.S.
Terán en conta o Proxecto Asiste para activs. extraescols.',407),
	 ('Consuelo Martínez','2003-02-24','Asiste','Ctro. privado de educac. infantil ata 4º ESO. Comedor propio (persoal estable, non se plantexa sustitucions).  No recreo os profesores coidan dos nenos. Cubren vacantes con coñecidos e antigas alumnas.
Activa leva as actividades; deportes depende da ANPA. Non pediron subvencions por contratación.
Teranos en conta para posible ampliación do servizo, en principio non contemplada.        ',408),
	 ('Alfonso Fdez.','2003-03-11','Asiste','Non ten comedor nin  transporte. Non vai implantar servicio de cuidado de nenos de 8 a 9 horas. Os propios profesores e nenos maiores que entran antes coidan dós máis pequenos.
As actividades extraescolares unhas as levan as Apas e  son  os propios pais as que as imparten e outras os docentes.
Interesoulle o proxecto para un futuro.',411),
	 ('Cristina Campos','2003-02-24','Asiste','Ten educación infantil, primaria e secundaria.
O servicio de comedor o leva un catering, o cuida a propia cociñeira e o profesor que lle corresponda, o mesmo que os descansos. Non ten máis centros.
Non lle interesa contratar por agora e o terá en conta.                            ',416),
	 ('Roberto','2003-03-13','Prospección G. Miñor Galicia, S.L.','Gracami é unha empresa pertenecente ao Grupo Miñor Galicia, S.L.',60),
	 ('','2005-05-24','oferta emprego','chaman urxente pedindo persoal para tareas de actividades nauticas. Se volta a chamar estarían interesados na oferta: Cruz Alonso, Alberto Iglesias e Christian Barros.               ',596),
	 ('Esperanza Calviño','2006-10-17','Solicita modelo oferta emprego','Envíase modelo oferta emprego por fax',435),
	 ('Angel Carrillo','2006-10-20','Seguimento oferta 01/09/06','informa que contrataron a outra persoa (posiblemente candidato a través de infojobs) e que non chegaron a entrevistar aos nosos candidatos.',1061),
	 ('Rocío Piñeiro','2006-11-07','Prospección','Cambiaron de enderezo a Tui. Manteñen os mesmos clientes (Grupo Pescanova), polo que seguen precisando persoal nos entornos de Redondela, Porriño e arredores de Vigo.
Os postos máis demandados son na área de Precocinado - operaria manipuladora de peixe con CMA -  e Loxística - carretilleiro/mozo almacén/chófer-',124),
	 ('Manuel','2003-02-28','Asiste','Educación primaria e secundaria. Teñen comedor, pero o coidan os profesores.
As actividades extraescolares levanas os docentes.
Teñen problema cos mestres porque aunque o fan voluntario non están contentos e estánse plantexando trocar e contratar   tanto as actividades como o transporte.                                                                                                              ',409);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Sr. Bouzón','2003-02-28','Asiste','Infantil, primaria, secundaria e C.S. de FP. Servizo de comedor (o levan cunha limpadora que lles axuda). Os profesores realizan as actividades e algunhas antigos alumnos. Teñen transporte (unha furgoneta que vixía o conductor e algún profesor).
Chamará porque van poñer un servizo para recoller nenos ás 8 horas e outro de Guardería.
Fan contratacions indefinidas e recurren ao SGC da CEP.',410),
	 ('Paloma Presas','2003-03-06','Asiste','Teñen comedor de 0-6 anos, os coidan elas que son participantes da sociedade.
O  transporte o levan elas. (Teñen problemas para  contratar ó  conductor  dó autobús porque ten que ter un permiso  especial).
Non van a contratar a ninguén porque tamén teñen persoal de prácticas.',412),
	 ('Sor Nieves','2003-03-13','Asiste','Teñen comedor e sempre coas mismas coidadoras, os profesores e antigas alumnas.
Transporte contratado cunha empresa particular, que pon os  seus propios coidadores.
Contratan as activids. extraescolares con autónomos.
Tiveron o sevizo de 8 a 9 horas, pero despois aumentaron o horario de entrada dós nenos. Para o ano posiblemente voltaranno a implantar.
Sempre teñen o mesmo persoal.',413),
	 ('Estanis','2003-03-13','Asiste','Lugar exclusivo de cumpreanos. Non recollen nenos por horas, soamente cumpreanos.
Son dous socios e só traballan os dous.
Un de eles irase, habería posibilidades de que contratasen a alguén.                  ',414),
	 ('José  - ofertas O.E. Coia','2001-01-01','oferta emprego','Previamente se había contactado con la Oficina De Empleo De Coia,en la cual demandaban aprendices de carpintería.                       ',44),
	 ('Manuel Castiñeiras','2003-04-09','Anuncio en prensa','establezo contacto coa empresa a consecuencia dun anuncio por palabras no que solicita persoal. Infórmase das axudas á contratación e fai unha oferta solicitando Xardinero.',65),
	 ('Ana Pardiñas','2005-07-14','Información','Informolle en xullo de 2005 das axudas á contratac. pola contratác. dunha persoa de Vigozoo II             ',65),
	 ('Ana Moldes','2006-06-15','Solicitude traballadores/as','Chama para solicitar perruqueiras ou auxiliares de perruquería',195),
	 ('¿?','2005-05-10','E.O. Mar de Vigo','Terán en conta a información recibida.',604),
	 ('¿?','2005-05-18','E.O. Mar de Vigo II','Quedan en estudiar a documentación recibida. Son ebanistas carpinteiros.',605);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('','2005-05-09','E.O. Mar de Vigo II','Enviada información.',609),
	 ('¿?','2005-05-11','E.O. Mar de Vigo II','Envíouse información.',610),
	 ('¿?','2005-05-12','E.O. Mar de Vigo II','Enviouse información.',611),
	 ('¿?','2005-05-16','E.O. Mar de Vigo II','Enviouse información.',617),
	 ('¿?','2005-05-10','E.O. Mar de Vigo II','Enviouse información.',637),
	 ('¿?','2005-05-06','E.O. Mar de Vigo II','Enviada información.',640),
	 ('Maruxa','2005-02-15','Formación','Falamos da posibilidade de facer un curso con compromiso de contratación, falará con Sandra e comenta a posibilidade de se pode ser por ETT',1009),
	 ('Xiana García','2005-03-14','Formación','Falou coa directorta de RR.HH e pareceulle interesante a formación con compromiso pero neste momentpo non poderían por estar nun momento baixo de producción',496),
	 ('Beatriz Macías','2007-05-07','Prácticas Actívate','Asínase convenio de prácticas con ACTIVATE para A.A.D. nos meses de maio de xuño de 2007',357),
	 ('Sonia','2005-03-04','Formación','Falamos polo tema de Toysal pero neste momento m¡non se pode poruqe a cousa está un pouco parada. Comentame que a automoción está un pouco en baixa porque para o ano saca Citroen un novo modelo polo que neste momento non fam¡n moita producción',116);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Chus','2005-04-15','Prospección  ','Formac posible en GEfCO,pero fan contrataos de 1 mes prorrogables a tres. Podería haber posibilidade de facer algo de carretilleiro. Fixero formac. de camareiro con xente da zona do Rosal e de Nigrán no Parador de Baiona pero a contratac. era para fins de semana.',131),
	 ('-','2006-01-26','Prospección','Falamos coa asociación para solicitar informac. sobre TEXVIGO, nos remiten a Bruno de Deloitte que é o asesor xurídico',1011),
	 ('Montse Aguirre','2006-06-21','Seguimento oferta','A encargada que levou a selección foise e levouse todos os CV e o resultado da selección, polo que non nos poden informar do resultado',1018),
	 ('','2006-07-13','motivo','situation',1025),
	 ('','2006-07-13','','fdgfsdg sfdg fsdg fsdg fsdg fsdg fsdg sdfg fsdg fsdg 
fsdg sdf gfsd f
s 
fssdfgfsdg fsgfsgfsdgfsdg fsdg fsdgfsdgsdf
g sdfg 
dsg fdg fsdgfsdg fsdg sdf fsdgfsdg fsdg fsdgsd sdfg fsdgfsdg sdfg fsd gfsd gfsd gsdfsd gfsdg sdf
 sdfgfsdg fsdg fsdg fsdg sdfg fsdg fsdg fsd g
sdg sdg sdfgsd 1212341234 1234124 2423
 423423
4 234
 23
4 
234
 234 23423 432',1025),
	 ('Ninoska Silva','2006-06-27','Seguimento oferta limpadora','achega correo informando que farán contrato a Cristina Covelo (ID 3931) para o mes de xullo de luns a venres a razón de 1 hora e 5 minutos ao día.',464),
	 ('Margarita Robleda','2006-07-19','Seguimento oferta mariñeiro','Van a contratar a Iván Lorenzo (ID 5476) por 6 meses e tiveron problema para concertar entrevista ca outra candidata. 
Quedo en achegar información relativa as axudas á contratación, para que ela a poida achegar ao contramaestre que está seleccionando aos mariñeiros e ao Xefe de administración.',187),
	 ('José Ramirez','2006-07-31','Oferta manicurista','Comunico que non temos candidatas disponibles neste momento.',475),
	 ('Eva Rodríguez','2006-09-29','Oferta operario producción','Informa que o usuario ID 3937, a pesar de non cumprir co requisito da idade gustoulles moito tanto a eles como a empresa e vai a ser contratado por 2 meses e medio, despois por outros 3 messes e medio pola Ett e posteriormente pola empresa.',116),
	 ('Salvador Comesaña','2006-10-10','Curso de soldadura non realizado','Ven por eiquí para falar dos motivos da non realización do curso de soldadura. Non se realiza porque a empresa Mondelnort  non presenta a documentación administrativa requirida.',1078);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Montserrat Calle','2006-11-07','Prospección e actualización de datos','A súa actividade é a xestión cultural (ludotecas e bibliotecas en tarefas de animación infantoxuvenil) e a organizac. de congresos e eventos. Os perfis máis demandados son lcdo/diplomado no campo da educación e especialización en tempo libre/animación sociocultural e, tamén, azafatas. Cando non ten candidaturas recurren neste orden ao SGC, prensa e contactos.',253),
	 ('Ana (Persoal)','2006-12-21','Prospección empresas catering','Informo do noso servizo e facilítame información da súa empresa.
O posto que máis requiren é de camareiro/a extra. As persoas interesadas deben dirixir o seu cv ao establecemento da rúa Urzaiz, 102 á atención de Persoal.',1087),
	 ('Margot Alvarez','2006-12-21','Prospección','Margot é agora a directora de servizos centrais e segue no enderezo de Simón Bolivar, a ETT agora está en Ecuador 41. Os sectores cos que traballan son conserveiro, automoción, telemarketing, hostalería e artes gráficas',494),
	 ('Dolores Rodríguez Alonso','2007-01-18','Prospección e actualización de datos','Manteñen a mesma forma de traballo, mesmos clientes e postos que xestionan (ver a ficha de visita correspondente).',119),
	 ('Cristina Díaz','2006-11-17','Prospección e actualización de datos','Postos máis solicitados: Teleoperadores de emisión/recepción; Operarios/as automoción (para empresas en Vincios e Porriño) e mozos almacén.
Máis información na ficha de recollida de información correspondente.',126),
	 ('Mónica Vázquez','2007-02-14','Prospección e información do P. Actívate','E un centro abierto, de desnvolvemento persoal e atención sociosanitaria interprofesional, cunha unidade sociosanitaria de psiquiatría e neuroloxía xeriátrica e unha unidade de psicoxeriatría. Aténdese con caracter rehabilitador e de xeito temporal ou permanente a persoas maiores con algun tipo de dependencia, discapacidade, enfermidade ou trastorno que requira unha atención temporal ou permanente.Teñen persoas de todas as idades. Capacidade para 100 persoas. 42 persoas con patoloxía psíquica. 
O persoal que teñen é psiquiatras, médicos xerais, DUE,Aux. enfermería, camareiras, limpadoras, persoal de mantemento, terapeuta ocupacional, fisioterapeuta, Ciclo medio de sáude mental
A contratación de traballadores é a través do CV recibidos e das solicitudes aos colexios profesionais.
Teñen o convenio de hospitalización privada de Pontevedra.
No verán poden ter demanda de xente para limpeza e cociña e neste momento de DUE e psiquiatras.





















































',387),
	 ('Arancha Mañas','2006-11-03','Prospección concesionarias','Integran as empresas: Recuperación y reciclaje - Nutrigras, S.A.(xestor e transporte resíduos) - PMA (almacén loxística). Fan o reciclaxe de aceite nas comunidades de veciños do concello. Postos máis demandados: chofer con carné mercancías perigosas e almacenamento resíduos con coñecementos de carretilla e mecánico camión. Fan cursos ca Asociación de Mos.',1080),
	 ('Teresa Lemos Domínguez','2006-11-15','Prospección e actualización de datos','Sectores cos que máis traballan son Automoción (operarios producción) en Vigo e Porriño e no Metal. Os postos que máis requiren son operarios de producción, carretilleiros, mozo de almacén e administrativas con idioma e coñecementos contabilidade e/ou facturación.',118),
	 ('','2006-11-16','Prospección','Recollida de información sobre perfís e sectores
Automoción, construc., hostalería, alimentación, comercio, banca. e postos de carristas, operarios de cadea, camareiros/as que sepan pinzar,mozos  de carga e descarga, dependentas...
',131),
	 ('Ana Gabián','2006-11-10','Actualización de datos','Antiga Creyf´s que ca fusión con People convírtese en Startpeople. Neste momento seguen traballando de xeito independente e a partir de xaneiro haberá cambios.
Postos máis solicitados nas áreas de Comercio e Automoción: Mozos de almacén e dependentas; carretilleiros e operarios de automoción; aux. admva. con inglés.
Máis información na ficha de recollida de información correspondente.',1083);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Sonia Castro','2006-10-31','Prospección','Automoción, textil, banca, granitos, industrias químicas, agrario (bodegas), carga e descarga, mozos de almacén....
Postos operarios de cadea, carristas, persoas para mantemento, mozos de almacén, comerciais,',116),
	 ('Gonzalo (director) /Gracinda Pampillón (Presidenta)','2007-05-07','Prácticas Actívate','Asinase convenio para a realización de practicas das A.A.D. de ACTÍVATE nos meses de maio e xuño de 2007',1143),
	 ('Gonzalo','2006-11-21','Prospección','Mantemos unha reunión para detectar perfís solicitados e sectores cos que traballan, e forma de reclutamento.
Traballan co naval e solicitan soldadores, caldereiros, peóns..., non importa a idade pero teñen que ter experiencia.',457),
	 ('Grace Morris','2006-10-26','Prospección','Instalaronse en Vigo en marzo deste ano. Recollen CV de todos os perfís e traballan con empresas de todos os sectores.
E a ETT do Grupo Norte, este grupo ten servizos de seguridade, limpeza, mantemento, teleservizos, xestión de arquivos, outsourcing e servizos sociais. 
Levan a limpeza de Citroen  a través de Limpisa (servizo de outsourcing).',1079),
	 ('Guillermo Giráldez','2006-11-17','Actualización de datos','O acceso á Ett é por autoentrada (a persoa usuaria introduce su cv no ordenador) ou cubrindo ficha de solicitude (se non ten coñecementos informáticos). Os postos máis demandados son Operarios automoción, operarias conserveiras e conxelados, mozos almacén e carretilleiros e carpinteiros/laminadores/empastadores do sector naval. Ver información máis amplia na ficha de recollida de información.',123),
	 ('Chema Serantes','2006-12-01','Prospección e actualización de datos','Achégase información máis ampliada a través da ficha de recollida de información.
A forma de acceso é entregando cv na empresa ou na súa web ou infojobs. Non traballan con empresas do sector automoción. Os postos máis requiridos son: mozo carga/descarga, xestor almacén, soldador, electricista, operaria producción (artes gráficas), admva. de reforzo, ...',72),
	 ('Manuel/Begoña/Mª José','2006-11-30','Prospección e actualización de datos','Entrevista persoal e individual mantida con cada unha das persoas sinaladas. Máis información a través da ficha de recollida de información.
Acceso cubrindo formulario escrito ou en ordenador e levar cv, tamén pódese a través da web.
Postos máis requiridos: Axudantes de oficios, peóns sen cualificar, mozos almacén,...',125),
	 ('Beatriz Alvarez/Lucía García','2006-11-22','Prospección e actualización de datos.','Na ficha da entrevista figura máis información. 
O sector co que máis traballlan é con alimentación (dependentes e oficios), ademáis de electricistas, administración e loxística.
',130),
	 ('Emilia Fdez. Goce','2006-11-10','Prospección e actualización de datos','Acceso persoal, levando cv, cubrindo ficha e entrevista previa.
Sectores: Automoción (operarios/as), Loxística e transporte (operarias, carretilleros, mozos almacén, ...), Conxelados (operarias de sala de elaboración de peixe) e Hostalería (extras catering).
Máis información na ficha de recollida de datos.',128),
	 ('Sonia Rodríguez','2006-11-28','Prsopección','Informanos dos sectores (hostalería, comercio, construción, automoción e en xeral todos os sectores). Postos de encofradores, electricistas, mozos de carga e descarga, carretilleros, operarios de cadea...
',136);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Arán Feijo','2006-12-18','Oferta de emprego','Comentame o resultado da selección da oferta de enxeñeiro técnico industrial',463),
	 ('Lorena Dike','2006-12-18','Oferta de emprego','Ponse en contacto para solicitar cociñeiro e auxiliar de limpeza',1041),
	 ('Manuel Añón Gómez','2007-01-22','Concrección práticas Actívate e prospección','José Ml. Davila (concreta calendario para realización de prácticas de conducción); Elisa informa da labor desde o SOL (ccc interésalle cando amplíen instalacións). 70 traballadores (68 contrato indef.) e 2 aux.clínica para cubrir vacacións ao longo do ano. Postos máis solicitados:aux.clínica (mín. FPI) e limpadora de planta (experiencia). Candidatos por coñecidos ou cv que achegan.
Tamén prevese a realización de prácticas para Auxiliar de axuda a domicilio de ACTÍVATE',532),
	 ('Victoria Millán','2007-01-31','Prospección de mercado','O seu contrato na Cámara de comercio remata en setembro, logo terá que buscar local. Informolle do proxecto Actívate. Quedamos  en seguir colaborando na inserción laboral das persoas.
Fainos unha oferta dunha persoa para divulgación.',1003),
	 ('Madre Teófila','2007-02-05','Visita de prospección.','Teñen 90 habitacións cun coste entre 650-750€/mes según tamaño e recursos da inquilina (elas as amueblan ó seu gusto). Con contrato indefinido ten 6 aux. enfermería (turnos de mañana, tarde e noite) e 7 limpadoras (9 a 15 e de 21 a 22 horas). A partir de abril necesitarán alguén para portería, pero xa valora 2 candidatas.',376),
	 ('Encarna Alonso de Paz','2007-02-16','Visita vivenda comunitaria','Neste momento ten 5 persoas (semiválidas). Como traballadores ten 2 auxiliares, unha animadora sociocultural  e unha traballadora social. En breve abrirá unha oficina  de  prestación de servizos de axuda a domicilio na Ronda de Don Bosco, tamén quere montar un centro de día',655),
	 ('Lucía del Campo','2007-02-26','Prospección e información P. Asiste','En García Barbón está a direccion de calidade, financieira, RR. HH, técnica, obras e a  dirección xeral. E unha empresa do Grupo Caixanova.  Xestiona tanto en Galicia como no resto do territorio nacional: residencias para maiores, centros de día e estancias diurnas, servizo de axuda a domicilio e servizos como telesiastencia, servizo de enfermería a domicilio, axudas técnicas, asesoría socio- sanitaria. Os centros en funcionamento son (residencias e centros de día) Ribadumia, Ferrol, Laraxe, Noia, Carballo, Larouco, Ribeira, e en Madrid en Valdemoro e Leganés. Próxima apertura Lalin e Barbadás.  As residencias soen ter unha capacidade de 160 persoas aprox.Nas zonas nas que hai hospital soen ter problemas para cubrir os postos porque a xente prefire traballar no Sergas polo convenio.
Levan o servizo de aux. de axuda a domicilio nos concellos de nigrán, Redondela, Vilagarcía e Santiago. En Naron levan o cheque. O persoal no servizo de axuda a domicilio se subroga. Os contratos que fan son de 9 meses en periodos de 18 meses. Teñen necesidade de persoal de limpeza, e gerocultores en Ribadumia e en Ribeira xa que as persoas formadas vanse o Sergas sobre todo na época de verán.

',345),
	 ('Remedios Loureiro','2006-10-31','Prospección','Asociación creada ca idea de definir este sector e evitar o intrusismo. Abarcan toda Galicia aunque aínda non son moitas empresas asociadas.
Ten interes na formación con compromiso de contratación',1101),
	 ('Francisco','2007-02-20','Propección','Atendo é un centro de atención ao maior que ofrece servizos de atenc. domiciliaria, ctro. de día, clínica xeriátrica e de fisioterapia e activs. afíns. Nunca teñen máis de 2 persoas facendo prácticas no centro de día ao mesmo tempo. Requiren das persoas a contratar formación previa, experiencia, soltura, calidez no trato, madurez (idade maior de 25 anos sin límite) e compromiso.',203),
	 ('Marien Moure','2007-03-01','Prospección','Centro de día para maiores dedicado á atención e apoio de persoas con alzheimer con capacidade de 33 prazas (están ocupadas neste momento 28 prazas). Teñen servizo de catering con serunion. Están de alta na Consellaría de sanidade e na de Asuntos sociais, porque ten interese en que os pacentes veñan derivados polo médico de cabeceira.
Pódese achegar o cv por correo postal ou a info@alzdem.com
Na plantilla son 3 auxiliares, psicóloga, fisioterapeuta, ATS, coidadora e directora. O perfil requirido é de unha persoa madura e valórase que sexa madre de familia (ten experiencia na limpeza e coidados persoais).',353);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Elena Blanco','2007-03-06','Prácticas Activate','Asinamos Convenio para a realización de prácticas os meses de marzo, abril e maio de 2007 (lavandería-SERVIMGAL)
Avaliación Prácticas: Satisfactorias con reservas. Boa acollida. Boa disposición para cambios. Deficientes instalacións',248),
	 ('Begoña Domínguez Arias','2007-03-12','Prácticas Actívate','Mediante Resolución da Xerencia do CHUVI, concedesenos autorización para a realización de prácticas como OPERARIOS DE LAVANDERÍA nas instalacións do Meixoeiro durante os meses de marzo, abril e maio.
Avaliación prácticas: Moi satisfactoria. Boa acollida. Moi boas instalacións.',384),
	 ('Manuel R. Ferreira','2006-10-31','Prácticas Actívate','Asinamos convenio para a realización de prácticas de Teleoperador/a ACTIVATE durante os meses de decembro 2006 e xaneiro 2007.
Avaliación prácticas: Satisfactorias. Nivel de esixencia alto para os/as nosos/as alumnos/as (exclusión social). Difícil inserción
',1113),
	 ('Juan Carlos Pérez Santiago','2007-02-06','Prácticas Actívate','Asinamos acordo para a realización de prácticas ACTÍVATE nos vehículos que de transporte adaptado ten a C. Vermella nos seus servizos de intervención social.
Avaliación prácticas: Altamente satisfactorias. Certa dificultade para cubrir o tempo de prácticas.',540),
	 ('Maribel (Responsable SAD)','2007-04-27','Prácticas AAD-Actívate','Asinado en febreiro o acordo de prácticas, concretamos a súa posta en marcha. Prácticas 15 alumnas-50 horas no Servizo Municipal de axuda a domicilio xestionado por Cruz Vermela no mes de maio 2007.
Avaliación prácticas: Altamente satisfactoria, no seu plantexamento, organización, seguimento e facilidades dadas.',375),
	 ('Belen Casal // Oscar Sáez(responsable zona Noroeste)','2006-11-27','Prácticas Actívate','Asinamos convenio para a realización de prácticas de ´axudantes de cociña´ de ACTÍVATE. nos meses de decembro 2006 e xaneiro 2007.
Avaliación Prácticas: Satisfactorias.

 ¡Contratan unha das alumnas de actívate como axudante de cociña para trabalar a a tempo parcial en Euroresidencias!',1041),
	 ('Nuria Pascual','2006-10-20','Prácticas Actívate','Asinamos convenio para a realización de practicas de axudantes de cociña en centros escolares e sociosanitarios durante os meses de novembro, decembro e xaneiro de 2006/7, e de AAD (que finalmente non se chegan a concretar).
Avaliación prácticas: Altamente satisfactoria.',367),
	 ('Cipriano Giménez','2006-10-17','Prácticas Actívate','Asínase convenio para a realización de prácticas de ´aux. de cociña ´de ACTIVATE durante os meses de novembro, decembro e xaneiro de 2006/7.
Avaliación Prácticas: Altamente satisfactorias. Participan nelas as dúas persoas xordas do itinerario.',374),
	 ('Mari Carmen Pascual (Directora)','2006-10-18','Prácticas ACTÍVATE','ASINASE CONVENIO PARA A REALIZACIÓN DE PRÁCTICAS DE AX.DE COCIÑADE ACTÍVATE DURANTEOS MESES DE NOVEMBRO , DECEMBRO E XANEIRO 2006/7.
Avaliación practias: Altamente satisfactorias
',1114),
	 ('Lydia Toyos (Directora)','2006-10-17','Prácticas Actívate','ASINASE CONVENIO PARA A REALIZACIÓN DE PRÁCTICAS DE AX.DE COCIÑADE ACTÍVATE DURANTEOS MESES DE NOVEMBRO , DECEMBRO E XANEIRO 2006/7.
Avaliación practias: Altamente satisfactorias
',1115);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Pablo Marcote','2007-05-25','Prácticas Actívate','Asinamos convenio para a realización no Colexio Marcote de prácticas do Itinerario de ax. de cociña en centros escolares e sociosanitarios nos mese de novembro, decembro e xaneiro 2006/7.
Avaliación prácticas: Moi satisfactorias.',1117),
	 ('Roberto González','2007-06-06','Seguimento oferta Administrativo/a','no seguimento realizado ca empresa informan que ID 3938 Guadalupe Beiro rexeitou a entrevista e que ID 3827 Diana Fdez. está pendente dunha 2ª entrevista e ten posibilidades.',249),
	 ('Manuel Añón Gómez','2007-10-17','Prácticas Actívate','Asinamos convenio para a realización de prácticas de axudante de cociña en centros escolares e sociosanitarios (na Residencia), condutor de transporte adaptado (nos vehículos da Residencia e do Centro de Día) e A.A.D. (en varias quendas tanto na Residencia como Centro de Día) de ACTIVATE, dende novembro de 2006 ata xuño de 2007.
Avaliación prácticas: Moi Satisfactorias. Centro sempre colaborador. Posibilidade de inserción de xerocultoras e condutoras.
',1121),
	 ('Ana Fieira (Psicóloga)','2007-03-19','Prácticas Actívate','Asinamos convenio para a realización de prácticas de Auxiliar de axuda a domicilio de  ACTIVATE durante o mes de abril 2007.
Avaliación prácticas: Moi Satisfactorias. Boa supervisión e plantexamento. 
',1089),
	 ('Luis Barros','2007-02-23','Prácticas Actívate','Asinamos convenio para a realización de prácticas de axuda a domicilio de ACTIVATE durante os meses de marzo a xuño de 2007.
Avaliación prácticas: Satisfactorias ( inda que temos a sensación de que teñen bastante axustado o persoal e a estancia das nosas alumnas facilitalles o traballo). Posibilidades de  inserción',372),
	 ('Angeles Alvarez','2007-03-19','Prácticas Actívate','Asinamos convenio para a realización de prácticas de axuda a domicilio de ACTIVATE durante os meses de abril a xuño de 2007
Avaliación prácticas: Satisfactorias. Boa colaboración e seguimento',380),
	 ('Mariano Gutierrez','2007-02-09','Prácticas Actívate','Autorízannos a realización de prácticas de auxiliar de ax. a domicilio de ACTIVATE nos mese de marzo a xuño de 2007.

Avaliación: Satisfactoria. Boa organización. Seguimento mellorable.',383),
	 ('Fco Javier Pérez Bravo','2007-02-06','Prácticas Actívate','Asínase convenio para a realización de prácticas de condutor..., de ACTIVATE, durante o mes de febreiro de 2007',1122),
	 ('Pablo Bua','2007-06-12','CCC Limpeza de inmobles','Achego por email borrador do convenio para o seu coñecemento e axilización da súa sinatura.',262),
	 ('Carlos Callejo','2007-06-13','Seguimento oferta','Móstrase gratamente sorprendido cos candidatos que entrevistou. Pasará en persoa a informar o resultado da selección (con ID 6339  é con quen ten máis dúbidas para a súa contratación pola falta de carné B e de experiencia acreditada con contrato)',662);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Victoria Millán','2007-05-29','Presentación a P. Actívate','Solicitou cita para darse a coñecer e intercambiar información e experiencias co Proxecto Actívate',1003),
	 ('Manuel Alonso/ Marcos Caderno','2006-11-27','Prácticas Actívate','Asínase convenio para a realización de prácticas de teleoperador/a na súa empresa nos mese de novembro, decembro de 2006 e xaneiro de 2007',1138),
	 ('Roberto Alvarez','2007-01-08','Prácticas Transporte Escolar','Inicio das prácticas do Itinerario de Transporte Escolar.',1139),
	 ('Conchi Somoza (Directora)','2007-05-07','Prácticas ACTÍVATE','Asínase convenio para a realización de prácticas de A.A.D. de ACTÍVATE nos meses de maio e xunio de 2007.',373),
	 ('Sandra López','2007-01-08','Prácticas Transporte Escolar','Inicio das prácticas de Transporte Escolar',1140),
	 ('Perfecto Estévez','2007-01-08','Prácticas Transporte Escolar','Inicio das prácticas de Transporte Escolar',1141),
	 ('Roberto Rodríguez','2007-08-03','oferta admvo/a de xuño','Non contrataron a ID 3827 Diana Fdez. Comesaña',249),
	 ('Luisi Salmerón','2007-07-19','oferta emprego-actualización enderezo','Dacordo ós datos da oferta actualizo o enderezo da empresa que deixa de ser en Nuestra Señora de la Merced, 5 - Pozuelo de Alarcón (28223 Madrid)',569),
	 ('Sandra Vázquez','2008-03-24','Denegación pago formación compromiso de contratación','Non se efectúa o pago do curso de Condutor/a de carretilla elevadora por falta de cumprimento do compromiso de contratación e infórmase á empresa para darlle a oportunidade de subsanar esta situación.',1102),
	 ('Isabel Gómez','2007-10-22','Oferta Repartidor/aplicador','Infórmase que non temos candidatos disponibles',1164);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('Rpble. RRHH','2007-11-06','Oferta Limpadora','A responsable RRHH discúlpase por non informar que non chamaron ás candidatas por darlle outra oportunidade á persoa a quen iban a sustituir.',1134),
	 ('','2007-09-10','Oferta electromecánico','infórmase que tras a sondaxe realizada non temos candidatos/as disponibles.',1166),
	 ('Elida Quintela','2010-05-12','Información sobre axudas contratación','Informa que ten contratado a ID 8117 do proxecto Vigo Emprega e quere información sobre as axudas á contratación. Informo que estamos elaborando as deste ano e que non pode optar sento un contrato inicial por obra de mes e medio o que lle fixo ao noso usuario.',1177),
	 ('Guillermo Martinez','2012-02-22','Prospección','Achégase modelo de oferta de emprego e quedamos á espera da súa previsión de contratacións para a sondaxe de pefis de dependenta con clara orientación ao cliente e que podan facen unha formación teórica e práctica previa.',1186),
	 ('Ramón (Dpto. Laboral)','2010-08-18','Oferta de emprego','fixo unha oferta de emprego para contratar unha contable entre 25 e 40 anos con máis de tres anos de experiencia nesas tarefas e coñecementos de Cai. Non houbo candidatas que cumpliran con estes requisitos e estiveran dispoñibles.',1182),
	 ('Juan Carlos Gil','2012-02-29','Prospección','Informa que a final de ano abrirán un novo centro en Mos e terán en conta as candidaturas que procedan dese entorno. Ademáis ao longo do 2013 abrirán outros centros, un deles na Avda. de Madrid.
A forma de acceso á empresa é deixando o seu cv por email, na web ou directamente nos distintos centros. Neste momento ten previsto a contratacion dun técnico de mantenemento e quedo en enviarlle modelo de oferta de emprego para a súa xestión.',1035),
	 ('Alicia Sánchez','2012-03-06','Prospección','Non teñen previsto realizar contratacións, neste momento recurren por outsourcing a Alliance (para un delineante con Catia v5) e por ETT a Randstad.
Alicia preséntase como a interlocutora con nós e solicita email no que deixar o meu contacto cara a posible colaboración futura.',1009),
	 ('Centralita','2012-03-06','Prospección','Indican que previamente a entrevista co Sr. Airas é mellor achegarlle información por email, porque sempre está reunido.',493),
	 ('Karina Fernández','2012-03-07','Prospección','Karina estará de baixa por enfermidade a lo menos 3 meses e non hai outro interlocutor ao que dirixirse.',25),
	 ('Esther Gutiérrez','2012-06-06','Oferta Administrativa/o','Xa entrevistaron ás candidatas pero aínda non tomaron a decisión. Están entre unha das nosas candidatas e outra que lle facilitou un contacto.',1198);
INSERT INTO public.empresa_seguimentos (contacto,"data",motivo,situacion,id_empresa) VALUES
	 ('David Fernández','2012-06-06','Seguimento oferta Tecn. mantenimiento e instalación ascensores','No seguimento realizado informan que só entrevistaron a ID 8555 pero que contrataron a outro candidato con mais experiencia.',1197),
	 ('Elisa Casal','2013-12-03','Oferta de emprego','Outras ofertas de emprego desta empresa se realizaron coa central Anislumara, SL.',1185),
	 ('Roberto Varela','2014-05-19','Seguimento oferta Aux. restauración','Acaban de obter os permisos de urbanismo necesarios e ten un compromiso de remate de obra para o 18 de xullo, aínda que pensan que ao ritmo da obra podería ser antes e iniciar a actividade a primeiros de xullo.',1226),
	 ('Roberto Varela','2014-06-19','Seguimento contratacións','Pretenden apertura local para 15 de xullo.Comenta que das persoas seleccionadas non contratarán a 8 por xa estar traballando ou por outros motivos. Quedamos en que si temos novas candidaturas se acheguen mañana de 12 a 14 horas ao CC A Laxe para mantener entrevista con él (queren contratar a 6 persoas máis).',1226),
	 ('Olivia Ojea','2014-07-08','Seguimento oferta Camareiro de maio 2014','No seguimento realizado informan que contrataron a outro candidato.',1215),
	 ('Nazaré','2014-07-08','Seguimento oferta Aux. Axuda a domicilio','no seguimento realizado informan que non seleccionaron a ningunha das candidatas porque deron prioridade a que o domicilio particular estivese cercano ao domicilio de traballo.',1235),
	 ('Fernando Briones','2016-03-29','Seguimiento oferta de emprego','O señor Briones indica que chamaron a todos os candidatatos para pedir o seu cv e non foi posible contactar cunha das candidatas. Dos currícula recibidos gostáronlle 2 e entrevistaron e contrataron a David Bande Alvarez candidato proposto polo Vigo Integra III.',1240),
	 ('Gregorio Díaz','2016-03-29','Seguimento oferta limpadora Centro Comercial','O sr. Díaz informa que pasou os datos a súa compañeiro en Madrid e que en canto teña información deste proceso enviará email.',1243),
	 ('','2016-06-22','Axudas á contratación e mellora do Emprego da mocidade viguesa 2016','Recibiron axuda 2016 pero a usuaria pola que reciben a axuda consta na base de datos de Vigo Emprega.',1246),
	 ('Fernando Briones','2016-06-14','Seguimento ofertas de emprego','Informan que os procesos seguen abertos, aínda non fixeron entrevistas. Ocúpase destes procesos o responsable da empresa e o responsable comercial.',1240);