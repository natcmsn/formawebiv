INSERT INTO public.empresa_axudas_contratacion (ano,estado,nummeses,observacions,posto,xornadacompleta,beneficiario_id,id_empresa) VALUES
	 (2007,NULL,6,'','Auxiliar Administrativa',NULL,4764,1163),
	 (2013,1,12,'','Camareiro/a',true,9317,1211);