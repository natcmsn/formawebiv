INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-06-26',0,8,'','Albanel',10,2,NULL,NULL),
	 ('2001-04-27',1,6,'','Operaria de almacén de producto terminado',10,6,NULL,NULL),
	 ('2001-04-27',1,3,'','Operario troquel e prehormado de corsetería',10,6,NULL,NULL),
	 ('2002-01-01',1,6,'','Pintor',10,18,NULL,NULL),
	 ('2001-03-30',1,1,'','Profesor de ofimática',10,76,NULL,NULL),
	 ('2001-04-17',1,3,'','Oficial xardineiro',10,77,NULL,NULL),
	 ('2001-04-24',1,2,'','Charcutero/a e pescadero/a',10,78,NULL,NULL),
	 ('2001-05-07',1,2,'','Diseñador de redes CATV',10,79,NULL,NULL),
	 ('2001-05-07',1,2,'','Instalador de redes telefónicas',10,79,NULL,NULL),
	 ('2001-05-07',1,3,'','Encofrador-Alicatador',10,80,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-05-08',1,3,'','Peón con coñec. de xardinería e laboreo de terra',10,81,NULL,NULL),
	 ('2001-05-09',1,1,'','Comercial de ordenadores,redes e programas',10,76,NULL,NULL),
	 ('2001-05-15',1,1,'','Diseñador /a de páxinas Web',10,82,NULL,NULL),
	 ('2001-06-15',1,4,'','Administrativo/a dpto comercial internacional',10,21,NULL,NULL),
	 ('2001-06-19',1,2,'','Administrativa con buen nivel de inglés',10,4,NULL,NULL),
	 ('2001-06-19',1,1,'','Departamento de facturación',10,4,NULL,NULL),
	 ('2001-06-26',1,2,'','Carpinteiros Navais',10,72,NULL,NULL),
	 ('2001-06-27',1,1,'','Monitor de Carpintería',10,83,NULL,NULL),
	 ('2001-06-19',1,1,'','Frigorista',10,79,NULL,NULL),
	 ('2001-06-21',1,1,'','Agente Especialista Saúde',10,84,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-07-03',1,4,'','Mozos de carga e descarga',10,85,NULL,NULL),
	 ('2001-07-10',1,2,'','Xardinero/a',10,86,NULL,NULL),
	 ('2001-07-09',1,1,'','Montador Mecánico Naval',10,21,NULL,NULL),
	 ('2001-07-18',1,3,'','Manipulador/a de regalos',10,87,NULL,NULL),
	 ('2001-07-16',1,1,'','Electricistas e Alicatadores',10,86,NULL,NULL),
	 ('2001-08-02',1,2,'','Camarero/a',10,86,NULL,NULL),
	 ('2001-07-23',1,2,'','Agente Integral Sistema',10,89,NULL,NULL),
	 ('2001-07-17',1,15,'','Limpiador/a',10,94,NULL,NULL),
	 ('2001-07-17',1,4,'','Camareiro/a con experiencia en bandexa',10,86,NULL,NULL),
	 ('2001-08-20',1,1,'','Docente de Maquinista de Confección Industrial',10,95,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-08-22',1,4,'','Albanel',10,96,NULL,NULL),
	 ('2001-08-22',1,4,'','Carpinteiro- instalador de moblesl',10,97,NULL,NULL),
	 ('2001-09-19',1,40,'','Promotora de Grandes Superficies',10,102,NULL,NULL),
	 ('2001-08-28',1,2,'','Comercial American Expres',10,101,NULL,NULL),
	 ('2001-09-25',1,2,'','Auxiliar administrativo',10,103,NULL,NULL),
	 ('2001-09-21',1,25,'','Monitor,recepcionista,auxiliar de fast-food etc',10,104,NULL,NULL),
	 ('2001-10-03',1,2,'','oficiales electricistas, pintores navales',10,77,NULL,NULL),
	 ('2001-10-04',1,1,'','Chofer repartidor',10,105,NULL,NULL),
	 ('2001-10-15',1,3,'','Axudante carpinteiro e axud. de barnizador',10,106,NULL,NULL),
	 ('2001-10-23',1,2,'','Pintor de automóbil',10,86,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-10-26',1,3,'','Médico',10,86,NULL,NULL),
	 ('2001-10-26',1,2,'','Perruqueira',10,107,NULL,NULL),
	 ('2001-11-11',1,1,'','Aprendiz de camarero',10,108,NULL,NULL),
	 ('2001-11-08',1,4,'','Auxiliar administrativo',10,109,NULL,NULL),
	 ('2001-11-15',1,6,'','Aprendiz de Floristería',10,110,NULL,NULL),
	 ('2001-11-09',1,1,'','Técnico de Hardware',10,111,NULL,NULL),
	 ('2001-11-16',1,5,'','Repartidor/a con furgoneta',10,112,NULL,NULL),
	 ('2001-11-28',1,4,'','Auxiliar de confección',10,113,NULL,NULL),
	 ('2001-12-07',1,3,'','Locutora vendedora de bingo',10,114,NULL,NULL),
	 ('2001-12-07',1,1,'','Chofer carné E',10,114,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2001-12-13',1,1,'','Peón lavacoches',10,114,NULL,NULL),
	 ('2001-12-18',1,4,'','Promotor ejecutivo de ventas',10,134,NULL,NULL),
	 ('2001-12-12',1,2,'','Pintores',10,118,NULL,NULL),
	 ('2002-01-08',1,3,'','Electricista',10,80,NULL,NULL),
	 ('2002-01-09',1,1,'','Carnicero',10,114,NULL,NULL),
	 ('2002-01-17',1,1,'','Comercial/coordinador de equipos',10,77,NULL,NULL),
	 ('2002-01-24',1,1,'','Electricista',10,86,NULL,NULL),
	 ('2002-01-25',1,2,'','Albanel',10,70,NULL,NULL),
	 ('2002-02-07',1,1,'','Albanel',10,80,NULL,NULL),
	 ('2002-02-08',1,1,'','Pintor pistola para sector naval',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-02-12',1,1,'','Conductor carné C, coñec. de gruas',10,86,NULL,NULL),
	 ('2002-02-15',1,1,'','Montador de mobles',10,86,NULL,NULL),
	 ('2002-02-01',1,4,'','Dependenta tenda de noivas',10,140,NULL,NULL),
	 ('2002-02-08',1,4,'','Empregada de ciber',10,141,NULL,NULL),
	 ('2002-02-12',1,1,'','Conductor carné C e manexo de gruas',10,86,NULL,NULL),
	 ('2002-02-15',1,1,'','Montadores de mobles',10,86,NULL,NULL),
	 ('2002-02-15',1,3,'','Peón de reciclaxe e pintado',10,18,NULL,NULL),
	 ('2002-02-14',1,9,'','Peón Forestal',10,143,NULL,NULL),
	 ('2002-02-15',1,1,'','FP Electrónica',10,77,NULL,NULL),
	 ('2002-02-21',1,5,'','Dependenta',10,144,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-02-25',1,1,'','Repartidor con moto',10,86,NULL,NULL),
	 ('2002-02-13',1,1,'','Persoa con coñecementos  medios,altos de cociña',10,132,NULL,NULL),
	 ('2002-02-28',1,1,'','Comercial con experiencia  en ventas e marketing',10,86,NULL,NULL),
	 ('2002-02-05',1,2,'','Conductor con todos os carnés',10,86,NULL,NULL),
	 ('2002-02-05',1,1,'','Sopletista',10,86,NULL,NULL),
	 ('2002-03-12',1,1,'','Colocador de lana roca (sector naval)',10,132,NULL,NULL),
	 ('2002-03-12',1,4,'','Mozo almacén',10,148,NULL,NULL),
	 ('2002-03-15',1,1,'','Decorador/a',10,149,NULL,NULL),
	 ('2002-03-18',1,1,'','Secretaria',10,150,NULL,NULL),
	 ('2002-04-05',1,3,'','Supervisora de promotoras',10,102,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-04-08',1,2,'','Carretilleiro',10,86,NULL,NULL),
	 ('2002-04-09',1,2,'','Calderero oficial',10,86,NULL,NULL),
	 ('2002-04-10',1,5,'','Laminador de poliester',10,152,NULL,NULL),
	 ('2002-04-12',1,7,'','laminador de poliester',10,153,NULL,NULL),
	 ('2002-04-16',1,5,'','peón soldador',10,153,NULL,NULL),
	 ('2002-04-16',1,1,'','Camarera',10,86,NULL,NULL),
	 ('2002-04-16',1,1,'','Peón electricista',10,77,NULL,NULL),
	 ('2002-04-19',1,1,'','Profesor de poda',10,154,NULL,NULL),
	 ('2002-05-06',1,2,'','Operario de taller',10,155,NULL,NULL),
	 ('2002-05-09',1,5,'','Peón impermeabilizador',10,156,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-05-02',1,15,'','Xardineiros',10,157,NULL,NULL),
	 ('2002-05-06',1,3,'','Maquinista de confección',10,158,NULL,NULL),
	 ('2002-06-03',1,4,'','Peón carpintería',10,162,NULL,NULL),
	 ('2002-06-04',1,1,'','Camarera',10,163,NULL,NULL),
	 ('2002-06-10',1,4,'','Gruista',10,153,NULL,NULL),
	 ('2002-06-10',1,2,'','soldador-calderero',10,164,NULL,NULL),
	 ('2002-06-14',1,1,'','Pintor de automóviles',10,86,NULL,NULL),
	 ('2002-06-14',1,1,'','Mecánico industrial',10,86,NULL,NULL),
	 ('2002-06-06',1,3,'','Dependenta',10,165,NULL,NULL),
	 ('2002-06-24',1,0,'','Comercial',10,167,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-06-28',1,2,'','Axudante de oficial e oficial de calefacción',10,168,NULL,NULL),
	 ('2002-07-04',1,3,'','montador-soldador',10,153,NULL,NULL),
	 ('2002-07-09',1,3,'','Dependenta',10,169,NULL,NULL),
	 ('2002-07-18',1,13,'','Limpiador/a',10,170,NULL,NULL),
	 ('2002-07-17',1,1,'','FP II electricidade',10,4,NULL,NULL),
	 ('2002-07-17',1,1,'','Carpinteiro con coñec. de soldadura',10,4,NULL,NULL),
	 ('2002-07-22',1,4,'','Auxiliares de dpto de corte',10,4,NULL,NULL),
	 ('2002-07-15',1,1,'','Pintor chorreo',10,77,NULL,NULL),
	 ('2002-07-12',1,1,'','Camarera',10,108,NULL,NULL),
	 ('2002-07-23',1,1,'','Peón obra pública',10,171,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-07-22',1,2,'','Auxiliar de limpeza',10,172,NULL,NULL),
	 ('2002-05-08',1,2,'','Caixeira/repositora',10,159,NULL,NULL),
	 ('2002-05-16',1,3,'','Caixeira',10,159,NULL,NULL),
	 ('2002-05-16',1,2,'','dependenta polivalente',10,159,NULL,NULL),
	 ('2002-07-26',1,2,'','dependenta frutería/pescadería',10,159,NULL,NULL),
	 ('2002-07-23',1,1,'','Aprendiz Carpinteiro',10,173,NULL,NULL),
	 ('2002-08-21',1,1,'','Carpinteiro naval',10,175,NULL,NULL),
	 ('2002-08-29',1,3,'','Axudante',10,113,NULL,NULL),
	 ('2002-09-02',1,3,'','Contable',10,194,NULL,NULL),
	 ('2002-09-11',1,4,'','Albanel',10,70,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-09-10',1,2,'','Perruqueira',10,195,NULL,NULL),
	 ('2002-09-12',1,5,'','Peón de arqueoloxía',10,196,NULL,NULL),
	 ('2002-09-20',1,7,'','Limpiador/a',10,197,NULL,NULL),
	 ('2002-09-24',1,1,'','Electricista naval',10,77,NULL,NULL),
	 ('2002-09-26',1,6,'','Dependenta',10,198,NULL,NULL),
	 ('2002-09-26',1,2,'','Montador de mobles',10,72,NULL,NULL),
	 ('2002-10-03',1,4,'','Repositor de prensa nas máquinas',10,199,NULL,NULL),
	 ('2002-10-03',1,1,'','FP Electrónica',10,200,NULL,NULL),
	 ('2002-10-03',1,4,'','Comerciales-promotores/as',10,201,NULL,NULL),
	 ('2002-10-04',1,3,'','FP administración e/o electricidade ou electrónica',10,202,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-10-04',1,2,'','soldador',10,153,NULL,NULL),
	 ('2002-11-09',1,3,'','Conductor/a furgoneta',10,203,NULL,NULL),
	 ('2002-10-11',1,1,'','Fileteadoras',10,132,NULL,NULL),
	 ('2002-10-17',1,4,'','Comercial',10,204,NULL,NULL),
	 ('2002-10-18',1,1,'','Cortadora/marcadora de confección',10,116,NULL,NULL),
	 ('2002-10-18',1,1,'','Camareiro',10,132,NULL,NULL),
	 ('2002-10-25',1,1,'','Comercial de páxina web',10,82,NULL,NULL),
	 ('2002-10-25',1,1,'','Comercial portal  inform. para comercios',10,82,NULL,NULL),
	 ('2002-10-23',1,1,'','Peluquera',10,205,NULL,NULL),
	 ('2002-10-29',1,1,'','Perruqueira',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-10-29',1,1,'','Camareiro',10,116,NULL,NULL),
	 ('2002-10-29',1,1,'','Conductor',10,116,NULL,NULL),
	 ('2002-10-29',1,1,'','Peón',10,116,NULL,NULL),
	 ('2002-10-29',1,1,'','Comercial',10,116,NULL,NULL),
	 ('2002-05-21',1,3,'','Traballadora social',10,206,NULL,NULL),
	 ('2002-05-24',1,4,'','Auxiliar de axuda a domicilio',10,206,NULL,NULL),
	 ('2002-11-08',1,4,'','Traballadora social',10,206,NULL,NULL),
	 ('2002-11-08',1,2,'','Maquinista  de confección industrial',10,113,NULL,NULL),
	 ('2002-11-11',1,1,'','Teleoperador con altos conoc. de informática',10,126,NULL,NULL),
	 ('2002-11-12',1,1,'','Conductor camión',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2002-11-11',1,12,'','Caixeira/repositora',10,159,NULL,NULL),
	 ('2002-11-08',1,1,'','Comerciales',10,207,NULL,NULL),
	 ('2002-11-18',1,1,'','Agentes de seguros',10,209,NULL,NULL),
	 ('2002-11-25',1,2,'','Laminadores de poliester',10,174,NULL,NULL),
	 ('2002-11-26',1,1,'','Podologo',10,210,NULL,NULL),
	 ('2002-11-26',1,1,'','Perruqueira',10,210,NULL,NULL),
	 ('2002-11-26',1,1,'','Persoa para charla sobre productos financieros',10,193,NULL,NULL),
	 ('2002-12-02',1,5,'','Executivo comercial',10,215,NULL,NULL),
	 ('2002-12-04',1,2,'','Peón Fontaneiro',10,72,NULL,NULL),
	 ('2002-12-27',1,1,'','Perruqueira',10,195,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-01-07',1,2,'','Comercial',10,204,NULL,NULL),
	 ('2003-01-10',1,7,'','Laminador de poliester',10,116,NULL,NULL),
	 ('2003-01-14',1,2,'','Axudante',10,113,NULL,NULL),
	 ('2003-01-15',1,2,'','Canteiro',10,219,NULL,NULL),
	 ('2003-01-17',1,3,'','Persoa para empresa de desinfectación',10,72,NULL,NULL),
	 ('2003-01-15',1,1,'','Camareira',10,220,NULL,NULL),
	 ('2003-01-21',1,11,'','Auxiliar Administrativo',10,221,NULL,NULL),
	 ('2003-01-21',1,1,'','Coordinador para festas de noite',10,222,NULL,NULL),
	 ('2003-01-21',1,8,'','Azafatas para festas de noite',10,222,NULL,NULL),
	 ('2003-01-23',1,1,'','Aprendiz para taller de lavado',10,213,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-01-28',1,1,'','Técnico Comercial',10,223,NULL,NULL),
	 ('2003-02-12',1,4,'','Administrativo Dpto. de Compras',10,225,NULL,NULL),
	 ('2002-02-05',1,21,'','Albanel',10,230,NULL,NULL),
	 ('2003-02-26',1,1,'','Axustador mecánico',10,237,NULL,NULL),
	 ('2003-02-27',1,2,'','Delineante proxectista',10,237,NULL,NULL),
	 ('2003-02-27',1,3,'','Responsable de compras',10,237,NULL,NULL),
	 ('2003-02-18',0,1,'','Axudante de mantemento (Boiro)',10,233,NULL,NULL),
	 ('2003-03-03',1,4,'','Administrativa- contable',10,238,NULL,NULL),
	 ('2003-03-03',1,4,'','Secretaria executiva',10,238,NULL,NULL),
	 ('2003-03-07',1,1,'','Dosificador',10,242,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-03-07',1,2,'','Chofer camión Hormigonera',10,242,NULL,NULL),
	 ('2003-03-07',1,1,'','Aprendiz electromecánico',10,242,NULL,NULL),
	 ('2003-03-07',1,1,'','Peón de limpeza',10,251,NULL,NULL),
	 ('2003-03-07',1,0,'','Camareira',10,252,NULL,NULL),
	 ('2003-03-10',1,5,'','Ludotecario/a',10,253,NULL,NULL),
	 ('2003-03-13',1,1,'','Encargado de limpeza',10,132,NULL,NULL),
	 ('2003-03-17',1,1,'','Axudante de peluquería',10,257,NULL,NULL),
	 ('2003-03-21',1,1,'','Xardineiro, oficial 1ª',10,120,NULL,NULL),
	 ('2003-03-25',1,1,'','Gruista',10,212,NULL,NULL),
	 ('2003-03-25',1,1,'','Alicatador',10,212,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-04-02',1,1,'','Carniceiro/a',10,260,NULL,NULL),
	 ('2003-04-07',1,1,'','Panadeiro/a',10,261,NULL,NULL),
	 ('2003-03-13',1,3,'','Administrativo Dpto. Facturación',10,249,NULL,NULL),
	 ('2003-03-13',1,1,'','Electromecánico',10,249,NULL,NULL),
	 ('2003-04-07',1,2,'','Operario de Planta de Machaqueo',10,249,NULL,NULL),
	 ('2003-04-07',1,1,'','Mecánico Automoción',10,249,NULL,NULL),
	 ('2003-04-09',1,7,'','Xardinero',10,65,NULL,NULL),
	 ('2003-04-14',1,2,'','Albanel oficial de 2ª',10,258,NULL,NULL),
	 ('2003-04-24',1,1,'','Junior Executive',10,259,NULL,NULL),
	 ('2003-04-24',1,2,'','Comercial',10,89,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-04-22',1,2,'','COMERCIAL',10,263,NULL,NULL),
	 ('2003-04-14',1,2,'','COMERCIAL-PROMOTOR',10,264,NULL,NULL),
	 ('2003-03-27',1,4,'','laminador',10,184,NULL,NULL),
	 ('2003-04-01',1,1,'','Conductor',10,77,NULL,NULL),
	 ('2003-04-09',1,1,'','Peón ',10,132,NULL,NULL),
	 ('2003-04-11',1,5,'','Laminador',10,174,NULL,NULL),
	 ('2003-04-24',1,1,'','Comercial',10,207,NULL,NULL),
	 ('2003-05-02',1,1,'','Comercial',10,209,NULL,NULL),
	 ('2003-05-02',1,1,'','Carpinteiro de madeira',10,268,NULL,NULL),
	 ('2003-05-02',1,1,'','Albanel',10,268,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-03-20',1,1,'','Inspector de Gas',10,269,NULL,NULL),
	 ('2003-05-16',1,1,'','Recepcionista balneario',10,116,NULL,NULL),
	 ('2003-05-16',1,3,'','Axudante',10,113,NULL,NULL),
	 ('2003-05-23',1,2,'','Xardineiro',10,77,NULL,NULL),
	 ('2003-05-29',1,2,'','Camareira',10,270,NULL,NULL),
	 ('2003-05-07',1,1,'','Administrativa',10,271,NULL,NULL),
	 ('2003-05-20',1,3,'','Comercial',10,272,NULL,NULL),
	 ('2003-06-02',1,1,'','Peón de arqueoloxía',10,196,NULL,NULL),
	 ('2003-06-02',1,1,'','Comercial',10,260,NULL,NULL),
	 ('2003-06-09',1,2,'','Auxiliar administrativo para perruquería',10,273,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-06-06',1,5,'','Técnico para montaxe e servicio técnico',10,274,NULL,NULL),
	 ('2003-06-12',1,1,'','Laminador de poliester',10,174,NULL,NULL),
	 ('2003-06-06',1,1,'','Aprendiz/a Camareiro/a',10,108,NULL,NULL),
	 ('2003-06-13',1,1,'','Perruqueiro/a',10,275,NULL,NULL),
	 ('2003-06-13',1,1,'','Técnico reparador caixeiros',10,276,NULL,NULL),
	 ('2003-06-13',1,3,'','Axudante de mantenemento',10,278,NULL,NULL),
	 ('2003-06-30',1,2,'','OPERARIO',10,282,NULL,NULL),
	 ('2003-07-09',1,2,'','ESTETICISTA',10,287,NULL,NULL),
	 ('2003-07-08',1,4,'','Camareiro',10,288,NULL,NULL),
	 ('2003-07-08',1,2,'','Axudante Cociña',10,288,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-07-08',1,0,'','Cociñeiro-Parrilleiro',10,288,NULL,NULL),
	 ('2003-05-16',1,1,'','Fontaneiro',10,294,NULL,NULL),
	 ('2003-07-03',1,3,'','Promotora',10,295,NULL,NULL),
	 ('2003-07-04',1,2,'','Instalador-fijador de publicidade exterior',10,296,NULL,NULL),
	 ('2003-07-10',1,2,'','Camareiro/a',10,77,NULL,NULL),
	 ('2003-07-08',1,2,'','Comercial',10,297,NULL,NULL),
	 ('2003-07-14',1,1,'','Pescadeiro/a',10,130,NULL,NULL),
	 ('2003-07-14',1,1,'','Charcuteiro/a',10,130,NULL,NULL),
	 ('2003-07-14',1,1,'','Fruteiro/a',10,130,NULL,NULL),
	 ('2003-07-14',1,1,'','Carniceiro/a',10,130,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-07-18',1,1,'','Pintor',10,77,NULL,NULL),
	 ('2003-07-30',1,1,'','CARPINTEIRO',10,96,NULL,NULL),
	 ('2003-07-30',1,1,'','AXUDANTE CARPINTEIRO',10,96,NULL,NULL),
	 ('2003-07-30',1,2,'','Albanel',10,97,NULL,NULL),
	 ('2003-07-30',1,1,'','Axudante albanel',10,97,NULL,NULL),
	 ('2003-07-29',1,4,'','Carpinteiro de aluminio',10,28,NULL,NULL),
	 ('2003-08-06',1,1,'','Pescadeira',10,72,NULL,NULL),
	 ('2003-08-04',1,3,'','Administrativa',10,299,NULL,NULL),
	 ('2003-08-05',1,3,'','Psicólogo/a',10,300,NULL,NULL),
	 ('2003-08-08',1,2,'','Carpinteiro',10,72,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-08-06',1,3,'','Dependenta-charcutera',10,301,NULL,NULL),
	 ('2003-08-11',1,1,'','Esteticista',10,195,NULL,NULL),
	 ('2003-08-08',1,1,'','Empregada de fogar',10,270,NULL,NULL),
	 ('2003-08-12',1,3,'','Administrativa',10,302,NULL,NULL),
	 ('2003-08-20',1,7,'','Mozo de almacén',10,303,NULL,NULL),
	 ('2003-08-20',1,2,'','Axudante de cociña',10,304,NULL,NULL),
	 ('2003-08-22',1,51,'','Limpiador/a',10,305,NULL,NULL),
	 ('2003-02-25',1,1,'','Montador de muebles',10,231,NULL,NULL),
	 ('2003-08-20',1,3,'','Camarero/a',10,304,NULL,NULL),
	 ('2003-08-28',1,3,'','Dependenta de telefonía',10,295,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-08-19',1,4,'','Azafatas volanteo',10,306,NULL,NULL),
	 ('2003-08-11',1,16,'','Promotor Comercial',10,307,NULL,NULL),
	 ('2003-10-01',1,4,'','caixeira',10,1,NULL,NULL),
	 ('2003-09-15',1,3,'','Camareira',10,310,NULL,NULL),
	 ('2003-09-03',1,1,'','Dependente ciber',10,311,NULL,NULL),
	 ('2003-09-03',1,1,'','Monitor electricidade',10,193,NULL,NULL),
	 ('2003-09-03',1,1,'','Monitor fontanería',10,193,NULL,NULL),
	 ('2003-09-17',1,1,'','OFICIAL ALBANEL',10,312,NULL,NULL),
	 ('2003-09-15',1,5,'','Repartidor con ciclomotor',10,313,NULL,NULL),
	 ('2003-09-03',1,16,'','Coidador/a colexio',10,314,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-09-24',1,1,'','Montador de mobles',10,72,NULL,NULL),
	 ('2003-09-17',1,1,'','Carpinteiro Habilitación Naval',10,225,NULL,NULL),
	 ('2003-09-17',1,15,'','6 OFERTAS  PERSONAL SUPERMERCADO',10,315,NULL,NULL),
	 ('2003-09-25',1,1,'','Monitor/a Coidador/a infantil',10,193,NULL,NULL),
	 ('2003-09-25',1,2,'','Administrativo con inglés',10,116,NULL,NULL),
	 ('2003-09-25',1,1,'','Arquitecto aparexador',10,116,NULL,NULL),
	 ('2003-09-25',1,3,'','Aux. de tráfego',10,116,NULL,NULL),
	 ('2003-09-25',1,5,'','Chófer',10,116,NULL,NULL),
	 ('2003-09-25',1,2,'','Encargado almacén',10,116,NULL,NULL),
	 ('2003-09-25',1,1,'','Carpinteiro/a naval',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-09-25',1,1,'','Técnico de Mantenimiento',10,316,NULL,NULL),
	 ('2003-09-15',1,3,'','Peón impermeabilización',10,317,NULL,NULL),
	 ('2003-09-24',1,1,'','COMERCIAL (PO e OR)',10,274,NULL,NULL),
	 ('2003-09-24',1,1,'','Administrativo/a  (Aprendiz)',10,274,NULL,NULL),
	 ('2003-09-26',1,1,'','Cociñeira',10,318,NULL,NULL),
	 ('2003-09-18',1,5,'','Comercial',10,319,NULL,NULL),
	 ('2003-10-06',1,1,'','Dependente (Aprendiz)',10,320,NULL,NULL),
	 ('2003-03-31',1,2,'','Camarera',10,322,NULL,NULL),
	 ('2003-08-22',1,2,'','Camareira',10,322,NULL,NULL),
	 ('2003-10-10',1,1,'','Perruqueira',10,195,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-10-11',1,1,'','Eneñeiro informático',10,325,NULL,NULL),
	 ('2003-10-21',1,9,'','Limpador/a',10,326,NULL,NULL),
	 ('2003-10-09',1,2,'','Peón para peche de malla na autopista',10,328,NULL,NULL),
	 ('2003-11-04',1,3,'','Aprendiz de guillotinista',10,327,NULL,NULL),
	 ('2003-11-17',1,1,'','Operaria de máquinas planas e overlock',10,113,NULL,NULL),
	 ('2003-11-17',1,1,'','Maquinista de confección',10,113,NULL,NULL),
	 ('2003-08-01',1,5,'','Limpador/a',10,94,NULL,NULL),
	 ('2003-11-05',1,5,'','Dependenta-Charcutera',10,301,NULL,NULL),
	 ('2003-10-28',1,2,'','Vendedor/a',10,338,NULL,NULL),
	 ('2003-11-03',1,1,'','OFICIAL 1ª SOLDADURA',10,28,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2003-11-06',1,2,'','Mozo almacén',10,339,NULL,NULL),
	 ('2003-11-06',1,1,'','COMISIONISTA',10,298,NULL,NULL),
	 ('2003-11-14',1,4,'','Peón',10,340,NULL,NULL),
	 ('2003-11-19',1,1,'','Comercial a comisión',10,341,NULL,NULL),
	 ('2003-11-19',1,2,'','Promotor/a',10,342,NULL,NULL),
	 ('2003-12-03',1,2,'','Escaiolista',10,343,NULL,NULL),
	 ('2003-12-03',1,6,'','Auxiliar de xeriatría, de domicilio, xerocultura',10,344,NULL,NULL),
	 ('2003-06-17',1,2,'','Comercial',10,277,NULL,NULL),
	 ('2004-01-08',1,4,'','Empastador/a',10,174,NULL,NULL),
	 ('2004-01-08',1,2,'','Axudante de cociña e barra',10,424,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-01-15',1,5,'','Empastador/a',10,116,NULL,NULL),
	 ('2004-01-11',1,4,'','Teleoperadoras',10,425,NULL,NULL),
	 ('2004-01-28',1,3,'','Administrativo/a',10,426,NULL,NULL),
	 ('2004-01-22',1,4,'','Auxiliar administrativa',10,113,NULL,NULL),
	 ('2004-01-27',1,2,'','Carpinteiro ',10,174,NULL,NULL),
	 ('2004-01-28',1,2,'','Teleoperadora',10,425,NULL,NULL),
	 ('2004-02-12',1,1,'','OPERARIO DE CHAPA',10,28,NULL,NULL),
	 ('2004-01-20',1,3,'','Gestor comercial',10,434,NULL,NULL),
	 ('2004-02-04',1,3,'','Peón ou oficial de 2ª albanel',10,80,NULL,NULL),
	 ('2004-02-05',1,1,'','Axudante de cociña',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-02-05',1,1,'','Cocinero',10,116,NULL,NULL),
	 ('2004-02-06',1,1,'','Fontanero-calefactor',10,435,NULL,NULL),
	 ('2004-02-11',1,2,'','Peón electricista',10,136,NULL,NULL),
	 ('2004-02-12',1,1,'','Mecanizado,soldadura,chapa...',10,28,NULL,NULL),
	 ('2004-02-19',1,2,'','Executivo comercial',10,87,NULL,NULL),
	 ('2004-02-17',1,1,'','Promotora de Beleza',10,321,NULL,NULL),
	 ('2003-02-24',1,1,'','Camareiro',10,116,NULL,NULL),
	 ('2004-02-25',1,1,'','Pintor',10,77,NULL,NULL),
	 ('2004-03-12',1,1,'','Camareiro',10,445,NULL,NULL),
	 ('2004-04-12',1,2,'','Electricista',10,117,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-04-30',1,1,'','Charcutero/a',10,117,NULL,NULL),
	 ('2004-03-11',1,1,'','Axudante de cociña',10,324,NULL,NULL),
	 ('2004-04-11',1,1,'','Carpinteiro',10,174,NULL,NULL),
	 ('2004-04-01',1,1,'','Operario de limpeza',10,197,NULL,NULL),
	 ('2004-04-02',1,1,'','Laminadores/as',10,116,NULL,NULL),
	 ('2004-04-05',1,1,'','Comerciales',10,161,NULL,NULL),
	 ('2004-04-06',1,1,'','Peón/oficial da construcción',10,117,NULL,NULL),
	 ('2004-04-07',1,1,'','Cocineiro',10,116,NULL,NULL),
	 ('2004-04-13',1,4,'','Peón para recollida escombros',10,435,NULL,NULL),
	 ('2004-04-14',1,1,'','Marmolista oficial ou peón',10,446,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-04-15',1,1,'','Fregadora',10,447,NULL,NULL),
	 ('2004-04-15',1,1,'','Axudante de camareira',10,447,NULL,NULL),
	 ('2004-04-16',1,1,'','Recepcionista',10,116,NULL,NULL),
	 ('2004-04-20',1,1,'','Cociñeiro',10,77,NULL,NULL),
	 ('2004-04-30',1,2,'','COMERCIAL',10,272,NULL,NULL),
	 ('2004-04-21',1,1,'','FRESADOR',10,28,NULL,NULL),
	 ('2004-06-04',1,2,'','Xardineiro',10,120,NULL,NULL),
	 ('2004-06-04',1,4,'','Comercial',10,272,NULL,NULL),
	 ('2004-04-23',1,2,'','Limpiadora',10,459,NULL,NULL),
	 ('2003-04-20',1,2,'','Operario- aprendiz',10,184,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-05-10',1,4,'','Mozo almacén',10,460,NULL,NULL),
	 ('2004-05-14',1,1,'','Manipulador',10,461,NULL,NULL),
	 ('2004-05-18',0,3,'','Promotora',10,462,NULL,NULL),
	 ('2004-05-20',1,1,'','Carpinteiro Naval',10,116,NULL,NULL),
	 ('2004-06-28',1,4,'','Auxiliar administrativo/a',10,463,NULL,NULL),
	 ('2004-06-30',1,6,'','Limpadora',10,464,NULL,NULL),
	 ('2004-07-02',1,1,'','Peón carga e descarga',10,465,NULL,NULL),
	 ('2004-06-17',1,1,'','Repartidor ',10,251,NULL,NULL),
	 ('2004-06-28',1,1,'','Economista-auditor',10,221,NULL,NULL),
	 ('2004-06-30',1,4,'','Delineante de construccción',10,471,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-07-01',1,1,'','Operario de ponte-guindastre',10,116,NULL,NULL),
	 ('2004-07-01',1,1,'','Maitre ',10,116,NULL,NULL),
	 ('2004-07-01',1,1,'','Auxiliar de axuda a domicilio',10,346,NULL,NULL),
	 ('2004-07-26',1,2,'','Dependenta de Kiosko',10,472,NULL,NULL),
	 ('2004-07-27',1,1,'','Axudante de repostería',10,472,NULL,NULL),
	 ('2004-07-30',1,0,'','Cociñeira (Tapería sacacorchos)',10,298,NULL,NULL),
	 ('2004-07-30',1,0,'','Axudante camareiro (Tapería Sacacorchos)',10,298,NULL,NULL),
	 ('2004-07-22',1,1,'','Escaiolista',10,473,NULL,NULL),
	 ('2004-07-22',1,2,'','Albanel oficial-Fontaneiro-Calefactor',10,474,NULL,NULL),
	 ('2004-07-02',1,1,'','Estilista',10,475,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-07-02',1,1,'','Champunier',10,475,NULL,NULL),
	 ('2004-07-02',1,1,'','Manicurista',10,475,NULL,NULL),
	 ('2004-07-23',1,3,'','FPI, FPII Fontanería',10,476,NULL,NULL),
	 ('2004-07-29',1,1,'','Operarios ',10,116,NULL,NULL),
	 ('2004-07-29',1,1,'','Almacenero',10,116,NULL,NULL),
	 ('2004-08-04',1,3,'','Auxiliar Técnico en Electrónica',10,463,NULL,NULL),
	 ('2004-07-27',1,3,'','Dependenta para tenda de telefonía',10,477,NULL,NULL),
	 ('2004-09-10',1,2,'','Teleoperador/a',10,425,NULL,NULL),
	 ('2004-09-13',1,1,'','Ludotecario/a',10,253,NULL,NULL),
	 ('2004-09-07',1,1,'','Carpinteiro',10,174,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-09-28',1,5,'','Peón arqueoloxía',10,196,NULL,NULL),
	 ('2004-09-23',1,1,'','Comercial (inmobiliaria)',10,479,NULL,NULL),
	 ('2004-09-23',1,1,'','Modista/Costureira',10,480,NULL,NULL),
	 ('2004-09-27',1,1,'','Dependenta (Educación social)',10,481,NULL,NULL),
	 ('2004-09-27',1,1,'','Comercial',10,116,NULL,NULL),
	 ('2004-09-27',1,1,'','Operario (granito/construcción)',10,116,NULL,NULL),
	 ('2004-10-04',1,1,'','Estilista-perruqueira',10,195,NULL,NULL),
	 ('2004-10-15',1,1,'','Ludotecario',10,253,NULL,NULL),
	 ('2004-10-18',1,1,'','Delineante',10,116,NULL,NULL),
	 ('2004-10-26',1,1,'','Televendedoras',10,425,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2004-12-15',1,1,'','Vixiante instalacións',10,485,NULL,NULL),
	 ('2004-11-03',1,1,'','Escaparatista',10,129,NULL,NULL),
	 ('2004-11-02',1,1,'','Educadora infantil',10,486,NULL,NULL),
	 ('2004-11-03',1,1,'','Operario de lavado de coches',10,487,NULL,NULL),
	 ('2004-12-03',1,1,'','oficial albanel',10,488,NULL,NULL),
	 ('2004-12-03',1,4,'','peón albanel',10,488,NULL,NULL),
	 ('2004-12-09',1,1,'','Administrativo dpto compras',10,489,NULL,NULL),
	 ('2004-08-26',1,1,'','Delineante',10,471,NULL,NULL),
	 ('2005-01-03',1,4,'','Teleoperadora',10,490,NULL,NULL),
	 ('2005-01-03',1,3,'','Chófer',10,471,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-01-03',1,4,'','Dependenta',10,471,NULL,NULL),
	 ('2005-01-05',1,3,'','Xefe/a de vendas',10,471,NULL,NULL),
	 ('2005-01-05',1,1,'','Comercial inmobiliaria',10,479,NULL,NULL),
	 ('2005-01-11',1,2,'','Comercial de material hospitalario',10,489,NULL,NULL),
	 ('2005-01-13',1,1,'','Electricista',10,80,NULL,NULL),
	 ('2005-01-18',1,4,'','Dependenta-comercial',10,491,NULL,NULL),
	 ('2005-01-14',1,1,'','Comercial de ventas',10,492,NULL,NULL),
	 ('2005-01-19',1,1,'','Técnico de iluminación',10,476,NULL,NULL),
	 ('2005-01-19',1,3,'','Oficial almacén',10,476,NULL,NULL),
	 ('2005-01-19',1,1,'','Enxeñeiro electrónico',10,476,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-01-19',1,1,'','Comercial de telefonía fixa',10,295,NULL,NULL),
	 ('2005-01-25',1,1,'','Comercial',10,497,NULL,NULL),
	 ('2005-01-27',1,3,'','Administrativa',10,498,NULL,NULL),
	 ('2005-02-01',1,2,'','Axudante de cociña',10,500,NULL,NULL),
	 ('2005-02-11',1,1,'','Repartidor dependente',10,489,NULL,NULL),
	 ('2005-02-11',1,1,'','Delineante sector construcción',10,489,NULL,NULL),
	 ('2005-02-17',1,1,'','Comercial',10,116,NULL,NULL),
	 ('2005-02-18',1,1,'','Auxiliar electricista',10,80,NULL,NULL),
	 ('2005-02-23',1,3,'','Administrativa',10,498,NULL,NULL),
	 ('2005-03-01',1,1,'','Técnico comercio exterior',10,116,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-02-01',1,2,'','Psicóloga',10,300,NULL,NULL),
	 ('2005-03-07',1,1,'','Axudante de estética',10,502,NULL,NULL),
	 ('2005-03-11',1,3,'','Carpinteiro de ribeira',10,174,NULL,NULL),
	 ('2005-03-15',1,2,'','Repartidor',10,503,NULL,NULL),
	 ('2005-03-15',1,3,'','FP  informática',10,503,NULL,NULL),
	 ('2005-03-11',1,1,'','Consultor',10,504,NULL,NULL),
	 ('2005-03-22',1,2,'','Operario de almacén',10,471,NULL,NULL),
	 ('2005-03-22',1,2,'','Operaria de limpeza',10,471,NULL,NULL),
	 ('2005-03-21',1,3,'','Camareiro/a',10,508,NULL,NULL),
	 ('2005-04-06',1,1,'','Auxiliar de axuda a domicilio',10,523,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-04-25',1,1,'','Operarias de limpeza',10,526,NULL,NULL),
	 ('2005-05-02',1,1,'','Mozo/a de almacén',10,303,NULL,NULL),
	 ('2005-05-02',1,4,'','Administrativo/a',10,303,NULL,NULL),
	 ('2005-05-02',1,1,'','Dependenta-charcutera',10,301,NULL,NULL),
	 ('2005-05-19',1,1,'','Aprendiz fontanería',10,114,NULL,NULL),
	 ('2005-05-24',1,1,'','Mecánico electricista',10,114,NULL,NULL),
	 ('2005-05-24',1,2,'','Técnico de mantenimento',10,114,NULL,NULL),
	 ('2005-05-24',1,1,'','Peón fresador',10,114,NULL,NULL),
	 ('2005-05-25',1,1,'','Técnico mecánica electricidad',10,527,NULL,NULL),
	 ('2005-05-31',1,1,'','Docente curso Inserción laboral',10,528,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-06-08',1,2,'','Técnico de Mantenimento',10,529,NULL,NULL),
	 ('2005-06-03',1,2,'','Instalador de gas-fontaneiro',10,126,NULL,NULL),
	 ('2005-06-13',1,7,'','Limpadora de obra',10,530,NULL,NULL),
	 ('2005-06-20',1,1,'','Soldador (automoción)',10,128,NULL,NULL),
	 ('2005-06-14',1,3,'','Técnico/a de inventario',10,531,NULL,NULL),
	 ('2005-06-20',1,2,'','Aux. Administrativo/a',10,521,NULL,NULL),
	 ('2005-06-20',1,1,'','Aux. Clínica/laboratorio/enfermería',10,521,NULL,NULL),
	 ('2005-06-20',1,1,'','Limpadora',10,521,NULL,NULL),
	 ('2005-06-22',1,6,'','Empastador',10,152,NULL,NULL),
	 ('2005-06-21',1,1,'','Podólogo/a',10,210,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-07-06',1,3,'','Oficial electricista',10,552,NULL,NULL),
	 ('2005-07-07',1,3,'','Oficial electricista',10,553,NULL,NULL),
	 ('2005-07-08',1,3,'','Electricistas/electrónicos',10,130,NULL,NULL),
	 ('2005-07-01',1,3,'','Oficial 1ª e 2ª',10,554,NULL,NULL),
	 ('2005-07-07',1,3,'','Dependenta',10,555,NULL,NULL),
	 ('2005-07-11',1,1,'','Caldereiro/Soldador',10,130,NULL,NULL),
	 ('2005-06-23',1,1,'','Promotores/as Stand',10,557,NULL,NULL),
	 ('2005-06-15',1,5,'','Operario de producción',10,118,NULL,NULL),
	 ('2005-07-20',1,1,'','Auxiliar Peluquería',10,475,NULL,NULL),
	 ('2005-07-13',1,1,'','Suministro combustible e explanada',10,187,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-07-13',1,3,'','Responsable Dpto. Recambios',10,187,NULL,NULL),
	 ('2005-07-06',1,1,'','Aux. Fábrica',10,251,NULL,NULL),
	 ('2005-07-22',1,1,'','Carniceiro/a',10,130,NULL,NULL),
	 ('2005-07-26',1,1,'','Consultor en calidade, medio ambiente e innovación',10,558,NULL,NULL),
	 ('2005-07-18',1,1,'','Auxiliar de axuda á domicilio',10,430,NULL,NULL),
	 ('2005-08-08',1,3,'','Aux. Administrativo/a',10,562,NULL,NULL),
	 ('2005-09-08',1,3,'','Técnico de empleo',10,567,NULL,NULL),
	 ('2005-09-05',1,1,'','Inxectador de poliuretano',10,130,NULL,NULL),
	 ('2005-09-14',1,2,'','Montador de mobiliario',10,569,NULL,NULL),
	 ('2005-09-13',1,7,'','Peón',10,570,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-09-15',1,7,'','Axudante Peón/Solador',10,571,NULL,NULL),
	 ('2005-09-19',1,1,'','Mariñeiro',10,187,NULL,NULL),
	 ('2005-09-23',1,1,'','Técnico de confección (Ourense)',10,573,NULL,NULL),
	 ('2005-09-29',1,2,'','Psicóloga',10,300,NULL,NULL),
	 ('2005-09-28',1,2,'','Laminador/tapiceiro/montador',10,129,NULL,NULL),
	 ('2005-10-10',1,1,'','Camareiro-encargado',10,580,NULL,NULL),
	 ('2005-10-13',1,1,'','Mecánico de camión',10,130,NULL,NULL),
	 ('2005-10-13',1,4,'','Carpinteiro naval',10,130,NULL,NULL),
	 ('2005-05-25',1,5,'','Carpinteiro-montador',10,174,NULL,NULL),
	 ('2005-05-09',1,3,'','Laminador',10,153,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-08-30',1,1,'','Asesor inversión personal',10,84,NULL,NULL),
	 ('2005-02-02',1,1,'','asesor',10,84,NULL,NULL),
	 ('2005-08-22',1,3,'','Peón para resinas e fibra',10,612,NULL,NULL),
	 ('2005-08-18',1,1,'','FPI/FP II Electricidade-Mecánica',10,613,NULL,NULL),
	 ('2005-08-18',1,2,'','Recepcionista almacén',10,613,NULL,NULL),
	 ('2005-08-10',1,1,'','Chófer con carné C',10,503,NULL,NULL),
	 ('2005-08-10',1,1,'','Diplom. documentación para biblioteca científica',10,614,NULL,NULL),
	 ('2005-10-19',1,3,'','Promotor/a de teléfonos móbiles',10,615,NULL,NULL),
	 ('2005-10-19',1,1,'','Profesor autoescola',10,616,NULL,NULL),
	 ('2005-10-13',1,1,'','Aprendiz de escaiolista',10,473,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2005-11-08',1,1,'','Recepcionista biingue francés',10,619,NULL,NULL),
	 ('2005-11-17',1,2,'','Carretilleiro (retráctil)',10,619,NULL,NULL),
	 ('2005-11-22',1,3,'','Limpadora (oficinas)',10,623,NULL,NULL),
	 ('2005-11-10',1,1,'','Carpintero naval',10,120,NULL,NULL),
	 ('2004-03-03',1,1,'','Mecánico de mantenemento, OFicial 2ª ',10,85,NULL,NULL),
	 ('2005-12-07',1,3,'','Auxiliar de Servicios',10,626,NULL,NULL),
	 ('2005-12-14',1,1,'','Comerciais',10,207,NULL,NULL),
	 ('2005-12-16',1,2,'','Taquillero/a',10,629,NULL,NULL),
	 ('2005-12-16',1,3,'','Persoal de marinería',10,187,NULL,NULL),
	 ('2006-01-02',1,4,'','Peón albanel',10,633,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-01-02',1,4,'','Montador electric. e iluminac. de centros comerc.',10,634,NULL,NULL),
	 ('2006-01-10',1,4,'','Optica/Aux.Optica',10,635,NULL,NULL),
	 ('2006-01-16',1,1,'','Educadora',10,636,NULL,NULL),
	 ('2006-01-24',1,2,'','Empastador-laminador',10,651,NULL,NULL),
	 ('2006-01-30',1,1,'','Jefe de obra',10,225,NULL,NULL),
	 ('2006-02-17',1,1,'','Mantenemento e reparación',10,187,NULL,NULL),
	 ('2006-02-17',1,2,'','Comercial de servizos de consultoría',10,652,NULL,NULL),
	 ('2006-02-17',1,2,'','Modista',10,653,NULL,NULL),
	 ('2006-02-06',1,1,'','Asistenta servizo doméstico',10,654,NULL,NULL),
	 ('2006-02-01',1,2,'','Promotor/a',10,295,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-02-08',1,1,'','Traballadora social',10,655,NULL,NULL),
	 ('2006-02-08',1,2,'','Auxiliar de clínica',10,655,NULL,NULL),
	 ('2006-02-14',1,1,'','Peón albanel',10,633,NULL,NULL),
	 ('2006-02-17',1,3,'','Comercial',10,657,NULL,NULL),
	 ('2006-02-28',1,1,'','Coordinador/a',10,661,NULL,NULL),
	 ('2006-03-10',1,1,'','Asistenta interna para Sanxenxo',10,415,NULL,NULL),
	 ('2006-03-01',1,2,'','Perruqueiro/a',10,663,NULL,NULL),
	 ('2006-03-06',1,3,'','Administrativa',10,303,NULL,NULL),
	 ('2006-03-13',1,3,'','Carpinteiro oficial 1º, 2º',10,174,NULL,NULL),
	 ('2006-03-13',1,4,'','Electricista',10,664,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-03-17',1,1,'','Oficial  1ª ',10,665,NULL,NULL),
	 ('2006-03-17',1,2,'','Oficial 2ª',10,665,NULL,NULL),
	 ('2006-03-17',1,2,'','Peón aprendiz',10,665,NULL,NULL),
	 ('2006-03-21',1,1,'','Auxiliar administrativa',10,666,NULL,NULL),
	 ('2006-03-22',1,1,'','Comercial',10,667,NULL,NULL),
	 ('2006-03-24',0,6,'','Comercial de seguros',10,668,NULL,NULL),
	 ('2006-04-05',1,4,'','Aux. administrativo/a',10,1001,NULL,NULL),
	 ('2006-04-19',1,1,'','Docente de Física, Química e Matemáticas',10,1002,NULL,NULL),
	 ('2006-04-19',1,1,'','Docente de inglés e francés',10,1002,NULL,NULL),
	 ('2006-04-10',1,1,'','Aux. de axuda a domicilio',10,1003,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-04-10',1,1,'','Dependenta charcutería',10,497,NULL,NULL),
	 ('2006-05-09',1,1,'','Monitor de taichi',10,507,NULL,NULL),
	 ('2006-04-18',1,4,'','Dependenta conxelados',10,497,NULL,NULL),
	 ('2006-04-18',1,4,'','Camareiro/a',10,1004,NULL,NULL),
	 ('2006-04-21',1,10,'','Camareiro/a',10,627,NULL,NULL),
	 ('2006-04-21',1,6,'','Axudante de cociña',10,627,NULL,NULL),
	 ('2006-05-12',1,1,'','Docente de inglés e francés',10,1002,NULL,NULL),
	 ('2006-06-29',1,4,'','Auxiliar de limpeza',10,1041,NULL,NULL),
	 ('2006-07-06',1,1,'','Dependente de comercio',10,613,NULL,NULL),
	 ('2006-04-21',1,1,'','Repartidor/instalador de mobles',10,120,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-06-21',1,1,'','Fisioterapeuta',10,415,NULL,NULL),
	 ('2006-05-03',1,15,'','Asesor financieiro',10,1016,NULL,NULL),
	 ('2006-05-05',1,10,'','Manipuladoras de peixe fresco e conxelado',10,129,NULL,NULL),
	 ('2006-05-08',1,2,'','Veterinarios para promociones',10,1017,NULL,NULL),
	 ('2006-05-08',1,3,'','Promotoras',10,1017,NULL,NULL),
	 ('2006-05-10',1,1,'','Asistenta o interna',10,654,NULL,NULL),
	 ('2006-05-11',1,25,'','Camareiros/as',10,654,NULL,NULL),
	 ('2006-04-19',1,1,'','Perruqueira',10,1024,NULL,NULL),
	 ('2006-04-25',1,3,'','Comercial',10,1020,NULL,NULL),
	 ('2006-05-15',1,1,'','Socio-Empleado',10,1021,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-06-26',1,3,'','2 puestos ofertados y 8 enviados',10,1025,NULL,NULL),
	 ('2006-06-23',1,15,'','Operario especialista',10,131,NULL,NULL),
	 ('2006-06-20',1,4,'','Limpadora',10,521,NULL,NULL),
	 ('2006-05-26',1,2,'','Operaria Producción (con discapacidade)',10,227,NULL,NULL),
	 ('2006-05-31',1,2,'','Comercial de seguros',10,668,NULL,NULL),
	 ('2006-06-15',1,3,'','Limpadora',10,464,NULL,NULL),
	 ('2006-06-27',1,0,'','Operario lavado de coches',10,487,NULL,NULL),
	 ('2006-06-20',1,2,'','Mariñeiro/a',10,187,NULL,NULL),
	 ('2006-06-26',1,6,'','un de exemplo',10,1025,NULL,NULL),
	 ('2006-06-23',1,15,'','Operario',10,131,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-06-27',1,2,'','werqwr',10,1025,NULL,NULL),
	 ('2006-05-16',1,2,'','Técnico de empleo',10,567,NULL,NULL),
	 ('2006-04-19',1,3,'','Animador/a coidador/a infantil',10,486,NULL,NULL),
	 ('2006-06-28',1,0,'','Auxiliar de clínica',10,655,NULL,NULL),
	 ('2006-06-28',1,3,'','Secretaria/Recepcionista',10,1005,NULL,NULL),
	 ('2006-05-30',1,3,'','Maquetista',10,1019,NULL,NULL),
	 ('2006-05-10',1,6,'','Dependenta de Tenda Levis',10,1018,NULL,NULL),
	 ('2006-03-16',1,21,'','Varios',10,658,NULL,NULL),
	 ('2006-07-06',1,0,'','Auxiliar de axuda a domicilio',10,1049,NULL,NULL),
	 ('2006-07-12',1,0,'','Mecánico de motos e coches',10,1050,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-06-28',1,0,'','Teleoperadora',10,1051,NULL,NULL),
	 ('2006-07-06',1,0,'','Médico',10,1052,NULL,NULL),
	 ('2006-07-06',1,2,'','Dependenta de conxelados',10,497,NULL,NULL),
	 ('2006-07-24',1,0,'','Manicurista',10,475,NULL,NULL),
	 ('2006-07-27',1,0,'','Técnico comercial',10,1055,NULL,NULL),
	 ('2006-07-20',1,2,'','Cocinero/a',10,1041,NULL,NULL),
	 ('2006-07-19',1,1,'','Mecánico Industrial',10,1056,NULL,NULL),
	 ('2006-07-17',1,0,'','Limpadora',10,1057,NULL,NULL),
	 ('2006-07-17',1,2,'','Mecánico Automoción',10,1057,NULL,NULL),
	 ('2006-08-01',1,2,'','Chófer camión cisterna',10,612,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-08-01',1,1,'','Operario mantenemento parques eólicos',10,612,NULL,NULL),
	 ('2006-07-20',1,0,'','Esteticista',10,1059,NULL,NULL),
	 ('2006-08-02',1,0,'','Empregada do fogar',10,415,NULL,NULL),
	 ('2006-08-08',1,2,'','Camareiro/a',10,1060,NULL,NULL),
	 ('2006-08-10',1,1,'','Electricista de mantenemento',10,566,NULL,NULL),
	 ('2006-08-10',1,2,'','Lcdo/a. Hª do Arte',10,1003,NULL,NULL),
	 ('2006-09-05',1,2,'','Dependente/a',10,1061,NULL,NULL),
	 ('2006-09-05',1,0,'','Comercial grandes contas',10,1062,NULL,NULL),
	 ('2006-08-21',1,0,'','Auxiliar Administrativa c/minusvalía',10,626,NULL,NULL),
	 ('2006-08-25',1,2,'','Axudante cociña',10,1063,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-08-28',1,0,'','Responsable de marketing',10,1064,NULL,NULL),
	 ('2006-08-28',1,0,'','Comerciais de expansión',10,1065,NULL,NULL),
	 ('2006-09-08',1,4,'','Asesor/a Financieiro/a',10,1016,NULL,NULL),
	 ('2006-09-26',1,1,'','Caixeiro-repoñedor',10,613,NULL,NULL),
	 ('2006-09-27',1,1,'','Técnico de formación',10,567,NULL,NULL),
	 ('2006-09-15',1,0,'','Fisioterapeuta',10,1068,NULL,NULL),
	 ('2006-09-19',1,0,'','Camareiro/a de sala con experiencia en carta',10,566,NULL,NULL),
	 ('2006-09-29',1,5,'','Operario de producción',10,116,NULL,NULL),
	 ('2006-09-14',1,0,'','Teleoperadores/as emisión/recepción de llamadas',10,494,NULL,NULL),
	 ('2006-09-14',1,0,'','Televendedores/as',10,494,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-09-14',1,1,'','Informático/a soporte técnico',10,494,NULL,NULL),
	 ('2006-09-11',1,2,'','Auxiliar - ordenanza',10,1071,NULL,NULL),
	 ('2006-09-08',1,1,'','Administrativa',10,1072,NULL,NULL),
	 ('2006-09-07',1,2,'','Instalador de subpavimentos e pavimentos',10,225,NULL,NULL),
	 ('2006-09-19',1,0,'','Troquelador',10,566,NULL,NULL),
	 ('2006-09-19',1,0,'','Responsable de parrilla',10,566,NULL,NULL),
	 ('2006-09-19',1,0,'','Manicurista',10,566,NULL,NULL),
	 ('2006-09-19',1,0,'','Laminador/a de poliester',10,566,NULL,NULL),
	 ('2006-09-27',1,0,'','Director/a coro 3ª idade',10,1070,NULL,NULL),
	 ('2006-08-24',1,0,'','Terapeuta ocupacional',10,352,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-09-19',1,1,'','Encofrador',10,566,NULL,NULL),
	 ('2006-09-19',1,2,'','Mozo de almacén',10,566,NULL,NULL),
	 ('2006-09-19',1,0,'','Operario puente grúa',10,566,NULL,NULL),
	 ('2006-09-19',1,0,'','Chorreador de pintura naval',10,566,NULL,NULL),
	 ('2006-10-03',1,0,'','Comercial',10,1074,NULL,NULL),
	 ('2006-09-19',1,2,'','Soldador (ofic. 2ª/3ª)',10,566,NULL,NULL),
	 ('2006-09-19',1,1,'','Técnicos de montaxe e axuste en ascensores',10,566,NULL,NULL),
	 ('2006-09-21',1,0,'','Técnico en alarmas',10,1075,NULL,NULL),
	 ('2006-11-09',1,0,'','Profesos particular a domicilio',10,1076,NULL,NULL),
	 ('2006-10-18',1,0,'','Fontaneiro-Calefactor',10,435,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-10-24',1,0,'','Xestor Financieiro',10,116,NULL,NULL),
	 ('2006-10-24',1,3,'','Recepcionista-Administrativa',10,116,NULL,NULL),
	 ('2006-10-30',1,2,'','Dependenta de perfumería',10,566,NULL,NULL),
	 ('2006-11-08',1,0,'','Auxiliar de perruquería',10,1079,NULL,NULL),
	 ('2006-10-30',1,0,'','Técnica en fotodepilación',10,1081,NULL,NULL),
	 ('2006-10-09',1,1,'','Operario para medición de toldos',10,601,NULL,NULL),
	 ('2006-11-08',1,0,'','Montador',10,129,NULL,NULL),
	 ('2006-11-08',1,0,'','Laminador',10,129,NULL,NULL),
	 ('2006-11-09',1,0,'','Promotor montador de publicidade',10,1069,NULL,NULL),
	 ('2006-11-09',1,0,'','Auxiliar de clínica',10,655,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-11-09',1,0,'','Aux. de axuda a domicilio',10,655,NULL,NULL),
	 ('2006-11-23',1,0,'','Asesor pedagóxico para Centro Comercial',10,1084,NULL,NULL),
	 ('2006-11-27',1,1,'','Contable',10,116,NULL,NULL),
	 ('2006-11-27',1,0,'','Tradutor francés/portugués',10,116,NULL,NULL),
	 ('2006-11-29',1,0,'','Teleoperadores/as',10,566,NULL,NULL),
	 ('2006-12-12',1,0,'','Comercial sector telecomunicaciones',10,1085,NULL,NULL),
	 ('2006-11-30',1,2,'','Enxeñeiro industrial',10,463,NULL,NULL),
	 ('2006-12-20',1,0,'','Becario/a (Santiago C.)',10,1086,NULL,NULL),
	 ('2006-11-29',1,0,'','Auxiliar do servizo de limpeza',10,1041,NULL,NULL),
	 ('2006-11-29',1,1,'','Cociñeiro',10,1041,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2006-12-22',1,0,'','Administrativo/a (Porriño)',10,566,NULL,NULL),
	 ('2006-12-22',1,0,'','Operarios/as',10,566,NULL,NULL),
	 ('2007-12-01',1,0,'','Operario de lavado de coches',10,487,NULL,NULL),
	 ('2006-10-20',1,0,'','Docente metodoloxía da formación aberta e a distancia',10,507,NULL,NULL),
	 ('2007-01-10',1,1,'','Operaria tintorería',10,632,NULL,NULL),
	 ('2007-01-12',1,0,'','Montador',10,174,NULL,NULL),
	 ('2007-01-12',1,0,'','Laminador/a',10,174,NULL,NULL),
	 ('2007-01-26',1,0,'','Dependente/a-Charcutero/a',10,301,NULL,NULL),
	 ('2007-01-26',1,0,'','Asesor/a de seguros',10,525,NULL,NULL),
	 ('2007-01-18',1,0,'','Comercial',10,89,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-01-19',1,2,'','Operario automoción',10,114,NULL,NULL),
	 ('2007-01-02',1,5,'','Axudante de cociña',10,1090,NULL,NULL),
	 ('2007-01-08',1,1,'','Operario de lavandería',10,136,NULL,NULL),
	 ('2007-01-08',1,0,'','Planchadora',10,136,NULL,NULL),
	 ('2007-01-02',1,0,'','Docente de marketing e ventas',10,1091,NULL,NULL),
	 ('2007-01-11',1,0,'','Técnico superior en estética',10,1081,NULL,NULL),
	 ('2007-01-29',1,0,'','Enquisadores',10,1093,NULL,NULL),
	 ('2007-01-29',1,0,'','Técnico (telecomunicacións)',10,1092,NULL,NULL),
	 ('2007-01-26',1,1,'','Auxiliar de axuda a domicilio',10,1003,NULL,NULL),
	 ('2007-02-05',1,1,'','Axudante de cociña',10,1089,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-02-08',1,0,'Disponibilidade para toda Galicia e norte de Portugal.','Técnico (electrónica)',10,1095,NULL,NULL),
	 ('2007-02-22',1,5,'','camghghk',10,1025,NULL,NULL),
	 ('2007-02-26',5,3,'E para traballar na preparación da feira  de enerxías renovables que se vai celebrar en xuño.','Consultora de medio ambiente',10,558,NULL,NULL),
	 ('2007-02-23',1,2,'Empresa automoción','Carretillera',10,136,NULL,NULL),
	 ('2007-02-22',1,1,'1 ano experiencia en inspeccións','Enxeñeiro técnico/superior',10,1096,NULL,NULL),
	 ('2007-02-22',1,1,'','Auxiliar administrativo/a',10,1096,NULL,NULL),
	 ('2007-02-27',1,0,'(Pescadeiro con ambición comercial)','Xestor comercial',10,1097,NULL,NULL),
	 ('2007-02-01',3,1,'','Comercial para divulgación',10,1003,NULL,NULL),
	 ('2007-02-07',1,0,'','Dependenta de conxelados',10,497,NULL,NULL),
	 ('2007-02-28',1,0,'A oferta é dun mes a proba e logo contrato indefinido','Carpinteiro de Ribera',10,1098,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-02-28',1,0,'','Auxiliar de axuda a domicilio',10,1049,NULL,NULL),
	 ('2007-02-27',1,1,'','Operario de limpeza industrial',10,114,NULL,NULL),
	 ('2007-03-01',1,1,'','Auxiliar de axuda a domicilio',10,655,NULL,NULL),
	 ('2007-03-02',1,0,'','Becario informática',10,16,NULL,NULL),
	 ('2007-03-12',1,0,'','Graduado/a Social para Dpto. Persoal',10,114,NULL,NULL),
	 ('2007-03-26',1,0,'Controlar as máquinas onde se realiza o tecido, cargalas','Tecedor',10,1103,NULL,NULL),
	 ('2007-03-26',1,0,'Condutora para repartos con vehículo propio media xornada','Condutora para reparto',10,1104,NULL,NULL),
	 ('2007-04-25',3,4,'Oferta xestionada por  Susana BIAL','',10,1106,NULL,NULL),
	 ('2007-04-17',1,2,'Solicítase ciclo medio de administración','Auxiliar administrativa para centralita',10,114,NULL,NULL),
	 ('2007-04-03',1,0,'Non conseguimos falar coa empresa para esta oferta','Dependente/a',10,1107,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-04-10',1,0,'Non se envían candidatos','Carretillero- carretilla retractil',10,114,NULL,NULL),
	 ('2007-04-10',6,0,'','Becario de administración',10,16,NULL,NULL),
	 ('2007-04-10',6,0,'','Becario desarrollos',10,16,NULL,NULL),
	 ('2007-04-17',6,0,'Paso a oferta a Susana Bial, pero non hai candidatos dispoñibles','Fontaneiro',10,1108,NULL,NULL),
	 ('2007-04-13',1,1,'E para unha empresa en Redondela. Xornada unha semana pola  tarde e outra pola mañana.','Cortadora textil',10,489,NULL,NULL),
	 ('2007-04-18',1,0,'','Odontólogo/a',10,1110,NULL,NULL),
	 ('2007-04-19',1,0,'Non hai ningún candidato/a na base de datos','Enxeñeiro naval',10,225,NULL,NULL),
	 ('2007-05-24',3,9,'','Monitor/a de tempo libre',10,1112,NULL,NULL),
	 ('2007-06-04',0,9,'','Inspector-peritación vehículos',10,1111,NULL,NULL),
	 ('2007-05-23',0,7,'Temporal sen definir, a tempo parcial: só 6 horas semanais. Enviamos tamén a persoas interesadas do grupo de lavandería (Actívate)','',81,248,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-05-28',0,0,'','Repartidor tenda pinturas',10,566,NULL,NULL),
	 ('2007-05-28',0,0,'','Fontanero',10,566,NULL,NULL),
	 ('2007-05-28',0,2,'','Dependente tenda decoración',10,566,NULL,NULL),
	 ('2007-05-02',6,0,'E unha oferta para Potevedra. Xornada partida','Camarero/a',10,1118,NULL,NULL),
	 ('2007-05-02',0,3,'','Profesor/a de inglés e francés',10,1119,NULL,NULL),
	 ('2007-06-06',3,0,'','Xardineiro',10,128,NULL,NULL),
	 ('2007-06-04',2,1,'promocion de piscinas no CC Alcampo da Avda. Madrid, durante mes e meio e horario de 8:00 a 15:00 horas.','Promotor/a',10,462,NULL,NULL),
	 ('2007-06-01',6,4,'Posto de Responsable do Dpto. de Facturación con 2 administrativos ó cargo.
Posibles contratos de 6 + 6 meses e indefinido.
Coñecementos informática, carné conducir e vehículo, inglés alto.
Ubicación inicial no Porriño.','Administrativo/a',10,249,NULL,NULL),
	 ('2007-06-11',3,5,'Traballadores paro o turno de noite (23 a 7 horas) para o lavado de contenedores e lavapapeleiras, desde o 18 de xuño ata final de setembro. Edade máxima entorno a 40 anos. Salario de 900 a 1000€ netos/mes + finiquito.','Operario/a',10,662,NULL,NULL),
	 ('2007-06-12',0,0,'','Axudante de taller sector metal',10,114,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-06-11',6,2,'Perfil: varón, ata 55 anos, con experiencia e carné B1','Carpinteiro de aluminio (ofic. 1ª/2ª)',10,114,NULL,NULL),
	 ('2007-06-11',6,1,'Para traballar no G. Izmar (confidencial) que é concesionario do mantenemento de Citroën.
Perfil: varon, ata 55 anos, carné B1, experiencia. Horario de 8 a 13 e 14:30 a 17:30.','Albanel (oficial 1ª/2ª)',10,114,NULL,NULL),
	 ('2007-06-04',42,1,'Perfil: muller de idade entre 27 e 34 anos, con experiencia laboral e carné B. Coñecementos amplios de informática (ver oferta). Afable, boa presencia e bo trato co público.','Administrativa',10,1123,NULL,NULL),
	 ('2007-06-07',5,0,'Para cubrir baixa por enfermidade (calculan que para 4 ou 5 meses) nunha empresa de automoción. Require coñecementos de Oracle, de Visual Basic e de Access.','Informático/a',10,116,NULL,NULL),
	 ('2007-06-08',1,3,'Sondaxe feita por BIAL','Aux. excavación arqueolóxica',10,196,NULL,NULL),
	 ('2007-06-13',3,2,'Oferta xestionada a través do BIAL','Oficiais 1ª Albanel',10,80,NULL,NULL),
	 ('2007-06-13',4,0,'Coñecido de Ignacio Ojea.
Comunícase que non temos candidatos/as co perfil requirido. Non obstante, infórmase de outras alternativas (OFOE, outros coñecidos, outras especialidades a contemplar, ...)','Adxunto a director de proxectos',10,1125,NULL,NULL),
	 ('2007-05-28',6,2,'','',10,1127,NULL,NULL),
	 ('2007-06-06',6,0,'','Becario de administración',10,16,NULL,NULL),
	 ('2007-06-06',0,0,'FP II  electricidade','Comercial',10,1128,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-06-06',0,0,'FP II electricidade','Operarios de almacén',10,1128,NULL,NULL),
	 ('2007-06-06',0,0,'FP interiorista','Técnico de iluminación',10,1128,NULL,NULL),
	 ('2007-06-13',3,0,'','Médico',10,1052,NULL,NULL),
	 ('2007-06-13',0,0,'','Enxeñeiro técnico comercial',10,588,NULL,NULL),
	 ('2007-06-29',12,0,'','FP II mecánica',10,489,NULL,NULL),
	 ('2007-06-14',0,0,'','',10,489,NULL,NULL),
	 ('2007-06-29',0,0,'','Oficiais 2ª Tabiquería',10,1106,NULL,NULL),
	 ('2007-06-29',0,2,'','Peón',10,1106,NULL,NULL),
	 ('2007-07-09',12,1,'','Perruqueira',10,195,NULL,NULL),
	 ('2007-07-02',12,0,'Perfil de Enxeñeiro/a Técnico/a, coñecementos de inglés, carné B1 e coche.','Técnico/a Dpto. de Compras',10,225,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-07-01',3,0,'Comercial para a captación de socios para a entidade con contrato mercantil (outros requisitos, ver na oferta)','Axente comercial',10,36,NULL,NULL),
	 ('2007-07-17',1,3,'','Enquisador/a',10,1129,NULL,NULL),
	 ('2007-07-17',0,3,'','Electricista',10,1130,NULL,NULL),
	 ('2007-07-16',3,3,'','Operario automoción',10,126,NULL,NULL),
	 ('2007-07-24',0,4,'','Auxiliar de axuda a domicilio',10,1131,NULL,NULL),
	 ('2007-07-24',0,2,'contrato con Adecco e despois ca empresa','Administrativo/a Facturación',10,1132,NULL,NULL),
	 ('2007-07-19',3,0,'','Auxiliar enfermería',10,655,NULL,NULL),
	 ('2007-07-30',0,0,'','Perruqueira',10,1052,NULL,NULL),
	 ('2007-07-20',0,0,'','Camarero/a',10,1133,NULL,NULL),
	 ('2007-07-18',3,3,'','Limpadora',10,1134,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-07-27',0,1,'Persoa con formación e/ou experiencia en coidados a persoas dependentes, con bó nivel cultural e ampla capacidade de comunicación. Non tarefas de hogar.','Coidador/a-acompañante',86,1003,NULL,NULL),
	 ('2007-07-01',3,3,'Require condutor/a para a furgoneta de transporte dos/as usuarios/as do Centro de Día. Xornada partida, de luns a venres, inicialmente 3 meses prorrogables. Valorarrase experiencia con persoas dependentes. Carnet "D"','Condutor/a de transporte adaptado',85,532,NULL,NULL),
	 ('2007-07-01',3,3,'Admite persoas sen a titulación de aux. de clinica (C.Medio), serán contratadas como xerocultoras. Contrato inicial de 3 meses para sustituir baixas e vacacións. Non especifica turnos.','Xerocultor/a',86,1121,NULL,NULL),
	 ('2007-07-27',0,7,'','Conserxe',10,1136,NULL,NULL),
	 ('2007-07-01',6,4,'Condutor/a de transporte adaptado a tiempo completo, con conocimiento de atención a personas dependientes.','Condutor/a de transporte adaptado',85,373,NULL,NULL),
	 ('2007-07-01',5,2,'Auxiliar de axuda a domicilio, para SAD concertado con el Concello, horario de mañá (tempo parcial) de luns a venres. Chama inicialmente para pedir datos de persoas que fixeron prácticas de Actívate con eles. ','',86,375,NULL,NULL),
	 ('2007-07-24',0,8,'Auxiliares de xeriatría en vivenda comunitaria, para incorporación a mediados de Agosto. Un deles de noite e outro a xornada partida. Farán tarefas de fogar.','Auxiliar de xeriatría',10,1135,NULL,NULL),
	 ('2007-07-19',0,3,'','Auditor o gestor de productos',10,569,NULL,NULL),
	 ('2007-07-30',48,0,'','Jefe oficina técnica',10,1144,NULL,NULL),
	 ('2007-07-26',12,4,'oferta remitida ó BIAL que tras a sondaxe realizada non atopa candidatos/as disponibles e interesados/as, así como tampouco tras a sondaxe desde o SOL.','Albanel',10,1145,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-08-09',3,9,'Recepción, limpeza e almacenado de menaxe e contenedores de transporte de comida.','Limpadora de menaxe',81,1146,NULL,NULL),
	 ('2007-08-01',0,3,'','Delineante mecánico',10,116,NULL,NULL),
	 ('2007-08-09',0,3,'','Camareira autoservizo',10,1146,NULL,NULL),
	 ('2007-08-09',0,1,'','Preparación menaxe+camareira autoservizo',10,1146,NULL,NULL),
	 ('2007-08-08',0,8,'Entre as tarefas a realizar está a realización de campaña para empresa de telecomunicacións
Entre os requerimentos está a de coñecementos de informática e perfil comercial','Teleoperadora',82,1147,NULL,NULL),
	 ('2007-08-02',0,2,'14/8/2007: infórmase que non temos candidaturas disponibles.','Empregada do fogar',10,1148,NULL,NULL),
	 ('2007-08-24',0,2,'Déuselle referencia das 2 persoas disponibles do P.Actívate que cumplían requisitos, contrataron a unha delas.','AAD',86,1149,NULL,NULL),
	 ('2007-08-29',0,0,'Non hai persoas dispoñibles para ese servizo domiciliario nestes momentos','AAD',10,1149,NULL,NULL),
	 ('2010-01-30',0,1,'Precisan candidaturas que acrediten discapacidade.','Limpadora',10,1151,NULL,NULL),
	 ('2007-10-01',0,19,'Datos recuperados de información escrita
Id. 6502 rexeitou o posto por outro traballo.','',10,1152,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2008-03-30',0,5,'Datos recuperados de información escrita.','',10,1153,NULL,NULL),
	 ('2008-03-03',0,2,'Información recuperada de documentación escrita.','Persoal apoio',10,1154,NULL,NULL),
	 ('2008-03-03',0,0,'Información recuperada de documentación escrita.','',10,1155,NULL,NULL),
	 ('2008-03-11',0,0,'Información recuperada de documentación escrita.','Autoventa',10,1158,NULL,NULL),
	 ('2008-03-11',0,0,'Contido recuperado de información escrita.','Dependente/a',10,1159,NULL,NULL),
	 ('2008-03-24',0,0,'Elisa Casal: Información recuperada de documentación escrita.','Aux. Enfermería',10,1160,NULL,NULL),
	 ('2008-03-24',0,0,'Elisa Casal: Información recuperada de documentación escrita.','Maquinista textil',10,123,NULL,NULL),
	 ('2007-11-13',0,0,'Datos recuperados de documentación escrita','Técnico en Comercio Exterior',10,1132,NULL,NULL),
	 ('2007-11-14',0,0,'Elisa Casal: Información recuperada de documentación escrita.','Aux. Administrativo/repartidor',10,1161,NULL,NULL),
	 ('2007-11-14',0,0,'Elisa Casal: Información recuperada de documentación escrita.','Laminador/a',10,131,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-11-15',0,4,'Elisa Casal: Información recuperada de documentación escrita.','Vixiante seguridade',10,1162,NULL,NULL),
	 ('2007-11-28',0,0,'Oferta para Porriño.
Elisa Casal: Información recuperada de documentación escrita.','Peón',10,494,NULL,NULL),
	 ('2007-10-03',0,10,'Elisa Casal: Información recuperada de documentación escrita.','Recepcionista',10,195,NULL,NULL),
	 ('2007-10-10',0,0,'Oferta enviada a BIAL para sondaxe de candidaturas.

Datos recuperados de información escrita.','Repartidor/aplicador',10,1164,NULL,NULL),
	 ('2007-10-10',0,6,'Elisa Casal: Información recuperada de documentación escrita.','Acompañante transporte escolar',10,1165,NULL,NULL),
	 ('2007-10-18',0,2,'Elisa Casal: Información recuperada de documentación escrita.','Limpadora',10,1134,NULL,NULL),
	 ('2007-08-31',0,0,'Elisa Casal: Información recuperada de documentación escrita.','Electromecánico',10,1166,NULL,NULL),
	 ('2007-09-03',0,3,'','Camareira',10,1167,NULL,NULL),
	 ('2007-09-04',0,0,'6/9/2007: infórmase que non temos candidaturas disponibles.','Oficial 1ª Montaje andamios',10,1168,NULL,NULL),
	 ('2007-09-05',0,2,'7/9/2007: infórmase que non temos candidaturas disponibles.','Pescadero/a',10,1127,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-09-05',0,6,'11/09/2007: infórmase que non temos candidaturas disponibles.','Carretilleiro/a',10,1169,NULL,NULL),
	 ('2007-09-10',0,0,'11/09/2007: infórmase que non temos candidaturas disponibles.','Monitor/a Pilates',10,1070,NULL,NULL),
	 ('2007-09-11',0,0,'17/09/2007: infórmase que non temos candidaturas disponibles.','Axente de emprego',10,1170,NULL,NULL),
	 ('2007-09-18',0,0,'20/09/2007: Pásase a oferta a BIAL e as 4 candidaturas non ten B1.
21/09/2007: infórmase que non temos candidaturas disponibles co perfil requirido.','Peón',10,1171,NULL,NULL),
	 ('2007-08-14',0,0,'14/08/2007: pásase a oferta a ACTÍVATE
21/08/2007: infórmase que non temos candidaturas disponibles.','Auxiliar axuda a domicilio',10,1049,NULL,NULL),
	 ('2010-08-22',0,2,'Pásase a oferta a ACTÍVATE.
24/08/2007: Oferta xestionada por Belén (Actívate)','Auxiliar axuda a domicilio',10,1172,NULL,NULL),
	 ('2007-08-27',0,0,'Pásase a oferta a ACTÍVATE. Informa Belén que non temos candidaturas disponibles.','Auxiliar axuda a domicilio',10,1172,NULL,NULL),
	 ('2007-08-27',0,0,'29/08/2007:Infórmase que non temos candidatos disponibles.','Vendedor/a ADSL',10,1173,NULL,NULL),
	 ('2010-06-29',6,3,'29/06/10: Acaban contratando a unha das candidatas súas ante a necesidade de incorporar á seleccionada antes das rebaixas.
30/069/10: Ao día seguinte conunican que non son capaces de contactar a súa seleccionada e enviámoslle as nosas candidatas.','Dependenta',10,1179,NULL,NULL),
	 ('2010-08-01',0,4,'Oferta dun só día en xornada completa con alta en S.S. para contar os vehículos que pasan nalgúns puntos da cidade.','Contador',10,1180,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2010-08-10',0,2,'Pide carpinteiros de ribeira da Escola Obradoiro para incio de novas actividades da súa empresa. Remítense os datos de dous dos mellores valorados da escola, inda que non teñen o permiso de conducir que a empresa demanda.','Carpinteiro de Ribeira',10,1181,NULL,NULL),
	 ('2010-08-18',0,0,'Muller entre 25 e 40 anos con tres anos de experiencia en contabilidade e coñecementos de Cai','Contable',10,1182,NULL,NULL),
	 ('2010-08-20',3,2,'Non contratou a ningunha das candidatas, inda que as dúas persoas lle gustaron e conta con elas para o futuro.','Capataz forestal ou agrícola',10,1183,NULL,NULL),
	 ('2010-10-14',6,2,'','Dependenta',10,1179,NULL,NULL),
	 ('2010-10-21',3,3,'','Persoal de limpeza',65,1185,NULL,NULL),
	 ('2012-03-23',0,3,'Limpeza de comercio de roupa, contrato por obra, horario de 8:00 a 10:00 e acreditación discapacidade.','Limpador/a',10,1188,NULL,NULL),
	 ('2012-03-15',0,0,'Contrato por obra. Coñecementos AutoCad-Microstation-Press to.

Infórmase que non temos candidaturas co perfil requirido.','Delineante',10,1014,NULL,NULL),
	 ('2012-02-21',6,1,'Enxeñeiro Sistemas, especialidade Programación. Nivel alto c++, Java, C-objetive.','Programador Aplicaciones informáticas',10,1189,NULL,NULL),
	 ('2012-02-21',0,1,'O candidato preseleccionado non cumpre o perfil. Infórmase á empresa que non temos candidaturas co perfil requirido.','Operario Mecanizado',10,1191,NULL,NULL),
	 ('2012-02-13',0,4,'Infórmase desta oferta ao UTIL','Oficial 1ª Polivalente',10,1192,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2012-02-13',0,1,'Infórmase desta oferta ao UTIL.','Oficial 1ª Electricista',10,1192,NULL,NULL),
	 ('2012-02-13',0,1,'Infórmase desta oferta ao UTIL.','Oficial 1ª Frigorista',10,1192,NULL,NULL),
	 ('2012-02-13',0,3,'Infórmase desta oferta ao UTIL.','Oficial 1ª Avanzado',10,1192,NULL,NULL),
	 ('2012-02-10',0,0,'Enxeñería Técnica ou Superior, especialidade agrícola, agrónoma, montes o forestal e experiencia.

Infórmase que non temos candidaturas co perfil requirido e publícase a súa oferta no taboleiro.','Responsable de Prevención',10,1193,NULL,NULL),
	 ('2012-02-07',0,2,'23/02/2012: Contrataron a outro candidato e non tiñan información sobre a entrevista dos nosos candidatos.','Mecánico/a (automoción)',10,1194,NULL,NULL),
	 ('2012-04-10',0,6,'Cadena de perfumerías Muchas.
Tódalas candidatas enviadas foron entrevistadas, a maioría en dúas ocasións; finalmente, seleccionarorn a unha candidata da súa base de datos.','Vendedora',10,233,NULL,NULL),
	 ('2012-04-02',0,0,'Oferta aberta polo que se informa ao persoal técnico de orientación e publícase no taboleiro.','Asesor comercial',10,1196,NULL,NULL),
	 ('2012-04-19',0,5,'Require que o/a candidato/a fale correctamente español e total disponibilidade horaria.','Informático de soporte técnico',10,117,NULL,NULL),
	 ('2008-03-06',0,3,'Información recuperada de documentación escrita.','',10,1156,NULL,NULL),
	 ('2008-03-07',0,8,'Información recuperada de documentación escrita.','Peón',10,1157,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2007-10-02',6,6,'Elisa Casal: Información recuperada de documentación escrita.','Administrativo/a',10,1163,NULL,NULL),
	 ('2012-04-27',0,0,'Oferta achegada pola titora de VigoEmprega. Infórmase ao persoal técnico de orientación e publícase no taboleiro.','Docente de cursos de camareiro de restaurante-bar en Ourense',10,1085,NULL,NULL),
	 ('2012-04-20',0,2,'O traballo desenvolverase entre os centros de Vigo e O  Porriño.

26.04.2012: Guillermo informa que o contrato que ofrecen na empresa é posible que non cubra a totalidade da xornada.
10.05.2012: Guillermo informa que ID 8769 foi enviada á entrevista e ID 8672 non tiña a disponibilidade horaria requirida.','Dependenta pastelaría',65,489,NULL,NULL),
	 ('2012-05-14',0,5,'Requisitos: FPII ou similar, carné B.
Xornada: 9 a 13 e 15 a 19 horas.
Ambito: provincia de Pontevedra.
Achéganse datos de 2 beneficiarios do UTIL que aínda non están rexistrados.
No seguimento realizado informan que só entrevistaron a ID 8555 pero que contrataron a outro candidato con mais experiencia.','Técnico/a instalación e mantemento de ascensores',10,1197,NULL,NULL),
	 ('2016-06-28',0,1,'Incorporación inmediata.
Tarefas: coidado de matrimonio de 90 anos e tarefas domésticas.
Preferencia muller con experiencia.','Interna cuidado matrimonio mayor y doméstico',65,1250,NULL,''),
	 ('2012-05-14',5,9,'Substitución para cubrir baixa por maternidade de 4-5 meses.
Administrativo/a cuxa tarefa principal será a atención ao asegurado. Valórase coñecemento de seguros e estudos universitarios de empresariais.
No seguimento realizado, xa entrevistaron ás candidatas pero aínda non tomaron a decisión. Están entre unha das nosas candidatas e outra que lle facilitou un contacto.','Administrativo/a',10,1198,NULL,NULL),
	 ('2012-05-16',0,2,'Requírese coñecementos de impresión offset en máquina de 6 cores con laca e UVI. Os candidatos preseleccionados non cumpren os requisitos e infórmase que nosn temos candidatos co perfil requirido.','Maquinista offset artes gráficas',10,489,NULL,NULL),
	 ('2012-05-21',0,11,'Oferta xestinada por sondaxe na base de datos e publicación no taboleiro.
Azafatas/as  para congreso médico do 13 ó 16 de xuño, requírese experiencia e idade ata 36 anos (achéganse candidaturas que sobrepasan a idade pola súa experiencia e non poñen trabas).','Azafatas/os de congresos e protocolo',10,1199,NULL,NULL),
	 ('2012-05-23',0,1,'Tras a sondaxe realizada, e os compromisos laborais adquiridos polo candidato preseleccionado infórmase que non temos candidatos disponibles para o evento do día 2 de xuño no CC. Gran Via.
Achegan información para publicar no taboleiro.','Animador cantante',10,1200,NULL,NULL),
	 ('2012-05-23',0,3,'Solicitan comercial para a provincia de Pontevedra para venta de servizos de publicidade na prensa escrita ou páxina web de medio de comunicación.','Comercial',10,1201,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2012-05-30',12,1,'Infórmase á empresa que non temos candidaturas disponibles neste momento na súa oferta e que procedeuse á publicación da súa oferta no taboleiro.','Asesor comercial financiero',65,1202,NULL,NULL),
	 ('2012-06-12',1,3,'Non seleccionaron a ningunha das candidatas polo elevado nivel de galego esixido.','Enquisador/a',10,1203,NULL,NULL),
	 ('2012-06-05',0,4,'','Asesor comercial financiero',10,1202,NULL,NULL),
	 ('2012-06-25',0,3,'','Encargado/a de almacén',10,489,NULL,NULL),
	 ('2012-07-09',0,2,'Publícase tamén esta oferta no taboleiro.','Comercial sector TIC-Informática zona Galicia',10,1204,NULL,NULL),
	 ('2012-09-10',0,1,'Publícase tamén esta oferta no taboleiro.
Achego datos dun usuario do SPE que mostrouse interesado na oferta publicada no taboleiro.','Programador/a informático/a',10,1205,NULL,NULL),
	 ('2012-10-01',6,0,'Informo á empresa que non temos candidaturas disponibles e/ou interesadas na súa oferta de emprego.','Promotor/vendedor tecnoloxía',10,1206,NULL,NULL),
	 ('2012-10-03',9,8,'','Auxiliar de vivenda comunitaria',10,203,NULL,NULL),
	 ('2013-02-26',0,3,'PRUEBA APLICACION NUEVA','prueba',113,1210,NULL,NULL),
	 ('2013-05-08',4,2,'','responsable de gestion documental',65,1210,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2013-08-20',0,1,'Idiomas: Igbo y Broken English. Certo nivel cultural. Manexo de correo electrónico,etc.
Para servizos puntuais nos xudgado e policía nacional. Alta e baixa o mesmo día.','Traductor/Intérprete Nigeriano',10,1208,NULL,NULL),
	 ('2012-11-01',0,1,'Informo á empresa que non temos candidaturas co perfil requirido.','Patronista industrial',65,489,NULL,NULL),
	 ('2012-11-07',0,1,'Boa presenza, sen piercings nin tatuaxes visibles.','Camareiro/a',65,1211,NULL,NULL),
	 ('2012-11-27',3,1,'Contratación ao abeiro do Plan Municipal de Fomento de Emprego 2012.
Achégase candidata usuaria do concello non inscrita na base de datos.
Informan que non chegaron a entrevistar a nosa candidata.','Auxiliar Comercial',65,484,NULL,NULL),
	 ('2012-12-19',0,1,'Oferta aberta publicada no taboleiro.','Axente comercial',65,1212,NULL,NULL),
	 ('2013-01-21',0,1,'','Mecánico de máquinas de conservas',65,1213,NULL,NULL),
	 ('2013-02-12',0,1,'','Mecánico/a Vigo',65,1194,NULL,NULL),
	 ('2013-02-19',0,0,'Oferta de emprego para publicar no taboleiro.
Ocupación a media xornada. 18-35 anos. Don de xentes.','Captación de Socios',65,1214,NULL,NULL),
	 ('2013-02-19',0,1,'Contrato mercantil con carteira de clientes para a venta de fariña de trigo para a fabricación do pan na provincia de Pontevedra.
Informo que non temos candidatos disponibles e/ou interesados na súa oferta de emprego.','Comercial',65,1207,NULL,NULL),
	 ('2013-02-12',6,3,'A oferta tamén se publica no taboleiro.
Contrataron a persoal con experiencia similar ao posto ofertado e non corresponde ás candidaturas enviadas.','Dependente/a de tenda de reloxería e xoiería',65,1209,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2013-03-26',0,1,'Atención barra e sala.','Camareira',65,1215,NULL,NULL),
	 ('2013-03-18',0,1,'Idade ata 40 anos. Tarefas: organización, supervisión y control de todo o proceso produtivo.
26/03/2013: Marta Vázquez informa que teñen unha candidata pendente de resposta.
15/04/2014:No seguimento realizado informan que contratan a outra candidata.','Xefe de producción',65,1216,NULL,NULL),
	 ('2013-03-15',0,6,'Idade ata 40 anos (preferencia <30). CMA. Experiencia laboral previa e coñecementos de informática.','Operario/a de producción',65,1216,NULL,NULL),
	 ('2013-04-09',0,7,'Titulación: Enxeñería Industrial/Mecánica, especialidade de calidade automoción. Experiencia laboral previa. Nivel de inglés alto. Carne conducir e vehiculo e residencia en Barcelona.

Informo á empresa que tras a sondaxe realizada non temos candidaturas disponibles e/ou interesadas na súa oferta de emprego.','Enxeñeiro de Calidade',65,1217,NULL,NULL),
	 ('2013-04-09',0,7,'Titulación: Enxeñería Industrial/Mecánica, especialidade de calidade automoción. Experiencia laboral previa en calidade e/ou deseño de carrocerías. Nivel de inglés alto. Carne conducir e vehiculo e residencia en Barcelona e disponibilidade para viaxar.

Informo á empresa que tras a sondaxe realizada non temos candidaturas disponibles e/ou interesadas na súa oferta de emprego.','Enxeñeiro Mecánico (Deseño de Carrocerías)',65,1217,NULL,NULL),
	 ('2013-04-25',12,0,'Contrato de formación. Idade ata 29 anos. Xénero: muller. Experiencia previa.
O empresario solicita que facilitemos o seus datos ás candidatas para que contacten con él.

O empresario descartou a estas candidatas pero tampouco resultou doado establecer novo contacto.','Dependenta de tenda de alimentación',65,1218,NULL,NULL),
	 ('2013-04-25',0,1,'Xornada laboral de 2 horas/día de L a V.
Tarefas: movilizacións de unha señora encamada de complexión forte, hixiene persoal e apoio nas labores domésticas e recados.','Auxiliar de axuda a domicilio',65,1219,NULL,NULL),
	 ('2013-05-09',0,1,'Posto ofertado polo Plan do Fomento de Emprego do Concello de Vigo.

16/05/2013: Decidiron contratar a outro aspirante.','Enxeñeiro/a Técnico/a en Informática',65,74,NULL,NULL),
	 ('2013-06-05',0,1,'Envíase candidato referido por Maika Cores (Vigo Laborando).','Docente para curso do CMA',65,1220,NULL,NULL),
	 ('2012-12-19',0,1,'Oferta derivada ao programa "Máis emprego na hostalería" de FEPROHOS.','Camareiro/a',65,1211,NULL,'');
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2013-06-06',0,1,'Atencións de carácter persoal, domésticas e de acompañamento. Idade entre 25-58 anos. Xénero: muller. Experiencia laboral previa. Carné conducir e vehículo. Xornada de L a V de 10 a 12 e de 18 a 21 horas.

07/06/2013: Oferta remitida á Directora do O.E. Vigo Atende.','Auxiliar de axuda no fogar',65,1221,NULL,NULL),
	 ('2013-06-06',0,1,'Atencións de carácter persoal, domésticas e de acompañamento. Idade entre 25-58 anos. Xénero: muller. Experiencia laboral previa. Carné conducir e vehículo. Xornada de sábados e domingos de 9 a 14 horas.

07/06/2013: Oferta remitida á Directora do O.E. Vigo Atende.','Auxiliar de axuda no fogar',65,1221,NULL,NULL),
	 ('2014-02-14',2,1,'Contrato de 12 h/semana repartidas entre viernes y sábados. Tarefas: asesorar tecnolóxicamente sobre los productos da firma, control de stock e reportes de ventas.

Nas conversacións mantenidas o señor Achaga refire que ten un candidato proposto polo centro de traballo (Corte Inglés) ao indicarme o seu perfil confirmo coñecer ao dito candidato e que é válido para este posto polo que para non xenerar falsas expectativas nos nosos usuarios faremos o sondaxe correspondente no caso de que sexa necesario.','Promotor/Asesor tecnolóxico',65,1222,NULL,NULL),
	 ('2013-07-05',0,1,'Mesmo perfil das ofertas anteriores.
Achégase a candidatura de María Viéitez Castro por referencia do O.E. Vigo Atende (non foi seleccionada e houbo desencontro co empresario).','Camareira',65,1211,NULL,NULL),
	 ('2013-05-20',0,8,'Aínda que non teñen centros de traballo en Galicia, segundo a prospección realizada desde a súa empresa as localidades de Vigo e Salamanca son nas que se produce máis movilidade laboral a outras cidades. Tamén se publicou esta oferta no taboleiro polo que as seguintes candidtaturas non son da base de datos:
- Mª Sandra González Pousada
- Inés Bastos Refolio','Trainee',65,1223,NULL,NULL),
	 ('2014-05-21',0,1,'Optico/a con titulación e experiencia para traballar a media xornada.

Informo á empresa que non temos candidaturas co perfil requirido.','Optico/optometrista',65,1225,NULL,NULL),
	 ('2013-06-13',0,1,'Precisan un perfil comercial para captación e mantenemento de clientes e proveedores e con experiencia na xestión de equipos de traballo. Se require formación académica.
Tamén se publicou esta oferta no taboleiro. Se enviaron las candidaturas de:
- Fco. Javier Nolan (obtido a través de contactos en Linkedin) - SELECCIONADO
- Oscar Fernández Villar (autocandidatura)
- Manuel Antonio Rodríguez Costas (por referencia de Vigo Laborando)
- María de Fátima Soto Barral (autocandidatura)','Director Comercial',65,135,NULL,NULL),
	 ('2013-06-17',0,1,'Tarefas a realizar: Captación de inmobles de venda e aluguer e xestión administrativo financeiras que correspondan.
Salario fixo + variable.
Idade ata 55 anos.
Se enviou a candidatura de Loreto Alvarez Alvarez (usuaria do SPE, que non foi seleccionada)
A candidata Id. 8422 foi seleccionada meses máis tarde pero xa empezara a traballar noutra empresa.','Comercial Inmobiliario',65,1224,NULL,NULL),
	 ('2013-04-16',6,1,'Contrato de 12 horas/semana para fines de semana. Tarefas: atención a clientes, promoción productos marca Vexia, asesoramento e venta. Idade entre 20-40 anos. Experiencia previa equivalente. Preferencia con coñecementos de telefonía, informática e/ou marketing.

Oferta tratada con sondaxe da base de datos e publicación no taboleiro. Achéganse os datos de Hugo Julín Glez. que respostou á publicación do taboleiro.

Ante a demora no proceso de selección cando quiseron contratar ao candidato proposto xa non estaba disponible.
Achégase as candidatura de Daniel Sánchez Iglesias e de José Luis Vázquez Armesto (por ref. do anuncio no taboleiro) e non foron seleccionados.','Promotor/Vendedor Tecnoloxía',65,1206,NULL,NULL),
	 ('2013-06-07',0,2,'Require experiencia previa, nivel alto de inglés e disponiblidade para viaxar e cambiar de residencia.

Publícase esta oferta no taboleiro.','Enxeñeiro Mecánico e Enxeñeiro de Calidade',65,1217,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2014-03-03',0,0,'Limpeza de mantenemento de zonas exteriores, barrido, uso de fregadora e recollida con carretilla elevadora. Contrato de obra de 2 horas/semana (venres de 15:00 a 17:00 horas). Se require experiencia. Incorporación o 07/03/2014. Salario: 42,62€ brutos/mes.

05/03/2014: a empresa informa que seleccionaron outra candidatura e non chegaron a entrevistar a nosa candidata.','Limpador/a de mantenemento',65,1229,NULL,NULL),
	 ('2014-05-26',0,2,'Profesionais con coñecementos de dirección e admón. empresas, enxeñería ou outros campos, capaces de interlocución a nivel xerencial para detectar carencias e necesidades de empresas e recomendar solucións. Pese ao marcado compoñente comercial, require coñecementos técnicos elevados e orientado á venda de produtos de consultoría.
Prevista incorporación para setembro 2014.','Técnico/a Comercial',65,1227,NULL,NULL),
	 ('2013-08-08',0,1,'Repartidor/a con moto propia de 4 tempos e baúl grande (ou posibilidade de incorporarlo), residente en Vigo centro. Para fins de semana e posibilidade de ampliación. Horario de 21:00 a 24:00 horas.

Publícase esta oferta no taboleiro.','Repartidor/a',65,1228,NULL,NULL),
	 ('2014-05-22',0,1,'Camareiro con experiencia e referencias, de 25 a 35 anos. Horario de tarde.
Responsable, serio e agradable con gran capacidade para o traballo en equipo.

08/07/2014: No seguimento realizado informan que contrataron a outro candidato.','Camareiro',65,1215,NULL,NULL),
	 ('2013-08-05',0,2,'Buscan profesionais con clara orientación comercial, dinámicos e interés no seu desenvolvemento profisional para a captación de novas contas de cliente, atendendo ás necesidades formativas e outras das empresas e procurar a súa fidelización. Non requiren titulación nin experiencia previa pero si vehículo propio.
Contrato mercantil en período de proba e posibilidade de contrato laboral segundo a valía.
Remuneración por obxectivos, incentivos e comisións.

Publícase esta oferta no taboleiro.','Asesor/a Comercial de Formación',65,1230,NULL,NULL),
	 ('2013-08-08',0,2,'Tarefas para operador loxístico internacional: Tramitación documentos, despachos import/export, clasificación arancelaria, Duas, tramitación de regímenes aduaneros, de licenzas e/ou certificados, etc. Indispensable coñecemento portuario e valórase o dominio do inglés e de ferramentas informáticas.
Salario bruto entre 20000-25000€.

10/09/2013: Informo telefónicamente que non temos candidaturas disponibles con ese perfil.','Axente de aduanas',65,1231,NULL,NULL),
	 ('2014-01-16',0,2,'Publícase no taboleiro.','Docente para curso de Información Xuvenil',65,1232,NULL,NULL),
	 ('2016-06-02',3,1,'Valórase experiencia, carné conducir, vehículo e CMA.
Tarefas: labores de limpeza en industria e fábrica.

Achégase cv de José Antonio Alonso Carrera (usuario de Vigo Integra).','Persoal limpeza',65,1240,NULL,''),
	 ('2016-06-20',0,1,'','Auxiliar de axuda a domicilio',65,203,NULL,''),
	 ('2014-06-09',4,1,'Tarefas: encargarse da froitería, repoñer, despachar, caixa, etc.
Capacidade de traballar con autonomía.
Require experiencia previa.
Contrato temporal a xornada completa e posibilidade de conversión a indefinido.

Achéganse os datos de Rut González García usuaria de Vigo Integra (Ref. Maika Cores).','Dependenta de froita',65,1233,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2013-12-03',3,30,'Tarefas: atención ao cliente, tramitar pedidos e recollida de mesas.
Incorporación prevista inicial para xaneiro 2014 (final previsto en xullo 2014).
Valórase CMA e experiencia axeitada ás tarefas a desenvolver.
Entre as 100 candidaturas achegadas figuran usuarios procedentes do SOL, SPE, O.E.Vigo Capacita, Imos traballar e do Vigo Integra.

Contratados:Teresa Garrido, Pablo Nogueira, David Fernández y Carlos Crespo (de Vigo Integra)','Auxiliar de restauración',65,1226,NULL,NULL),
	 ('2014-06-12',3,2,'1 posto a xornada completa e outro a xornada parcial.
Venda de iogures xeados en quiosco en Av. Samil, 26.
Require CMA, muller, idade entre 22 e 35 anos e experiencia igual ou equivalente.','',65,1234,NULL,NULL),
	 ('2014-07-04',12,1,'Tarefas: Captación e mantenemento da carteira fixa de clientes desde o domicilio.
Ofrecen contrato mercantil.
08/07/2014: Informo que, tras a sondaxe realizada, non hai candidaturas co perfil requirido. Quedamos en publicar a oferta no taboleiro.','Comercial Consultor/a',65,1236,NULL,NULL),
	 ('2016-08-09',1,1,'Data incorporación: 16/08/2016.
Requírese experiencia previa.

Infórmase que non temos candidatas dispoñibles neste momento.','Limpiadora',65,464,NULL,''),
	 ('2016-09-19',0,3,'Requírese formación e experiencia e carné de conducir.','Auxiliar de axuda a domicilio',65,203,NULL,''),
	 ('2014-06-24',12,1,'Require Certificado de Profesionalidade Sociosanitario en axuda a domicilio.
Ofrecen contrato inicial de 20 horas/mes e ampliaráse a 70 h/mes.

08/07/2014: no seguimento realizado informan que non seleccionaron a ningunha das candidatas porque deron prioridade a que o domicilio particular estivese cercano ao domicilio de traballo.','Auxiliar de axuda a domicilio',65,1235,NULL,NULL),
	 ('2014-07-31',0,1,'Tarefas: mantenemento ximnasio (coidado e mantenemento de instalacións de aclimatación, depuradoras, carpintería, albanelaría, fontanería, etc.).
Horario: 9:00 a 13:00
Incorporación 04/08/2014

01/08/2014: informan que xa cubriron a vacante.','Técnico Mantenemento',65,1237,NULL,NULL),
	 ('2014-08-07',0,10,'Require CMA, experiencia laboral.
Achégase esta oferta ao Plan Integrado (Sonia Mtnez.).
Da prospección da base de datos con varias candidatas non é posible contactar.','Auxiliar de fabricación en conserveira',65,1237,NULL,NULL),
	 ('2014-08-11',12,10,'Da labor de prospeción da base de datos non resulta candidata algunha que cumpra co perfil requirido o que se transmite á empresa. Achégase datos desta oferta ao Programa Integrado (Sonia Mtnez.)','Operaria con discapacidade',65,1237,NULL,NULL),
	 ('2014-09-09',0,5,'Só se require experiencia previa na mecánica de autobús. Achégase candidatura cun perfil equivalente.
Infórmase desta oferta ao Vigo Integra e non ten candidaturas para este perfil.
Infórmase desta oferta á titora do Vigo Emprega e achega candidatura ID.10832','Mecánico de Autobuses',65,1237,NULL,NULL);
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2015-11-13',0,1,'Técnico reparador móviles, ordenadores e tablets (Iphone, Samsung, LG, Sony, etc.), a nivel de software e hardware. Atención ao público (Stand no CC. Gran Vía).
Abstenerse persoas sen experiencia na reparación de móviles e de Iphone e sen capacidade de atención ao público.
Data incorporación prevista: 23/11/2015. Xornada completa.
Achéganse 2 candidatos de Vigo Integra III.','Técnico reparador',65,1238,NULL,''),
	 ('2016-02-03',3,2,'Captación de clientes para contratación de produtos, xestión de cobros, análise de riscos e informes comerciais e servicios financeiros.
Período de proba con contrato mercantil de 3-6 meses e incorporación en plantilla.
Experiencia superior a 3 anos e valora coñecementos financeiros.','Xestor/a Comercial',65,1239,NULL,''),
	 ('2015-11-25',0,1,'Tarefas: limpeza de choque inicial ata a apertura do establecemento e posteriormente o seu mantenemento.
Data de incorporación prevista: 01/12/2015
Requisitos: 30 a 55 anos, muller. Valórase o compromiso coa empresa e as ganas de traballar.','Limpeza - Auxiliar de Servicios',65,1241,NULL,''),
	 ('2016-02-26',3,2,'Tarefas: limpeza oficinas, aseos, cristais, fachadas, instalacións industriais, etc.
Requiren experiencia, carné conducir e vehículo.
Ofrecen contrato temporal por circunstancias da produción cunha duración prevista de 3 a 6 meses e xornada en función do/s cliente/s.
Infórmase de esta oferta a OE Vigo Capacita II, Vigo Emprego e PIEG Vigo Integra III.
Contrataron ao candidato David Bande Alvarez procedente do Vigo Integra.','Operario/a Limpeza',65,1240,NULL,'primaria'),
	 ('2016-03-03',6,1,'Tarefas: Xestionar o proceso de difusión e distribución das publicacións, produtos comerciais e libros, cumprindo os obxectivos esixidos respecto a invendidos e esgotados.

Achéganse candidaturas procedentes de Vigo Emprega e Vigo Integra (indícanse as candidaturas que están nesta base de datos).

30/3/2016: Non chamaron aos candidatos porque consideraron mellores outros perfis procedentes de outras bolsas de emprego.','Difusor de prensa',65,303,NULL,'FP'),
	 ('2016-03-14',6,2,'2 Postos: 1 Vendedor/a e 1 Encargado/a (trátanse por xunto porque achegamos as candidaturas para os dous postos).
Achéganse 3 candidaturas de Vigo Integra e 1 usuaria do SOL.
Ao facer seguimiento achegan correo electrónico o30/03/2016 e agradecen as candidaturas enviadas pero procederon a seleccionar a persoal interno como dependente e as candidaturas para o posto de encargado/a non as consideran viables.','Vendedor/a e Encargado/a',65,1242,NULL,'secundaria'),
	 ('2016-03-03',0,1,'Tarefas de limpeza e mantenemento en Centro Comercial en Vigo.
Requiren experiencia previa.
Achéganse candidaturas procedentes de Vigo Emprega, Vigo Integra e O.E. Vigo Capacita.','Limpadora',65,1243,NULL,''),
	 ('2016-05-25',9,1,'A candidata deberá reunir os requisitos necesarios para optar á solicitude da Axuda á contratación e mellora do emprego da mocidade viguesa 2016 (menor de 30 anos e experiencia laboral inferior a 365 días).
Achéganse 2 candidatas de Vigo Integra III: Graciela Vila Martínez e Lucía Cesteiro Pazó e unha candidata do SOL.','Dependenta',65,1246,NULL,''),
	 ('2016-05-20',9,1,'Achegaranse candidaturas que reúnan os requisitos para poder solicitar a correspondente axuda á contratación e mellora do emprego da mocidade viguesa 2016 (menor de 30 anos, experiencia laboral inferior a 365 días).
Envíanse 2 candidatos procedentes de Vigo Integra III: Carlos Casal Fdez. e Borja Pérez Pérez.
24/05/2016: a empresa informa que seleccionaron un candidato procedente do SPEG.','Electricista, oficial 3ª',65,1247,NULL,'FP'),
	 ('2016-06-21',2,10,'Requírese experiencia en carpintería de aluminio, estruturas metálicas e/ou fachadas ventiladas. Carné de conducir e coche. Curso de PRL de 60 horas e valórase curso de plataformas elevadoras.','Oficiais e peóns fachada ventilada',65,1248,NULL,'');
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2016-06-28',0,1,'Se require: Curso de Atención Sociosanitaria ou Aux. enfermería, etc.; muller e experiencia.
Tarefas: atención a persoa de mediana idade con autonomía limitada por un accidente como asistente persoal, traslados e movilizacións e tarefas domésticas.
Luns a venres de 08:00 a 10:00','Auxiliar de axuda a domicilio',65,1219,NULL,''),
	 ('2016-06-20',-1,1,'Incorporación prevista en setembro.
Tarefas: coidado nenos de 3 e 5 anos e tarefas domésticas e cociña.
Horario de 7:30 a 15:30 horas.
Require: idade 27-55 anos, muller e 3 anos de experiencia.','Auxiliar Servicio doméstico y cuidado niños',65,1250,NULL,'primaria'),
	 ('2016-07-20',0,10,'Requisitos: 18 a 55 anos, experiencia, carne conducir e vehículo. Valorarase curso de PRL e manexo de carretilla e plataforma elevadora.

Ao ser incorporación inmediata algúns dos candidatos non os deixaron optar ao posto por estar traballando.','Limpieza y mantenimiento industrial',65,1251,NULL,'secundaria'),
	 ('2016-07-21',0,1,'Oferta que publícase no taboleiro.','Store Manager',65,1252,NULL,''),
	 ('2016-08-01',0,2,'Requisitos: experiencia previa, CMA
Horario: 8 a 13 e 15 a 18 horas
Tarefas: selección e limpeza de peixe, empacado, etc.

Infórmase que non temos candidaturas disponibles e procedeuse a publicar a oferta no taboleiro.','Operario/a de conservas',65,117,NULL,''),
	 ('2016-08-02',0,0,'Requírese dispoñibilidade horaria de 10 a 22 horas.

Infórmase que non temos candidaturas dispoñibles.','Teleoperador/a',65,117,NULL,''),
	 ('2016-06-20',9,1,'Requiren >25 anos, > 2 anos carné conducir, preferencia muller.
Queren optar a Axuda á contratación da mocidade viguesa.

Achéganse datos de Ana Victoria Márquez Quevedo (Vigo Integra) que tamén é contratada.','Dependente/a (Repartidor)',65,1246,NULL,''),
	 ('2017-03-20',6,1,'Tarefas administrativas, elaboración facturas, albaráns, contabilidade, arquivo, etc.
Data incorporación: abril 2017
Xornada parcial: 20 h/semana de 9:00 a 13:00
<30 anos, experienca < 365 días, inglés, informática.

Achégase tamén os datos da candidata Kelly Pereira Alvarez, usuaria de Vigo Integra.','Auxiliar administrativo/a',65,1253,NULL,'FP'),
	 ('2016-05-27',12,1,'Requiren Ciclo en Electricidade e/ou electrónica, < 30 anos, carné B.

Achéganse tamén os datos de Carlos Casal Fdez. e Borja Pérez Pérez usuarios do Vigo Integra.

Contrataron a un candidato procedente do Colexio Hogar por ter máis idade e experiencia. Non descartan contar con Borja si seguise disponible.','Técnico instalación y reparación máquinas vending',65,1184,NULL,''),
	 ('2016-06-02',3,1,'Requisitos: Experiencia laboral, carnet B e carretilleiro, vehículo propio. Valórase CMA.
Tarefas: labores de mantenemento, reparacións de averías e apoio ao persoal da empresa.

Achégase tamén a candidatura de Luis Miguel Fdes. Sangiao (usuario do Vigo Integra III).','Persoal Servizos Xerais',65,1240,NULL,'');
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2016-06-10',9,1,'Requisitos: <30 anos

14/06/2016: Párase o proceso de preselección porque informan que teñen unha candidata do seu interese que lles achegarán desde o SPEG.','Axudante dependente quiosco',65,1254,NULL,''),
	 ('2016-06-27',9,1,'Contrato en prácticas.
Requiren FP Estética.

Achégase a candidatura de Marta De Melo Barciela (usuaria de Vigo Integra).','Estethicien',65,1255,NULL,''),
	 ('2017-03-30',0,6,'Contrato por obra o Servicio para realización de tareas de soldadura Mig/Mag
Se remite también los cv de Ramón Suárez Iglesias, Manuel Alejandro Darriba Casal y  José María Comesaña Comesaña.  Tanto estos 3 candidatos como  Miguel Shawab  son trabajadores del Vigo Emprega 2016/2017.','Soldadores MIG/MAG',10,117,NULL,''),
	 ('2017-04-03',-1,1,'Solicita Fresador con CNC con expereincia previa demostrable como operario de fresadora ou torno cnc e convencional. o contrato é de carácter indefinido.

Rémitese o dia 18/04/2017  o cv de Francisco por que non o dimos localizado antes. Despois de ver as chamadas perdidas decidiuse a por en contacto con nos. Ainda que está traballando está aberto a valorar outras ofertas de emprego','FRESADOR CNC',65,1256,NULL,''),
	 ('2017-04-06',6,1,'Solicita un/a administrativo/a para realizar contrato de prácticas. Tiene que ser menor de 30 años.

Se envia el cv de Tania Izaskun el dia 20/04/2017 que tiene un cilco superior de administracion y Finanzas y un ciclo de Técnico de documentación sanitaria. No está en la base de datos de SOL por que estuvo participando en el Programa Integrado Vigo Integra III que tiene base de datos propia','Administrativa/o',65,1257,NULL,'FP'),
	 ('2017-04-27',6,1,'El  perfil solicitado es de un Jefe de Almacén con formación profesional en el área de química o similar y con amplia experiencia laboral.

 No se remiten candidatos por que no hay ninguno que se adapte al perfil solicitado. En fecha 05/05/2017 se remite correo a la empresa informándole.','JEFE DE ALMACÉN',65,1258,NULL,''),
	 ('2017-05-05',0,0,'El perfil solicitado es para un puesto de Administrativo Comercial polivalente para un centro de formación. Tiene que gestionar toda la formación  subvencionada y privada.

Se ha remitido también el cv de una candidata que vino por SGC el dia 8/05/2017 que se llama Rocio Martínez.','Administrativo Comercial Polivalente',65,1259,NULL,''),
	 ('2006-07-12',1,50,'Achéganse candidaturas pola próxima apertura do centro da rúa Pizarro en Vigo.','Dependente/a polivalente (Carnicería, perfumería, etc.)',65,1035,NULL,''),
	 ('2017-06-06',6,1,'Tarefas: captación, xestión e aluguer de inmobles; traballo con CRM; mecanización de datos; redación de correos; xestións coa administración; reportaxe bibliográfico; atención telefónica.

Ademáis das candidaturas do SOL achéganse os datos de Iñigo Díaz Cortés e de Teresa Arias González de Vigo Emprega.','Comercial de Alquiler',65,1224,NULL,'secundaria'),
	 ('2018-01-22',12,1,'Require Ciclo ou Grao Superior en Deseño/Decoración, AutoCad e valora coñecementos de administración.','Técnico Decoración',65,1260,NULL,'FP');
INSERT INTO public.empresa_ofertas_contratacion ("data",nummeses,numpostosofertados,observacions,posto,accionsfe_id,id_empresa,categoriaprofesional_id,estudiosminimos) VALUES
	 ('2017-11-08',0,0,'CARNICERA EN VIGO A TIEMPLO COMPLETO 
ENVIAMOS A SILVIA PARENTE QUE PASA A ENTREVISTA.','',10,1262,NULL,''),
	 ('2017-11-17',0,0,'AUXILIARES DE AYUDA A DOMICILIO .LLAMAMOS A 16 PERSONAS Y FINALMENTE ENVIAMOS A 6



, E','AUXILIAR DE AYUDA A DOMICILIO',10,1263,NULL,''),
	 ('2018-05-09',3,1,'Cos requisitos necesarios para poder solicitar a correspondente Axuda á contratación e mellora do emprego da mocidade viguesa 2018.','Axudante camareiro/a',65,1266,NULL,''),
	 ('2020-06-12',9,1,'Reparto de paquetería. Idade 20 a 30 e 40 a 50 anos.','Chofer-Repartidor',65,1267,NULL,'');