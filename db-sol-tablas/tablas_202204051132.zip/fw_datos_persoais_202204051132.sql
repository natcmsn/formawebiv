INSERT INTO public.fw_datos_persoais (apel1,apel2,email,nome,tfno,datosprofesionais_id) VALUES
	 ('Multimedia','SLL','ramon@alenmultimedia.com','Alen','986136710   ',81),
	 ('','','','Axenda -Conta So Para Uso De Citas Na Axenda-','            ',86),
	 ('Calviño','','sol.concello@vigo.org','Mila','2178        ',133),
	 ('Iglesias',' ','chelo.iglesias@vigo.org','Chelo','1229        ',90),
	 ('Calviño','','sol.concello@vigo.org','Milagros','986810232   ',135),
	 ('Veiga','','ricardo.veiga@vigo.org','Ricardo','986442113   ',96),
	 ('Soto','Sío','','Montserrat','            ',144),
	 ('Martínez','Rodríguez','','Silvana','986442113   ',145),
	 ('Castro y','Antonio','','Ana María','986442113   ',146),
	 ('Casabella','Fidalgo de Lemos','','Andrea','986442113   ',147);
INSERT INTO public.fw_datos_persoais (apel1,apel2,email,nome,tfno,datosprofesionais_id) VALUES
	 ('Mouriño','Barros','pme.oficina1@vigo.org','Carmen','986447400   ',149),
	 ('Rodríguez','Ricart','util.administracion@vigo.org','Sonia','986263068   ',150),
	 ('Piñeiro','Álvarez','belen.pineiro@vigo.org','Belén','986266320   ',122),
	 ('González','Torres','susana.glez@vigo.org','Susana','986263068   ',125),
	 ('Martínez','Alonso','sonia.martinez@vigo.org','Sonia','1229        ',129),
	 ('Rivas','','','Jose Luis','',151),
	 ('Gutiérrez','Orúe','paco.orue@vigo.org','Francisco J.','986810236',137),
	 ('C ores','','sol.cera1@vigo.org','Mª del Carmen','986266320',134),
	 ('Sousa','Fernández','sol2@vigo.org','Sandra','986266320',127),
	 ('García','','eva.garcia@vigo.org','Eva','1209',88);
INSERT INTO public.fw_datos_persoais (apel1,apel2,email,nome,tfno,datosprofesionais_id) VALUES
	 ('Núñez','Vázquez','sol@vigo.org','Tatiana','986266320',136),
	 ('Cea','Rodríguez','xosealberte.cea@vigo.org','Xose Alberte','5459',148),
	 ('De Monasterio','Roldan','util.titoria@vigo.org','Celia','986263068',143),
	 ('SEN','ASIGNAR','no@email.com','ORIENTADOR','986000000',139),
	 ('Mouriz','','pme.coordinacion@vigo.org','Ana','629233892',142),
	 ('Perez','Durán','gloria.perez@vigo.org','Gloria','',140),
	 ('Domínguez','Montenegro','blanca.dominguez@vigo.org','Blanca','1931',152),
	 ('Casal','','elisa.casal@vigo.org','Elisa','2304',93),
	 ('Juncal','Gil','uti.directorvigo.org','Carlos','986263068',141),
	 ('Bernardez','Nuñez','ismael.bernardez@vigo.org','Ismael','63938 10 05',155);
INSERT INTO public.fw_datos_persoais (apel1,apel2,email,nome,tfno,datosprofesionais_id) VALUES
	 ('Martinez','Nieves','maria.nieves@vigo.org','Maria','61094 26 52',156),
	 ('Otero','Malvárez','rosa.otero@vigo.org','Rosa','986810310',157),
	 ('Otero','Malvárez','rosa.otero@vigo.org','Rosa M.','986810310',158),
	 ('Otero','','','Rosa','',159),
	 ('Otero','','rosa.otero@vigo.org','Rosa','986810310',160),
	 ('Otero','','','Rosa','',161);