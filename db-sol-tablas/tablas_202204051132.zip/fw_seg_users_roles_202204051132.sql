INSERT INTO public.fw_seg_users_roles (user_id,rol_id) VALUES
	 (139,1),
	 (139,2);