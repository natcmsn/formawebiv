INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('2','ESPAÑA'),
	 ('3','COMUNITARIO'),
	 ('null','Non Comunitario'),
	 ('null','Ecuador'),
	 ('null','Brasil'),
	 ('null','Angola'),
	 ('null','Uruguay'),
	 ('null','Colombia'),
	 ('null','Rusa'),
	 ('null','Venezuela');
INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('null','Ghana'),
	 ('null','Argentina'),
	 ('null','Portugal'),
	 ('null','Polonia'),
	 ('null','República Dominicana'),
	 ('null','Nigeria'),
	 ('null','Marruecos'),
	 ('null','Laos'),
	 ('null','Paraguay'),
	 ('null','Italiana');
INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('null','Mozambique'),
	 ('null','Senegal'),
	 ('null','Túnez'),
	 ('null','Cuba'),
	 ('null','Ucrania'),
	 ('null','Bolivia'),
	 ('null','Guinea Conakry'),
	 ('null','Perú'),
	 ('null','Bulgaria'),
	 ('null','México');
INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('null','Rumanía'),
	 ('null','Panama'),
	 ('null','Guatemala'),
	 ('null','Irlanda'),
	 ('null','Chile'),
	 ('null','Honduras'),
	 ('null','Eslovenia'),
	 ('null','Liberia'),
	 ('null','Mauritania'),
	 ('null','Venezolana');
INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('null','Ecuatoriana'),
	 ('null','Colombiana'),
	 ('null','Extracomunitario'),
	 ('null','Kenia'),
	 ('null','Haiti'),
	 ('null','Italia'),
	 ('null','Mali'),
	 ('null','Congo'),
	 ('null','Y Brasil'),
	 ('null','Nicaragua');
INSERT INTO public.ma_nacionalidades (codigo,nome) VALUES
	 ('null','Gambia'),
	 ('null','Lutuania'),
	 ('000','Desconocida');