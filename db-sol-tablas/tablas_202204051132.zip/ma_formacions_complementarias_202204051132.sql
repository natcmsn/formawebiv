INSERT INTO public.ma_formacions_complementarias (nome) VALUES
	 ('Doutorado'),
	 ('Post-Grao'),
	 ('Máster'),
	 ('Outros');