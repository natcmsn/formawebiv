INSERT INTO public.fw_datos_profesionais (postolaboral,centro_id) VALUES
	 ('Programador',10),
	 ('',10),
	 ('Orientadora laboral',10),
	 ('Técnica de Orientación',10),
	 ('Orientadora',18),
	 ('Técnica de Inserción',10),
	 ('Orientadora',10),
	 ('Auxiliar Administrativa',10),
	 ('Técnica de Inserción',10),
	 ('Xefe servizo',10);
INSERT INTO public.fw_datos_profesionais (postolaboral,centro_id) VALUES
	 ('',10),
	 ('Responsable-Coordinador do CITIC',10),
	 ('Orientadora',10),
	 ('Director UTIL',16),
	 ('Orientadora Laboral',10),
	 ('Orientadora',17),
	 ('Orientadora',17),
	 ('Orientadora',17),
	 ('Administrativa PME',18),
	 ('Administradora UTIL',16);
INSERT INTO public.fw_datos_profesionais (postolaboral,centro_id) VALUES
	 ('',10),
	 ('Técnica de Orientación e Inserción',11),
	 ('Administradora do Programa BIAL',12),
	 ('Técnica de Orientación e Inserción',10),
	 ('Técnica de orientación',10),
	 ('Coordinadora PME',18),
	 ('Tecnico Emprego',10),
	 ('Titora UTIL',24),
	 ('Auxiliar administrativa',18),
	 ('Docente',11);
INSERT INTO public.fw_datos_profesionais (postolaboral,centro_id) VALUES
	 ('Docente',11),
	 ('Técnica de xestión',10),
	 ('Técnica de xestión',10),
	 ('',10),
	 ('Técnica de xestión',10),
	 ('',10);