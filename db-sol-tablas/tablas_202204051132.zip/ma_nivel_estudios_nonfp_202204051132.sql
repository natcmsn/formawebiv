INSERT INTO public.ma_nivel_estudios_nonfp (codigo,nome) VALUES
	 ('4','Sen estudios'),
	 ('5','Estudios Primarios'),
	 ('6','Graduado Escolar'),
	 ('7','Bacharelato'),
	 ('8','Bachiller'),
	 ('9','BUP'),
	 ('10','COU'),
	 ('14','Eso');