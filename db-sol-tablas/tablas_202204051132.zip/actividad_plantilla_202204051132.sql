INSERT INTO public.actividad_plantilla (actividad_id,plantillas_id) VALUES
	 (1,2),
	 (3,2);