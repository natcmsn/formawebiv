INSERT INTO public.users_roles (users_id,roles_id) VALUES
	 (1,1),
	 (2,2),
	 (3,2),
	 (12,2);