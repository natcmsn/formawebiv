INSERT INTO public.ma_provincias (nome) VALUES
	 ('A Coruña'),
	 ('Pontevedra'),
	 ('Ourense'),
	 ('Lugo'),
	 ('Álava'),
	 ('Albacete'),
	 ('Alicante'),
	 ('Almería'),
	 ('Asturias'),
	 ('Ávila');
INSERT INTO public.ma_provincias (nome) VALUES
	 ('Badajoz'),
	 ('Islas Baleares'),
	 ('Barcelona'),
	 ('Burgos'),
	 ('Cáceres'),
	 ('Cádiz'),
	 ('Cantabria'),
	 ('Castellón'),
	 ('Ceuta'),
	 ('Ciudad Real');
INSERT INTO public.ma_provincias (nome) VALUES
	 ('Córdoba'),
	 ('Cuenca'),
	 ('Girona'),
	 ('Granada'),
	 ('Guadalajara'),
	 ('Guipúzcoa'),
	 ('Huelva'),
	 ('Huesca'),
	 ('Jaén'),
	 ('León');
INSERT INTO public.ma_provincias (nome) VALUES
	 ('Lleida'),
	 ('Madrid'),
	 ('Málaga'),
	 ('Melilla'),
	 ('Murcia'),
	 ('Navarra'),
	 ('Palencia'),
	 ('Las Palmas'),
	 ('La Rioja'),
	 ('Salamanca');
INSERT INTO public.ma_provincias (nome) VALUES
	 ('Santa Cruz de Tenerife'),
	 ('Segovia'),
	 ('Sevilla'),
	 ('Soria'),
	 ('Tarragona'),
	 ('Teruel'),
	 ('Toledo'),
	 ('Valencia'),
	 ('Valladolid'),
	 ('Vizcaya');
INSERT INTO public.ma_provincias (nome) VALUES
	 ('Zamora'),
	 ('Zaragoza'),
	 ('Desconocida');