INSERT INTO public.fw_seg_grupos_roles (grupo_id,rol_id) VALUES
	 (1,1),
	 (1,2),
	 (1,3),
	 (1,4),
	 (1,5),
	 (1,6),
	 (1,7),
	 (1,8),
	 (1,9),
	 (1,10);
INSERT INTO public.fw_seg_grupos_roles (grupo_id,rol_id) VALUES
	 (1,11),
	 (1,12),
	 (2,2),
	 (2,4),
	 (2,5),
	 (2,6),
	 (3,2),
	 (3,7),
	 (3,8),
	 (3,9);
INSERT INTO public.fw_seg_grupos_roles (grupo_id,rol_id) VALUES
	 (4,2),
	 (4,10),
	 (4,11),
	 (5,2),
	 (5,12),
	 (6,7),
	 (6,8),
	 (6,9),
	 (6,11),
	 (6,12);
INSERT INTO public.fw_seg_grupos_roles (grupo_id,rol_id) VALUES
	 (6,10);