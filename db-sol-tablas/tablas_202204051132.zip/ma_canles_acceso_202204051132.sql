INSERT INTO public.ma_canles_acceso (codigo,nome) VALUES
	 ('01','Libre'),
	 ('02','Participación en acción da Concellaría'),
	 ('03','Derivación doutra entidade'),
	 ('04','Derivación do Servizo Público de Emprego');