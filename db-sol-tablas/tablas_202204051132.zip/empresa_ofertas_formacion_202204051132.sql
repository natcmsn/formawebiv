INSERT INTO public.empresa_ofertas_formacion (dataata,datadende,lugar,nome,numhoras,numprazas,tipo,accionsfe_id,id_empresa) VALUES
	 ('2001-06-21','2001-06-04','','Empregado/a de hipermercado (Repoñedor/a)',80,13,'',10,1),
	 ('2001-01-30','2001-01-01','','Maquinista de Confección de Corsetería e baño',350,13,'',10,4),
	 ('2001-01-30','2001-01-01','','Inxección, restaurado e rebabado de volantes',80,14,'',10,13),
	 ('2001-01-30','2001-01-01','','Soldadura con electrodo revestido. Nivel I',200,13,'',10,17),
	 ('2001-01-30','2001-01-01','','Preimpresión de artes gráficas',415,14,'',10,22),
	 ('2001-01-30','2001-01-01','','Electricidade e mecánica do automóbil',250,15,'',10,23),
	 ('2001-01-30','2001-01-01','','Instalador de Sistemas de Calefacción e Gas',400,10,'',10,35),
	 ('2001-01-30','2001-01-01','','Multimedia e video dixital',580,8,'',10,75),
	 ('2001-01-30','2001-01-01','','Electricista',300,13,'',10,74),
	 ('2001-01-30','2001-01-01','','Electricista',300,10,'',10,74);
INSERT INTO public.empresa_ofertas_formacion (dataata,datadende,lugar,nome,numhoras,numprazas,tipo,accionsfe_id,id_empresa) VALUES
	 ('2001-01-30','2001-01-01','','Caixeira',80,15,'',10,1),
	 ('2001-01-30','2001-01-01','','Caixeira',100,15,'',10,1),
	 ('2001-01-30','2001-01-01','','Empregado de hipermercado',50,13,'',10,1),
	 ('2001-05-30','2001-05-02','','Caixeira de gran superficie',120,15,'',10,1),
	 ('2001-08-29','2001-06-01','','Operario cualificado en empresas instaladoras',300,13,'',10,74),
	 ('2001-01-31','2001-10-18','','Dependente/a de distribución alimentaria',350,17,'',10,98),
	 ('2001-08-08','2001-04-16','','Instalación de sistemas de calefacción e gas',400,15,'',10,35),
	 ('2002-01-11','2001-11-05','','Instalación de cartón-xeso',200,14,'',10,135),
	 ('2001-12-20','2001-10-15','','Construcción (Gruista)',225,13,'',10,73),
	 ('2002-09-05','2002-06-25','','Dependente/a polivalente de superficie alimentaria',300,17,'',10,98);
INSERT INTO public.empresa_ofertas_formacion (dataata,datadende,lugar,nome,numhoras,numprazas,tipo,accionsfe_id,id_empresa) VALUES
	 ('2002-05-31','2002-05-13','','Caixeira de gran superficie',125,17,'',10,166),
	 ('2003-05-22','2003-04-28','','Caixeira de gran superficie',125,20,'',10,166),
	 ('2003-06-20','2003-06-04','','Clasificadoras de madeira',32,16,'',10,116),
	 ('2003-10-16','2003-08-05','Vegonsa. O  Troncal s/n','Dependente/a da distribución alimentaria',300,15,'Curso Compromiso contratac.',10,98),
	 ('2004-06-09','2004-05-10','','Caixeira de gran superficie',125,24,'',10,166),
	 ('2005-06-15','2005-06-06','','Técnicas de servizo en barra  e sala',40,15,'',10,36),
	 ('2005-06-09','2005-05-10','','Caixeiro/a de gran superficie',125,22,'',10,166),
	 ('2004-11-19','2004-09-22','','Dependente/a da distrib. alimentaria',240,15,'',10,98),
	 ('2006-06-28','2006-05-30','Alcampo, S.A','Caixeiro/a de gran superficie',125,22,'Formación con compromiso de contratación',10,166),
	 ('2006-11-24','2006-11-24','Vigo','un calquera, inventado',150,10,'presencial',10,1025);
INSERT INTO public.empresa_ofertas_formacion (dataata,datadende,lugar,nome,numhoras,numprazas,tipo,accionsfe_id,id_empresa) VALUES
	 ('2006-07-21','2006-06-17','Instalación LINORSA no Vao-Coruxo-Vigo','Experto en Limpeza',100,15,'Ocupacional',81,262),
	 ('2007-06-09','2007-05-03','Alcampo, S.A','Azafato/a de caixa',125,20,'Compromiso de contratación',10,166),
	 ('2007-06-13','2007-06-13','Vego Supermercados','Caixeiro/a',140,15,'Compromiso de contratación',10,98),
	 ('2007-08-10','2007-07-04','Instalacións de Linorsa e centros de traballo','Limpeza de inmobles',100,15,'Formación con compromiso de contratación',10,262),
	 ('2007-11-09','2007-11-05','Aula Limber Multiservicios, S.L.','Condutor/a de carretilla elevadora (Grupo 1)',30,8,'Formación con compromiso de contratación',10,1102),
	 ('2007-12-09','2007-11-19','Aula Limber Multiservicios','Condutor/a de carretilla elevadora (Grupo 2)',30,8,'Formación con compromiso de contratación',10,1102),
	 ('2007-12-14','2007-12-10','Aula Limber Multiservicios','Condutor/a de carretilla elevadora (Grupo 3)',30,8,'Formación con compromiso de contratación',10,1102),
	 ('2013-02-26','2013-02-26','','pureba',8,2,'',10,1210);