INSERT INTO public.ma_tipos_seguimento (nome,oculto) VALUES
	 ('Abeiro',true),
	 ('Asiste',true),
	 ('Autoemprego',false),
	 ('B.A.E.',true),
	 ('Contrato indefinido',false),
	 ('Contrato temporal',false),
	 ('Desempregado/a',false),
	 ('E.T.T.',true),
	 ('Enfermidade',false),
	 ('Escola obradoiro/Obradoiro de emprego',false);
INSERT INTO public.ma_tipos_seguimento (nome,oculto) VALUES
	 ('Estudiante',false),
	 ('Exclusión social',true),
	 ('Falecido/a',true),
	 ('Formación Ocupacional',false),
	 ('Grupos B.E.',true),
	 ('Habilidades Sociais',true),
	 ('Ilocalizable',false),
	 ('PROMIL',true),
	 ('Situación económica precaria',true),
	 ('Tempo parcial',true);
INSERT INTO public.ma_tipos_seguimento (nome,oculto) VALUES
	 ('Traballo en precario',true),
	 ('Inactivo',true),
	 ('Bial',false),
	 ('Sin Especificar',false);