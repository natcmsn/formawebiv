INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Director','2001-01-01','','Marcelino Pastor','986417000',NULL,1,139),
	 ('','','','','2001-06-26','','José Luis Díaz','986221478 / ',NULL,2,139),
	 ('','','','Xefe Persoal','2001-01-01','','Javier Mariño','986331207 / ',NULL,3,139),
	 ('','','','Xefe Persoal','2001-01-01','selmark@arraki.es','Javier Ballesta López','986493232 / ',NULL,4,139),
	 ('','','','Propietarios','2001-01-01','','Manuel Domínguez. Pilar Fernández','986469083 / ',NULL,5,139),
	 ('','','','Xefe de persoal','2001-04-27','','Javier Ballesta','986493232 / ',NULL,6,139),
	 ('','','','Xefe de RRHH ','2001-01-01','egallego@hjbarreras.es','Jose M. Maceiras Varela ','986231400 / ',NULL,7,139),
	 ('','','','Apoderado','2001-01-01','matrigalsa@futurnet.es','Francisco León Rodríguez','986277300 / ',NULL,8,139),
	 ('','','','RR.HH','2001-01-01','','Antonio Pampillón','986269000 / ',NULL,9,139),
	 ('Contacto realizado por Chelo Iglesias cuando la empresa se denominaba Peguform Ibérica. Esta traballadora xa non está na empresa.','Del Campo','Redondo (non está)','Rpble. RR.HH','2001-01-01','Ldelcampo@Peguformib.com','Lucía','986408050 / ',NULL,10,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','RR.HH','2001-01-01','','Ninfa Siveira','986213838 / ',NULL,11,139),
	 ('','','',' RR.HH (Xefe dpto/ Respons. de selec. e formac) ','2001-01-01','dik.personal@puntocero.es','Luis Ángel Salas. Estefanía Lores','986294500 / ',NULL,12,139),
	 ('','','','Xefe de persoal / Producción','2001-01-01','','Miguel Mallo. Manuel Ayude','986293129 / ',NULL,13,139),
	 ('','','','Departamento de persoal','2001-01-01','','Jose Pascual Osorio. Ana Mª Vázquez','986288081 / ',NULL,14,139),
	 ('','','','Administradora / Responsable de RR. HH','2001-01-01','','Maruxa Sanmartín. Carmen Lema','986290100 / ',NULL,15,139),
	 ('','','','Responsable do departamento de persoal','2001-01-01','maupri@mp.maier.es','Mauro Prieto Gil','986343420 / ',NULL,16,139),
	 ('','','','Director xerente /Director técnico','2001-01-01','','Fernando Couñago Pérez/Javier Pérez','986293114 / ',NULL,17,139),
	 ('','','','Xefe Persoal','2001-01-01','','Miguel Álvarez. Diego Marana','986422355 / ',NULL,18,139),
	 ('','','','Director de persoal','2001-01-01','','Fernando Ilarri','986818100 / ',NULL,19,139),
	 ('','','','Respons. formación / Xefe Persoal','2001-01-01','','Jose R.Comesaña. López Macías','986415111 / ',NULL,20,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Fondevila','','Responsable de RR.HH','2002-01-01','','Inés','986811802 / ',NULL,21,139),
	 ('','','','Secretaria','2001-01-01','','Isabel Castro','981534142 / ',NULL,22,139),
	 ('','','','Secretario xeral./ Asesor','2001-01-01','','Juan Russ. Jose M. Rodríguez Simón','986224702 / ',NULL,23,139),
	 ('','','','','2001-01-01','atg@atexga.com','Eva Mº Ben Garea','981552040 / ',NULL,24,139),
	 ('','','','Representante','2001-01-01','','Jose Manuel R.Rivero','986443047 / 646953072',NULL,40,139),
	 ('','','','Administrador','2001-01-01','','Jesus Dasilva','986226526 / ',NULL,42,139),
	 ('','','','Gerente (non está) / Responsable formación','2001-01-01','kfernández@ceaga.com','Luis Moreno Diéguez. Karina Fernández','986213790 / ',NULL,25,93),
	 ('','','','Dpto Administración','2001-01-01','asociacion@asemaco.es','Esther','986462021 / 986462991',NULL,26,139),
	 ('','','','Secretaria ejecutiva ','2001-01-01','','María Álvarez','986443412 / ',NULL,27,139),
	 ('',' ',' ','Secretario Xeral','2001-01-01','asime@asime.es','Javier Martínez López','986410727',NULL,28,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xerente','2001-01-01','','Armando Luis Mathieu Cuña','986896732 / ',NULL,29,139),
	 ('','','','Presidente','2001-01-01','','Antonio Reguera Repiso','986484191 / ',NULL,30,139),
	 ('','','','Adxunto a secretaría xeral/ Dpto de Formación','2001-01-01','jccastro@anfaco.es','Jose Carlos Castro /Clara','986469301 / ',NULL,31,139),
	 ('','','','Presidente','2001-01-01','','Servando Torres Fernández','986203855 / ',NULL,32,139),
	 ('','','','Responsable de Formación','2001-01-01','','Montserrat','986437522 / ',NULL,33,139),
	 ('','','','Responsable de Formación','2001-01-01','','Carmen Salvador','981179300 / ',NULL,34,139),
	 ('','','','Presidente / Vicepresidente / Secretaria','2001-01-01','foncalor@ctv.es','Manuel Pérez.Eduardo Magdalena. Geni','986263627 / ',NULL,35,139),
	 ('','','','Presidente','2001-01-01','','Jose Carlos Lemos/ Jose Gago','986432400',NULL,36,139),
	 ('','','','Secretaria','2001-01-01','','Raquel','986298637 / ',NULL,37,139),
	 ('','','','Secretaría','2001-01-01','','Maysa','986443504 / ',NULL,38,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Departamento comercial','2001-01-01','','Begoña','986447421 / ',NULL,39,139),
	 ('','','','Arquitecto Técnico','2001-01-01','','Ignacio  Vilas González','986227058 / ',NULL,41,139),
	 ('','','','','2001-01-01','','Esther','986468327 / ',NULL,43,139),
	 ('','','','','2001-01-01','','Jose(ofertas)Ofic.Empleo Coia (tel:986291912)','986462059 / ',NULL,44,139),
	 ('','Corral','Bernárdez','Xerente','2001-01-01','','Valentín','986232763 / 656838250',NULL,45,139),
	 ('','','','Gerente','2001-01-01','','Nicolas brasa De Lis','986265044 / 678671295',NULL,46,139),
	 ('','','','Xerente','2001-01-01','','Francisco Sanchez Blanco','986468046 / ',NULL,47,139),
	 ('','','','Gerente','2001-01-01','','J.Fernandez  Otero','986468190 / ',NULL,48,139),
	 ('','','','','2001-01-01','','Begoña','986221803',NULL,50,139),
	 ('','','','Dpto Personal','2001-01-01','','MªJosé','986201818 / ',NULL,51,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Administrador','2001-01-01','','Enrique Alonso Cebreiro','986293624 / ',NULL,52,139),
	 ('','Pérez','Molares','Director-Gerente','2001-01-01','','Jose Carlos','986471133',NULL,53,139),
	 ('','','','Gerente','2001-01-01','','Enrique Fidalgo Gomez','986467029 / ',NULL,54,139),
	 ('','','','Director-gerente','2001-01-01','','José Gonzalez Araujo','986337327 / ',NULL,55,139),
	 ('','','','Depart.Comercial','2001-01-01','Vigo@ eternia.org','Silvia','986441028 / ',NULL,56,139),
	 ('','','','Gerente','2001-01-01','','francisco Ogando R.','986295958 / 908087526',NULL,57,139),
	 ('','','','Encargado','2001-01-01','','Cerviño','986233592 / ',NULL,58,139),
	 ('','','','Gerente','2001-01-01','','Cristobal Vila Hermida','986469762 / ',NULL,59,139),
	 ('','','','Personal De Oficina','2001-01-01','gracami@arrakis.es','Jose Roca','986469983 / ',NULL,60,139),
	 ('','','','Persoal de oficina','2001-01-01','','Yolanda','986468469 / ',NULL,61,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dto Persoal','2001-01-01','ramilo@ramilo.es','Ana Muñoz','986298300 / ',NULL,62,139),
	 ('','','','Gerente','2001-01-01','','jose Manuel Fernandez','986235610 / ',NULL,63,139),
	 ('','','','Gerente','2001-01-01','','Antonio','986490107 / ',NULL,64,139),
	 ('','','','Gerentes','2001-01-01','forsai@arrakis.es','Carlos-Jorge','986460147 / ',NULL,66,139),
	 ('','','','Gerente','2001-01-01','','Jorge Fernandez  Vizoso','986424883 / 607783697',NULL,67,139),
	 ('','','','Secretaría','2001-01-01','','Isabel','986468005 / ',NULL,68,139),
	 ('','','','Gerente','2001-01-01','','Ramón Magdalena Nogueira','986687002 / ',NULL,69,139),
	 ('','','','Gerente','2001-01-01','','Carlos Fernandez','986480805 / ',NULL,70,139),
	 ('','','','Xerente','2001-01-01','','Fernandez Gomez','986243300 / ',NULL,71,139),
	 ('','','','Xerente','2001-01-01','manuelspain@mns.com','Manuel Castiñeiras Rodríguez','986472217 / 616575000',NULL,65,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Seleccion de  personal','2001-01-01','','Macarena Quintero / Esther Mezquita','986494979 / ',NULL,72,139),
	 ('13/6/07 en conversación mantida informan que xa non traballa na empresa','Méndez','(non está)','Xefe de producción','2001-05-07','aquatic@aquaticpiscinas.com','Luis','986294711 / 646960197',NULL,80,139),
	 ('','','','','2001-05-08','','Ramón Vázquez','986433344 / ',NULL,81,139),
	 ('','','','Xefe comercial red propia Galicia','2001-06-21','vigo.saludcom@aegon.es','Carlos Rama Hermida','986220178 / ',NULL,84,139),
	 ('','','','Responsables de formación','2001-01-11','','Juan Vázquez / Elena','986229042 / ',NULL,73,139),
	 ('','','','Gerente','2001-01-01','','Leonardo Pérez Alonso','986224903 / ',NULL,74,139),
	 ('','','','Formación','2001-01-01','','Mariló','986438341 / ',NULL,75,139),
	 ('','','','Xerente','2001-03-30','galired@galired.com','Manuel antonio Martínez Vega','986266466 / ',NULL,76,139),
	 ('','','','','2001-04-17','','Marta Pérez','986436121 / ',NULL,77,139),
	 ('','','','','2001-04-24','','Amalia Diéguez','986488208 / ',NULL,78,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2001-05-07','','Eva Serrano','981206189 / ',NULL,79,139),
	 ('Tras conversación mantida con Ignacio Chamorro en Navalia confirma que Susana Barreras é a nova xerente.','Barreras','Sanjurjo','Xerente','2006-05-24','','Susana','',NULL,501,93),
	 ('','','','','2001-05-15','','Pablo',' / 667941253',NULL,82,139),
	 ('','','','','2001-06-27','','Tonia Moldes Beloso','986297400 / ',NULL,83,139),
	 ('','','','','2001-07-03','','Susana Pérez','986441022 / ',NULL,85,139),
	 ('','','','Técnica de seleccion / Directora','2001-07-10','vigo@olstein.es','Sandra Candal  / Greta Gutiérrez','986412977 / ',NULL,86,139),
	 ('','','','','2001-07-18','','Silvia Barbero Fdez','915725932 / ',NULL,87,139),
	 ('','','','','2001-07-12','egerie@jazzfree.com','Mercedes García','902181457 / ',NULL,88,139),
	 ('','','','Asesores','2001-07-09','','Duvi Collazo e Jose Mª Daluz','986431538 / ',NULL,89,139),
	 ('','','','','2001-01-01','','Purificación Moreira','986261900 / ',NULL,90,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Propietario','2001-01-01','','Miguel Rodríguez Fuentefria','986242276 / 986242276',NULL,91,139),
	 ('','','','','2001-01-01','','José Álvarez','986493459 / ',NULL,92,139),
	 ('','','','','2001-01-01','','Eladio Durán Besada','986231615 / ',NULL,93,139),
	 ('','','','Resp. Persoal','2001-01-01','pilar.paz@grupo-unica.com','Pilar Paz Silva','986493122 / ',NULL,94,139),
	 ('','','','Dpto Formación','2001-08-20','','Roberto Gaspar Conde','981554483 / ',NULL,95,139),
	 ('','','','','2001-08-22','oftega@oftega.com','Carlos Filgueira','986222203 / ',NULL,96,139),
	 ('','','','','2001-08-22','oftega@oftega.com','Carlos Filgueira','986228945 / ',NULL,97,139),
	 ('','','','Dpto Formación','2001-01-01','formación@vegalsa.es','Carmen Salvador/Susana Castro ','981179300 / ',NULL,98,139),
	 ('','','','Propietaria','2001-01-01','','María Mariño','986375322 / ',NULL,99,139),
	 ('','','','Director','2001-01-01','','Salvador Alba Fernández','986292242 / ',NULL,100,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2001-08-28','','Josefa Barrosa','917003306 / 670368009',NULL,101,139),
	 ('','','','','2001-09-19','','Yolanda Díaz','914584615 / ',NULL,102,139),
	 ('','','','','2001-09-25','','Clara','986213790 / ',NULL,103,139),
	 ('','','','','2001-09-21','','Ana González','917157067 / ',NULL,104,139),
	 ('','','','','2001-10-04','','Cristobal Olmedo','986334787 / ',NULL,105,139),
	 ('','','','','2001-10-15','','Verónica','986469779 / ',NULL,106,139),
	 ('','','','','2001-10-26','','Macamen Alonso Rodríguez','986410738 / 669470755',NULL,107,139),
	 ('','','','','2001-11-12','','Ana','986468577 / ',NULL,108,139),
	 ('','','','','2001-11-08','','Rogelio Rodríguez Campos','986411780 / ',NULL,109,139),
	 ('','','','','2001-11-15','','David Otero','986485539 / ',NULL,110,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2001-11-09','','Inés Hoyos','918038198 / ',NULL,111,139),
	 ('','','','','2001-11-16','transtips@airtel.net','Mercedes Ribera/Beniggno González','986422289 / ',NULL,112,139),
	 ('','','','Xerente (Dona)','2001-11-29','','Antonia Mouriño / Manoli','986233118 / ',NULL,113,139),
	 ('','','','Técnica de selección','2001-12-05','','Gabriela Baranda (non está na empresa)','986437800 / ',NULL,114,139),
	 ('','','','Jefe de Relaciones laborales','2001-12-07','maguerram@fcc.es','Miguel A. Guerra Martín','986485300 / ',NULL,115,139),
	 ('','','','Técnicas de Selección','2001-12-04','silivia.fernandez@adecco.es','Sonia Castro/Eva Rdguez','986481210 / ',NULL,116,139),
	 ('','','','Técnica de selección','2001-11-28','','Loli ','986443130 / ',NULL,117,139),
	 ('','','','Técnica de selección','2001-12-11','vig1004@altagestion.es','Teresa Lemos / Sonia','986434988 / ',NULL,118,139),
	 ('','','','','2001-11-29','','Dolores Rodrríguez','986238449 / ',NULL,119,139),
	 ('','','','Técnica de selección','2001-11-28','vigo@creyfs.es','Ana Gabián ','986220403 / ',NULL,120,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Técnica de selección','2001-11-27','','Ana','986443117 / ',NULL,121,139),
	 ('','','','Departamento de ventas','2001-11-29','','Andrés Ortigueira','986447215 / ',NULL,122,139),
	 ('','','','Técnicos de selección','2001-11-29','arancha.minguez@manpower.es','Guillermo Giráldez / Arancha Mínguez','986294612 / ',NULL,123,139),
	 ('','','','Técnica de selección','2001-12-11','','Meli','986422477 / ',NULL,124,139),
	 ('','','','Técnica de selección','2001-11-28','','Crsitina','986493131 / ',NULL,126,139),
	 ('','','','Xefa de axencia','2001-12-04','','Paula Rey','986229768 / ',NULL,127,139),
	 ('','','','Office Manager/Consultora','2001-11-28','vigo@randstad.es','Emilia Fdez./Rocío Rdguez.','986223317 / ',NULL,128,139),
	 ('','','','Axudas contratación','2002-07-16','','Clara','',NULL,31,139),
	 ('Xa non está nesta ETT','','','Consultora','2001-11-27','','Marta Ribas','986473456 / ',NULL,129,139),
	 ('','','','Técnica de selección','2001-12-04','vigo@central.trabatem.es','Begoña ','986222906 / ',NULL,130,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Envianos dúas ofertas de traballo','','','Técnica de selección','2006-06-20','netnancys@homail.com','Nancy','986244674 / ',NULL,131,139),
	 ('','','','Técnica de selección','2001-11-12','xegaett@terra.es','Miriam Jiménez','986484380 / 986484522',NULL,132,139),
	 ('','','','Técnica de selección','2001-11-27','sttseleccion@stt.es','Silivia Méndez','986493300 / ',NULL,133,139),
	 ('','','','Xefe de equipo','2001-12-18','','Jesús Soto','986113770 / ',NULL,134,139),
	 ('','','','','2001-01-02','','Miguel Mera','986266555 / ',NULL,135,139),
	 ('','','','Técnica de selección','2002-01-15','','Natalia Hernández','986207400 / ',NULL,136,139),
	 ('','','','','2001-01-01','','Puime',' / ',NULL,137,139),
	 ('','','','Xerente ','2006-06-05','','Gonzalo Alvarez Francisco',' / 654546060',NULL,139,139),
	 ('','','','','2002-02-01','','Zuly','986373020 / ',NULL,140,139),
	 ('','','','Dona','2002-02-08','','Pilar Janeiro','986471111 / ',NULL,141,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Director Técnico','2002-02-14','redenor@taelpo.com','Pablo Rocha','986866678 / ',NULL,143,139),
	 ('','','','','2002-02-21','','Ana Vaqueiro','670513461 / ',NULL,144,139),
	 ('','','','Adxunta Xerente','2002-02-13','conxemar@conxemar.com','Dolores Castro Muñiz','986433351 / ',NULL,145,139),
	 ('','','','','2002-02-27','jgg-urbaser-redonde@dragados.com','J. Pablo Guerrero','986408034 / 670998233',NULL,146,139),
	 ('','','','Delegado Técnico de Ventas','2002-02-26','','Francisco Conde','986344197 / 627558127',NULL,147,139),
	 ('','','','Donos','2002-03-12','','Manuel o Aurea',' / 678787821',NULL,148,139),
	 ('','','','','2002-03-15','','Maria Iglesias Varela','986262921 / ',NULL,149,139),
	 ('','','','','2002-03-18','','Santiago Labrador','986438033 / ',NULL,150,139),
	 ('Están construindo unha nave que comenzará a traballar en agosto pero non saben os traballadores que necesitarán. As persoas que traballan no conxelado soen rodar por todas as empresas do sector. Reclutan persoal a través da fichas e dos CV. A formación de fileteado sae moi cara e cando ven unha persoa espabilada o que fan e pasala a fileteado.','','','Dpto Persoal','2002-03-11','','Carmen Campos','986201011 / ',NULL,151,139),
	 ('','','','Apoderado','2002-04-10','info@astipol.com','Juan Carlos Pazó Olmedo','986338042 / ',NULL,152,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2006-06-05','rodolfo@ronautica.com','Rodolfo Andrade Olivié','986234298 / ',NULL,153,139),
	 ('','','','','2002-04-19','','Olga','902118936 / 670615193',NULL,154,139),
	 ('','','','Dona','2002-05-06','','Gloria','986294376 / ',NULL,155,139),
	 ('','','','','2002-05-09','','Marisol','986200929 / ',NULL,156,139),
	 ('','','','','2002-05-02','','Jose Miguel Saguillo','986211614 / 666442565',NULL,157,139),
	 ('','','','','2002-05-06','','Ramonita','986416833 / ',NULL,158,139),
	 ('','','','Responsable de Recursos Humanos','2002-05-08','','Cesar Graña','986833030 / ',NULL,159,139),
	 ('','','','Xerente','2002-05-28','','Verónica Pérez Calzado','986442076 / 667648008',NULL,160,139),
	 ('','','','Director de agencias','2002-06-03','alberto.mourino@catalanaocci.es','Alberto Mouriño Barros','986220856 / 600921971',NULL,161,139),
	 ('','','','Dono','2002-06-03','mampa.ms@terra.es','Mario Soares','986482854 / 649883423',NULL,162,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dono','2002-06-04','','Jose','986417789 / 627950251',NULL,163,139),
	 ('','','','','2002-06-10','info@tecnofish.com','Almudena Rouco','986467045 / ',NULL,164,139),
	 ('','','','Dona','2002-06-14','','Sonia','986220920 / ',NULL,165,139),
	 ('ssss','','','Xefes/as de caixas','2002-02-04','','Angela,Moncha,Miguel González-Puelles','986201010 / ',NULL,166,139),
	 ('','','','','2002-06-24','oran@telefonica.net','Patricia','985226133 / ',NULL,167,139),
	 ('','','','','2002-06-28','cligama@retemail.es','Ruth','986266313 / 686485893',NULL,168,139),
	 ('','','','','2002-07-09','','Josefina Enriquez Díaz','986223985 / ',NULL,169,139),
	 ('','','','','2002-07-18','aadavila@eulen.com','Angel Dávila- Pastora','986494979',NULL,170,139),
	 ('','','','','2002-07-23','','Isabel Rodríguez','925240201 / 925241019',NULL,171,139),
	 ('','','','','2002-07-22','','Bruno Paz',' / 609881761',NULL,172,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2002-07-23','','Sr. Lorenzo','986209185 / 986239832',NULL,173,139),
	 ('','','','Xefe de producción/ responsable de persoal','2001-06-01','moatecnica@teleline.es','Tomás Pérez/ Eva Costas','986393016 / ',NULL,174,139),
	 ('','','','','2001-06-01','','Sr. Castro','986403152 / ',NULL,175,139),
	 ('','','','','2001-12-01','comercial@astinor.com','Jose Antonio Vázquez','986404202 / ',NULL,176,139),
	 ('','','','','2001-06-01','','Fidel','986472030 / ',NULL,178,139),
	 ('','','','Xerente','2001-06-01','','Alfonso Carreiro','986261750 / 986370512',NULL,179,139),
	 ('','','','Xerente','2001-06-01','oceano@ctv.es','Jose Barreras Sanjurjo','986224878 / ',NULL,180,139),
	 ('','','','','2001-06-01','','José Simón - Manolo','986460455 / ',NULL,181,139),
	 ('','','','','2001-06-01','','José Diz','986452097 / ',NULL,182,139),
	 ('','','','Xerente- Propietario','2001-06-01','','Fernando Camiña Fernández','',NULL,183,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2001-06-01','','Francisco Andrade / Jose Luis Rubianes','986223504 / ',NULL,184,139),
	 ('','','','','2001-06-01','','Julio Melero Fernández','986421549 / ',NULL,185,139),
	 ('','','','Xerente','2001-06-01','','JOrge Rodríguez Vázquez','986214220 / ',NULL,186,139),
	 ('','','','Director general','2001-06-01','','Joaquín Fernández Davila','986244612 / ',NULL,187,139),
	 ('','','','','2001-06-01','','Serodio','986336974 / ',NULL,188,139),
	 ('','','','Gerente','2001-06-01','','Jesús Pampillón','986337200 / ',NULL,191,139),
	 ('','','','','2002-09-05','','Mª Jesús Bendaña','986242029 / ',NULL,193,139),
	 ('','','','','2002-09-02','','Fidel Ferreiro Rodríguez','986240586 / ',NULL,194,139),
	 ('','','','Dona','2002-09-10','','Ana Belén Moldes Fajardo','986241717 / ',NULL,195,139),
	 ('','','','','2002-09-12','','Xurxo','986460910 / ',NULL,196,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2002-09-20','','Antonio Ferreirua','986439080 / ',NULL,197,139),
	 ('','','','Dona','2002-09-25','','Teresa Sosa Jeremías','986117388 / 629486376',NULL,198,139),
	 ('','','','','2002-10-03','rafaelnunezdominguez@hotmail.com','Rafael Nuñez',' / 636993841',NULL,199,139),
	 ('','','','','2002-10-03','info@grupo-duplex.com','Laura','986470934 / ',NULL,200,139),
	 ('','','','','2002-10-03','seleccion.central@intereuropea.es','Eva','915476303 / ',NULL,201,139),
	 ('','','','Dpto RRHH','2002-10-04','','Ana Martínez','981783430 / ',NULL,202,139),
	 ('','','','','2002-10-09','','Luis','986412341 / ',NULL,203,139),
	 ('','','','Dona','2002-10-23','','Aurora','986429292 / ',NULL,205,139),
	 ('','','','','2002-05-24','','Lina Río','986207730 / 607323868',NULL,206,139),
	 ('','','','Axente seguros/xefe de equipo','2002-11-08','','Sebastián Romero','986222223 / 652091773',NULL,207,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Teñen unha consultoría que fai formación. Cadro de persoal  400 persoas, 1º temporal e logo indefinidos. Cando entran a traballar teñem¡n un período de formac. de 10 semanas no que lle dan unha beca. Traballan con Manpower.
Mulleres e homes, tratan de primar a incorporación de mulleres','','','Responsable de formación','2002-11-16','mallegue@vigo2.faurecia.com','María Allegue','986828800 / ',NULL,208,139),
	 ('','','','Director Nova Rede','2002-11-18','','Otero Rodríguez','986222700 / ',NULL,209,139),
	 ('','','','','2002-11-26','','Mª Dolores Porto Blanco','917104489 / 916378236',NULL,210,139),
	 ('','','','','2002-12-28','','Yolanda Solorzano','986484014 / 615622723',NULL,211,139),
	 ('','','','','2002-10-01','','Araceli González Manzano','986230078 / ',NULL,212,139),
	 ('','','','','2002-10-01','','Jose Luis Rebón Sánchez','986206603 / ',NULL,213,139),
	 ('','','','','2002-10-01','','Juan José Presa Suárez','986224222 / ',NULL,214,139),
	 ('','','','','2002-12-02','','María Fernández Torres','915821190 / ',NULL,215,139),
	 ('','','','Xerente','2003-02-05','','Jose Manuel Queral Fdz',' / 629887044',NULL,217,139),
	 ('','','','Dono','2002-01-11','','Ramiro Gill','986422455 / 670623356',NULL,218,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2003-01-15','','Jose Manuel','986236952 / 696081568',NULL,219,139),
	 ('','','','Dono','2003-01-15','','Manuel Gómez Domínguez','986251963 / ',NULL,220,139),
	 ('','','','','2003-01-21','sacevigo@sacevigo.e.telefonica.net','Mª Jesús Estévez','986441962 / ',NULL,221,139),
	 ('','','','','2003-01-21','','Marta Martínez','917489087 / ',NULL,222,139),
	 ('','','','','2003-01-28','','Javier Colomar',' / 677640258',NULL,223,139),
	 ('','','','','2003-01-30','','Mª Jose','986344043 / ',NULL,224,139),
	 ('Presenta Oferta de Emprego dun Administrativo para o Dpto. de Compras con inglés (contrato temporal dun ano, nese período aprenderá cotraballador ó que vai substituir cando se xubile).
Queda en estudiar posibilidad de curso de Carpintería Naval con compromiso de contratación.','Fernández','Arrabal','Responsable Recursos Humanos','2003-02-12','rrhh@gonsusa.es','Jaime','986494177 / ',NULL,225,93),
	 ('','','','Gerente','2005-08-08','','Andrés Lago Sánchez (Sito)','986212767 / ',NULL,226,93),
	 ('Entrevista mantida por Elisa e Chelo.
A contratación de novos traballadores dependerá dos niveis da producción e da saída ó mercado de novos productos (neste momento, calamares recheos).
Convén voltar a establecer novo contacto recordatorio da entrevista, con motivo da resolución aprobatoria das axudas á contratación.','Campuzano','','Director RR.HH','2003-02-11','alfredo@fandicosta.es','Alfredo','986326800',NULL,227,93),
	 ('Tamén Xerente de Admón. de MERCACEVI
                                                                                                                                               ','Méndez','Veloso','Gerente','2003-02-17','','Angel ','986435474 / 610573139',NULL,228,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xefe de RRHH','2003-06-09','','Rafael Martínez','986330466 / ',NULL,281,139),
	 ('','Salgueiro','','Propietario','2003-07-01','fersalasesores@terra.es','Fernando','986243654',NULL,283,93),
	 ('','Vázquez','Lorenzo','Propietario','2003-07-08','davidvazquez@wanadoo.es','Maike','660845463',NULL,288,93),
	 ('Tamén Xerente do Mercado de Progreso
','Méndez','Veloso','Gerente de Administración','2003-02-17','','Angel ','986431633 / ',NULL,229,93),
	 ('','','','','2002-01-10','','Manuel Martínez','986481100 / ',NULL,230,139),
	 ('','','','Xerente','2003-02-23','','Cristina Vázquez Pérez',' / 615658866',NULL,231,139),
	 ('','Pérez','Cebrian','Rpble. RR.HH','2003-02-18','','Angel','986292600 / ',NULL,232,93),
	 ('','Reboredo','','Jefe Personal','2003-02-18','rhumanos@hogarlin.es','Angeles','986214952 / ',NULL,233,93),
	 ('','Márquez','','Responsable Personal, Formación y PRL','2003-02-20','','Patricia','986231662',NULL,234,93),
	 ('','Bello','Dopazo','Rpble. R.R.H.H.','2003-02-20','','Evangelina (Eva Bello)','986209511 / ',NULL,235,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Sánchez','','Administración','2003-02-25','','Esther Sánchez','986213238 / ',NULL,236,93),
	 ('','Mera','Rodríguez','Dtor. de Personal','2003-02-26','mera@balino.es','Jesús M. ','986296000 / ',NULL,237,93),
	 ('','Rey','Vera','Director Gerente','2003-02-28','p.rey@cip-formacion.com','Pedro ','986472211 / ',NULL,238,93),
	 ('','Guisande','','Rpble. Persoal','2003-03-06','','Concepción ','986372011 / ',NULL,239,93),
	 ('','Insua','','Rpble. R.R.H.H.','2003-02-24','','Julia ','986214952 / ',NULL,240,93),
	 ('','Pizorno','Díaz','Gerente','2003-02-25','prosega@prosega.com','Juan Antonio','986431400 / 609802000',NULL,241,93),
	 ('','Vázquez','Garea','Rpble. Operacións','2003-03-04','','Alberto ','680423302//986493100',NULL,242,93),
	 ('','','','Administrativo','2003-03-07','','Guillermo M. Santiago','986877160 / 986877002',NULL,253,139),
	 ('','','','','2003-05-02','','Marco Varela','902999924 / ',NULL,268,139),
	 ('','','','','2003-03-20','','Miguel González Ardura','915174296 / ',NULL,269,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Coordinador de Formación','2003-05-20','','Jose A. Dominguez, Alejandro','676990067 / ',NULL,272,93),
	 ('','González','Gesteiro','Delegado','2003-06-06','','José','986122341 / 607303658',NULL,274,93),
	 ('','','','','2003-06-13','','Rosana','913590925 / ',NULL,276,139),
	 ('','','','Técnica Recursos Humanos','2003-06-24','','Conchi Liñayo','981577255 / ',NULL,279,139),
	 ('','','','Rpble. Administración','2003-03-07','','Rosa Casal Tielas','986220374 / ',NULL,243,93),
	 ('','','','Director Operaciones','2003-03-11','alfredo@pizzamovil.net','Alfredo Alcántara','986493055 / ',NULL,244,93),
	 ('','Riveiro','Barciela','Apoderada','2003-03-06','lapin@lapin.es','Ana','986207798 ',NULL,245,93),
	 ('','Vilariño','','Rpble. Contratación','2003-03-06','','Raúl Vilariño','986213693 ',NULL,246,93),
	 ('','Velasco','','Gerente','2003-03-11','vigo@clarosol.es','D.  Enrique','986225346 / ',NULL,247,93),
	 ('','Airas','Cotobad','Jefe Personal y RR.HH','2003-03-14','xurxoairas@grupomaconsi.com','Xurxo Airas Cotobad','986211534',NULL,248,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Rodríguez','','RR.HH','2003-03-13','','Roberto','986343434',NULL,249,93),
	 ('','Pazos','','Rpble. RR.HH ','2003-03-14','','Clara','986377111',NULL,250,93),
	 ('','','','Técnica de selección','2006-06-02','villagarcia@ader.net','Gracia Rubianes','986565096 / ',NULL,251,139),
	 ('','','','Dono','2003-03-07','','Agustin Iglesias',' / 678702839',NULL,252,139),
	 ('Comenta que nunca houvo tanto traballo no sector, pero que observa en xeral en tódalas empresas, unha forma de distribución do traballo e da xornada laboral máis racional, o que implica non ter que contratar de forma masiva. Neste senso, ve máis viable solicitar ofertas de emprego.
Habitualmente precisa persoal para aplicación de pinturas e/ou montaxe de andamios (a súa outra empresa é Loxítica e Andamios, s.l. - L&A), polo que o perfil requerido proveninte de outros sectores é o de peóns e operarios da construcción, edad sobre 30 anos e capacidade de traballo. Ve probable contactar en caso de ofertas de traballo.','Maseda','','Dtor. Técnico','2003-02-25','tranasa@futurnet.es','Fernando','986434711',NULL,254,93),
	 ('Nunca houbo tanto traballo no sector naval, pero as empresas necesitan unha forma de distribución do traballo e da xornada laboral máis racional, para non ter que contratar de forma masiva. 
As contratacións son de persoal para aplicación de pinturas e/ou montaxe de andamios (a súa outra empresa é Tranasa). O perfil requerido proveninte de outros sectores é de peóns e operarios da construcción, entorno a 30 anos e capacidade de traballo. Nunca solicita directamente pintores porque achéganlle candidatos con pouca capacidade de traballo e non tendo en conta que a pintura naval require outro tipo de esforzo.','Maseda','','Dtor. Técnico','2003-02-25','','Fernando','986434711',NULL,255,93),
	 ('Cambió de empresa','Estévez','','Dtor. Planificación','2003-02-25','caasa@fiab.es','Gerardo','986202054 / ',NULL,256,93),
	 ('','','','Asesoría Belyse, S.L. 986 291362','2003-03-17','','Jose Manuel Negreira',' / ',NULL,257,139),
	 ('','García','','Supervisor en Vigo','2005-12-16','','José Mª','986374031',NULL,628,93),
	 ('','','','','2003-05-29','','Javier Lozano, Maribel Bautista','986373580 / ',NULL,270,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2003-06-16','','Susana Neria','916270548 / ',NULL,278,139),
	 ('','','','Xefa Dpto Personal','2003-06-10','','Mª Jesús Gallego Herrera','986869340 / ',NULL,280,139),
	 ('','Pazó','Ares','Propietario','2003-07-09','','Pedro','986118102 / 630145016',NULL,287,93),
	 ('','','','','2003-08-05','','Teresa Ramírez/ Carmen','986101488 / 625498310',NULL,300,139),
	 ('','Costas','','','2003-04-13','servicom@mundo-r.com','Alberto','659494784 / 659494784',NULL,258,93),
	 ('','Amoedo','','Director','2003-04-24','','Dositeo','986443454 ',NULL,259,93),
	 ('','Romero','Rodríguez','','2003-04-02','','Xosé Manuel','982284111 / 610693917',NULL,260,93),
	 ('','','','Propietarios','2003-04-07','','RAFAEL / FELISA',' / 646939331',NULL,261,93),
	 ('','','','','2003-03-25','','Araceli González','986230078 / ',NULL,262,139),
	 ('xa non está na empresa. Está de Dtor. Xerente en IDEGA','Molinos','Lentijo','Gerente','2003-04-22','info@gestoresdeprevencion.com','Angel','606278988',NULL,263,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Núñez','Alvarez','','2003-04-14','gaia@gaiapaintball.com','Pablo Núñez Alvarez','986229522',NULL,264,93),
	 ('','Vázquez','','','2003-05-14','','Elena ','986235262 / 617437328',NULL,265,93),
	 ('','Pombo','Liria','Dtor. General','2003-05-16','grencoiberi@nexo.es','Ignacio','986294850 / ',NULL,266,93),
	 ('','Pérez','Mosteiro','','2003-05-16','fisteco@bbvnet.com','Matilde','986210482',NULL,267,93),
	 ('','','','Dono','2003-05-07','','José Benito','690367820',NULL,271,93),
	 ('','','','','2003-06-13','adreco@terra.es','Gema López','986432244 / ',NULL,275,139),
	 ('','','','','2003-06-18','','David Temes',' / 670883350',NULL,277,139),
	 ('','Pérez','Parga','Dpto. de Recursos Humanos','2003-07-04','rrhh@enor.es','Juan','986251166 / ',NULL,284,93),
	 ('','','','Técnica de Selección','2003-09-26','rosa_povea@carrefour.com','Rosa Povea / Mónica Pascual / Javier','913018042 / ',NULL,315,93),
	 ('','Iglesias','','','2003-09-25','liliaiglesias@ingenierosvigo.org','Lilia','661871889',NULL,316,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Administrativa','2003-09-15','impertex@asemaco.es','CAMY','986490771 / ',NULL,317,93),
	 ('','Rozas','Frenquel','Titular','2003-09-26','','Ana','986299638',NULL,318,93),
	 ('','Pérez','Parga','Dpto. Recursos Humanos','2003-07-04','rrhh@enor.es','Juan','986251166 / ',NULL,285,93),
	 ('','Pinal','','','2003-07-09','','Judith','986247270',NULL,286,93),
	 ('','Núñez','','Rpble. Personal','2003-04-23','personal@alfageme.com','Antonio','986213217 / ',NULL,289,93),
	 ('','Vila','Campo','Rpble. Gestión RR.HH','2003-04-25','rvila@grupocopo.com','Rosana','986810500',NULL,290,93),
	 ('','García','Carrera','Dtor. de Personal y RR.HH','2003-04-24','conservas@albo.es','José Antonio','986213333 / ',NULL,291,93),
	 ('','Bustamante','Caño','Dtora. U.N. Comercial ','2003-07-21','pcano@pascualsilva.com','Patricia','986439470 ',NULL,292,93),
	 ('','Tejada','Fernández','Director','2003-07-18','info@ciudaddevigo.com','Miguel Angel','986227820',NULL,293,93),
	 ('','','','','2003-05-16','','Rubén','986339136 / ',NULL,294,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Técnica de selección','2003-07-03','','Eva Hidalgo','981210034 / ',NULL,295,139),
	 ('','','','Director','2003-07-04','','Pedro Hernández Bono','986419244 / ',NULL,296,139),
	 ('','','','','2003-08-01','servivente@serviventa.com','Raquel Martínez','986640248 / ',NULL,297,139),
	 ('','Da Ponte','Tarrío','Administradora-Economista','2003-11-06','rh_dyouteam@hotmail.com // mpponte_diyou@hotmail.com','Mª Pilar','986485561 / ',NULL,298,93),
	 ('','','','Dpto laboral','2003-08-04','','Betariz Martínez','986439470 / ',NULL,299,139),
	 ('','','','Dona','2003-08-06','','Carmen Rosa Otero Lamas',' / 661463010',NULL,301,139),
	 ('','','','Directora  Financiera','2003-08-12','','Ana Aranda ','986337244 / ',NULL,302,139),
	 ('','','','Delegada','2003-08-07','','Patricia Varela','986373014 / ',NULL,303,139),
	 ('','','','Dona','2003-08-20','','Manuela Rodriguez Fernández','986228122 / ',NULL,304,139),
	 ('','','','Responsable de RRHH','2003-08-22','jcrivas@misan.net','Jorge Ten García','913596905 / 647608205',NULL,305,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','','2003-08-19','','Alvaro Mas','916500463 / ',NULL,306,139),
	 ('','','','','2003-08-11','','Tania','914845707 / ',NULL,307,139),
	 ('','Pazo','Rodríguez','Propietario','2003-09-15','','Ángel','986223120',NULL,310,93),
	 ('','Tenoira','','Propietario','2003-09-03','vigo_cks@hotmail.com','Rafael','606635664 / 606635664',NULL,311,93),
	 ('','Brea','','Propietario','2003-09-17','','Juan','647939653 / 647939653',NULL,312,93),
	 ('','Quiroga','','Responsable','2003-09-03','celia@fervellos.com','Celia','986116788 / 609100809',NULL,314,93),
	 ('','Domínguez','','Rpble. Personal','2003-09-25','','Charo ','986279282 / ',NULL,308,93),
	 ('','Fernández','','','2003-09-15','corunia@sabico.com','Carmen','981139876',NULL,313,93),
	 ('','Bernárdez','','Titular','2003-09-18','rubenbernardez@yahoo.es','Rubén','617820202',NULL,319,93),
	 ('','Marcote','','Titular','2003-10-06','','Juan A. ','986431725 ',NULL,320,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dona','2003-03-31','','Susana Velázquez','986272611 / ',NULL,322,139),
	 ('','','','Dona','2003-08-29','','Manuela Rdguez Fernández','986441400 / ',NULL,324,139),
	 ('','','','','2003-10-11','','Jose Oliveira',' / ',NULL,325,139),
	 ('','','','Comercial','2006-06-08','','Ramón Arenas','933426620 / ',NULL,326,139),
	 ('','','','','2003-11-04','','Charo Lago','986338333 / ',NULL,327,139),
	 ('','','','Dpto de Administración','2003-10-09','','Lucía','986580240 / ',NULL,328,93),
	 ('','','','','2003-11-07','','Patricia Castro Carrera','986344635 / 650441860',NULL,329,139),
	 ('','Alvarez','','Rpble. Formación','2003-07-04','vulcano@factoriasvulcano.com','Roxelio','986266161',NULL,330,93),
	 ('','Diez','','Administrativo','2003-05-27','','Ramón','986229288',NULL,331,93),
	 ('','','','Dpto. Persoal (ext.806)','2003-06-13','administración@cemegasa.com','Olga','986811100',NULL,332,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Pereiro','','Persoal','2003-06-17','fribesa@fribesa.com','Miguel','986297700 / ',NULL,333,93),
	 ('','','','Dpto. Persoal','2003-08-05','exconsa@fonocom.es','Mª José ','986299805 / ',NULL,334,93),
	 ('','Montenegro','Rodríguez','Jefe de Personal','2003-07-16','','Avelino','986268500 / ',NULL,335,93),
	 ('','De la Torre','','Dpto. Selección','2003-10-17','vigo@serviguide.com','Alba','986443311 / ',NULL,337,93),
	 ('','Porto','','Administrativo','2003-11-14','','Oscar','986419847 / 647180557',NULL,340,93),
	 ('','Soto','Virulegio','','2003-11-19','','Filomena Mª ','886116983 / 652870731',NULL,341,93),
	 ('','','','Socia   / ','2003-11-19','globalazaga@globalazaga.com','Yolanda Pantin  / Belén Sanjurjo','981208990 / 981208932',NULL,342,93),
	 ('','Hernández','','Dpto. Formación','2003-10-28','vitae@berner.es','Carlos','958060200 / ',NULL,338,93),
	 ('','Menarguez','','Técnico de selección','2003-11-06','','Ainhoa','915751603',NULL,339,93),
	 ('','García','Fandiño','Administrador','2003-12-03','','Ricardo','986871516 / 629479580',NULL,343,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Directora','2003-12-03','','Rebeca Rebolo Constela','651844463 / ',NULL,344,139),
	 ('','','','Directora de Programas','2002-10-28','soniafresco@avanzas.com','Sonia Fresco','986227103 / ',NULL,345,139),
	 ('','Rodríguez','','Ejecutiva de cuentas','2003-09-16','cv.vigo@ajilon.es (para envío cv)','Lucrecia','986222697 ',NULL,336,93),
	 ('Visita conveniar prácticas Abeiro. Non se concretan      ','','','Apoderado','2003-07-18','luis.súarez@arasmultiservicios.com','Luis Suárez Filgueira','986114717',NULL,346,139),
	 ('Visita conveniar practicas Abeiro. No se concretan','','','Presidenta','2003-06-19','','Josefina','986220303',NULL,347,139),
	 ('Mantivéronse contatos para realizar prácticas de Abeiro. Finalmente non se chegaron a realizar    ','','','Responsable dpto relaciones públicas','2003-06-02','','Celia Estévez','986811111',NULL,348,139),
	 ('Visita inserción Asiste','','','Directora','2003-03-07','','Carmen González','986483105 / ',NULL,349,139),
	 ('Mantuvose contacto persoal para a xesrión de prácticas enmarcadas dentro do proxecto Abeiro. finalmente non se firmou convenio de colaboración.

                                   ','','','Propietaria-Xerente','2003-07-04','','Paula Costas Novo','986242222 / ',NULL,350,139),
	 ('','','','Director xeral','2003-06-25','','Padre Carlos Ortiz ','986297003 / ',NULL,351,139),
	 ('','Caballero','Vila','Dtra. de Zona','2003-09-16','','Carmen','',NULL,336,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Están abertos a todos os sectores, irán especializándose a medida que inicien a labor de prospección de empresas.','','','Técnica de selección/Comercial','2006-03-09','','Carolina García/ Marco Parada','',NULL,117,139),
	 ('','','','Presidenta','2002-07-02','a.f.a.g.a@terra.es','Concha Blanco','986229797 / ',NULL,352,139),
	 ('Visita conveniar practicas Asiste.             ','','','Directora','2002-10-03','','Mariem Moure Iglesias','986485543 / 617926989',NULL,353,139),
	 ('','','','Coordinadora','2003-03-19','','Adela','986436874 / ',NULL,354,139),
	 ('','','','Responsable proxectos','2002-07-18','','Montserrat Lamas','986434874 / ',NULL,355,139),
	 ('','','','Presidenta','2002-07-18','hoypormañana@hotmail.com','Elena Piñeiro','986261098 / 629887663',NULL,356,139),
	 ('','','','Directora','2002-09-05','','Beatriz Macías López','986208395 / ',NULL,357,139),
	 ('Visita inserción durante o proxecto Asiste','','','Directora','2003-03-17','','Mª Jesús Cobián','986425685 / ',NULL,358,139),
	 ('','','','Directora','2002-09-24','','Nuria Silva','986277370 / 657645073',NULL,359,139),
	 ('','López','','Directora','2003-03-13','','Madre Purificación','986275168',NULL,360,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Directora','2002-12-02','','Mª Teresa Seoane Ramos','986262570 / ',NULL,362,139),
	 ('','','','Directora','2002-12-02','','Flora Alonso','986437609 / ',NULL,363,139),
	 ('','','','Directora','2002-12-03','','Marta Bonar','986377726 / ',NULL,364,139),
	 ('visita de inserción do proxecto Asiste        ','','','Directora','2003-03-11','','Directora','986413890',NULL,365,139),
	 ('','','','Traballadora Social','2003-03-17','','Ruth Blanco','986224468 / ',NULL,366,139),
	 ('','','','Directoras','2002-06-19','','Nuria Pascual /Carmen Freiría','986240336 / ',NULL,367,139),
	 ('','','','Xerente','2002-07-02','esthersilva_@hotmail.com','Esther Silva Pereira','986264910 / ',NULL,368,139),
	 ('','','','Directora','2002-10-16','','Mª Jesús','986438900 / ',NULL,369,139),
	 ('','','','Directora','2002-10-16','','Dolores Novo González','986240441 / ',NULL,370,139),
	 ('','','','Presidenta','2002-09-27','asodoa@arraquis.es','Josefina Otero','986483208 / ',NULL,371,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Banda','','Directora','2003-06-24','c.banda@egresidencias.es','Carmen','986485610 / 669311307',NULL,372,139),
	 ('','Somoza','','Directora','2003-04-28','','Concepción','986294422',NULL,373,139),
	 ('Información para Asiste','','','Directora','2002-07-22','','Susana Rodríguez','986423433  ',NULL,374,139),
	 ('','','','Coordinador xeral','2002-06-26','jcarlos@cruzroja.es','Juan Carlos Pérez Santiago','986423666 / ',NULL,375,139),
	 ('','','','Directora','2002-07-04','','Madre Osorio','986290054 / ',NULL,376,139),
	 ('Visita conveniar pácticas Abeiro    ','','','Copropietaria','2003-07-17','','Reyes Arias García','986243178 / ',NULL,377,139),
	 ('','','','Directora','2002-09-24','cee.saladino.cortizo@edu.xunta.es','Concepción Martínez Rodríguez','986288188 / ',NULL,378,139),
	 ('Visita conveniar practicas Abeiro     ','','','Director xerente','2003-07-01','','Doctor Bibiano Fernández-Arruti López','986219114 / ',NULL,379,139),
	 ('','Alvarez','','Directora-xerente','2003-07-04','','Ángeles','986242706 / 646102312',NULL,380,139),
	 ('Visita conveniar prácticas Abeiro.          ','','','Xerente','2003-07-10','','Sofía García Iturbi','986438900 ',NULL,381,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Directora','2002-06-18','','Alicia Pedrosa','986253511 / ',NULL,382,139),
	 ('','','','Director','2002-05-28','mvazquez@segg.es','Miguel Ángel Vázquez Estévez','986374141 / ',NULL,383,139),
	 ('Visita conveniar prácticas para la Unidad de Psiquiatría del Rebullón. Multiples contactos a partires da data indicada.                       ','Font','','Rble. Dpto. de formación','2003-06-30','','Encarna','986816091',NULL,384,139),
	 ('Información Asiste','','','Xefe do Servizo de Pediatría','2002-06-20','olivo11@hotmail.com','Javier Olivo','986816000 / 657383707',NULL,385,139),
	 ('Visita conveniar prácticas Abeiro.','','','Directora','2003-07-02','','Mª del Mar de La Peña Cristiá','986451400 / 986451255',NULL,386,139),
	 ('','Vázquez','Noguerol','Xerente','2003-04-30','elpinar@jet.es','Mónica','986266400',NULL,387,139),
	 ('','Rodríguez','','Directora','2002-10-17','','Raquel ','986223097',NULL,388,139),
	 ('','','','Director Xerente','2002-09-05','','Ángel Gómez López','986294730 / ',NULL,389,139),
	 ('','','','Directoras','2002-11-02','','Isabel Alonso/Mª Teresa Seoane','986273012',NULL,390,139),
	 ('Solicitude de información de cara a realización de prácticas do proxecto Asiste. Non se firmou convenio de colaboración               ','Queija','Romero','Directora','2002-10-14','','Raquel','986233963 ',NULL,391,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Solicitude de información de cara a posible realización de prácticas do proxecto Asiste. Non se firmou convenio.                                     ','Vázquez ','González','Xerente','2002-08-28','acamelia@terra.es','Amparo ','986241329 ',NULL,392,139),
	 ('Visita conveniar prácticas Asiste       ','Muñiz','Agís','Director','2002-07-01','','Pablo ','986292087 / 607511615',NULL,393,139),
	 ('Solicitude información no proxecto Asiste              ','','','Socia da cooperativa','2002-06-19','','Ana García Crespo','986487786 / 629830762',NULL,394,139),
	 ('Firma de convenio de practicas do proxecto Asiste.','Aguiar ','Alvarez','Directora','2002-09-11','','Isabel ','986271644',NULL,395,139),
	 ('','','','Presidente','2002-09-18','interpares@ctv.es','Juan Francisco Pardo Figueroa','986118324 / 655820450',NULL,396,139),
	 ('','','','Socia','2002-07-09','maria2802@terra.es','María Lorenzo','986435742 / ',NULL,397,139),
	 ('Firmouse convenio de colaboración para a realización de prácticas do proxecto Asiste.         ','','','Directora','2002-06-25','ceip.emilia.pardo@edu.xunta.es','Isaura Abelairas','986293780 ',NULL,398,139),
	 ('Firmouse convenio de colaboración para a realización de prácticas do proxecto Asiste.       ','','','Xefe de estudios','2002-06-25','','Enrique','986239901',NULL,399,139),
	 ('Firmouse convenio de colaboración para a realización de prácticas do proxecto Asiste.       ','','','Xefa de estudios','2002-06-25','ceip.pintor.laxeiro@edu.xunta.es','Esther','986238043 / ',NULL,400,139),
	 ('Firmouse convenio de colaboración para a realizacón de prácticas do proxecto Asiste.        ','Nabaza','Blanco','Directora','2002-06-27','','Martina ','986471410 ',NULL,401,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Firmouse convenio de colaboración para a realización de prácticas do proxecto Asiste','Agún','','Directora','2002-06-27','cristo.victoria@edu.xunta.es','Mª Jesús ','986202717 / ',NULL,402,139),
	 ('Firmouse convenios para a realización de practias do proxecto Asiste.                                  ','Rivera','','Directora','2002-06-24','','Angeles ','986291213',NULL,403,139),
	 ('Non se firmou convenio de colaboración para realización de practicas do proxecto Asiste.           ','','','Profesora de Educación Infantil','2002-09-24','','Mª José','986486901',NULL,404,139),
	 ('Solicitude de información de cara a posible realización de prácticas do proxecto Asiste. Non se firmou convenio de colaboración.                ','Fernández','','Directora','2002-06-28','','Ramona ','986469241 ',NULL,405,139),
	 ('Non se realizaron práctivas do proxecto Asiste','González','','Directora','2002-09-30','','Aurora ','986293194  ',NULL,406,139),
	 ('','','','Director','2003-03-13','','Estanis','986424818 / ',NULL,414,139),
	 ('','','','','2001-01-01','','Sor Mª Angeles','986436369 / ',NULL,418,139),
	 ('','','','Administrador','2001-01-01','','Juan Ignacio González','986412652 / ',NULL,420,139),
	 ('','','','','2001-01-01','','Matilde','986374278 / ',NULL,421,139),
	 ('Contrata la APA','','','Directora','2003-03-17','','Concepción Taboada','986416574',NULL,422,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Fernández','','Directora','2002-02-25','','María','986272195 ',NULL,407,139),
	 ('','Martínez','','Directora','2003-02-24','','Consuelo','986231149',NULL,408,139),
	 ('','','','Director','2003-02-28','','Manuel','986278089 / ',NULL,409,139),
	 ('','Bouzón','','Director','2003-02-28','','José Mª','986293282',NULL,410,139),
	 ('','Fernández','','Director','2003-03-11','','Alfonso','986371330',NULL,411,139),
	 ('','Presas','','Directora','2003-03-06','','Paloma','986420938',NULL,412,139),
	 ('','','','Directora','2003-03-13','','Hermana Nieves','986493501 / ',NULL,413,139),
	 ('','','','Directora / Coordinadora de Servizos','2003-03-18','vigo@bbserveis.com','Eva Costas /Olalla Vázquez','986114938 / ',NULL,415,139),
	 ('','Campos','','Directora','2003-02-24','','Cristina','986410174',NULL,416,139),
	 ('Estableceuse un 1º contacto co fin de recabar información sobre o que se está a facer na área de Lecer e Tempo Libre dentro da asociación co fin de organizar o itinerario 3 do Proxecto Alicerce.      ','','','Coordinadora/Gerenta','2004-05-03','downvigo@teleline.es','Ana Tejada','986201656 / ',NULL,454,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Solicítase información para o Iti. de Ocio do Alicerce e tantease a posibilidade de realizar prácticas.         ','','','Presidenta','2004-05-28','fundacion_igualarte@hotmail.com','Cristina','986117370 / 667353935',NULL,456,139),
	 ('','','','Técnico de selección','2004-02-13','','Marcos Fariñas','986138851 / ',NULL,457,139),
	 ('','','','Responsable de formación','2004-02-16','','Camilo Chas','981150567 / ',NULL,458,139),
	 ('','','','Administrador','2004-04-23','','Raúl Ríos Basadre','986384404 / 607904690',NULL,459,139),
	 ('','','','Directora de xestión de servizos','2006-12-21','','Margot Alvarez','',NULL,494,139),
	 ('Matralia, s.l.l. é un grupo de empresas que engloba á empresa Cetefor Fomación, s.l. que é un centro privado de formación e, a su vez, éstas pertenecen o grupo FRUELA AUTOESCUELAS.
Polo R.D. 836/2003, do 13 enero 2004, aprobouse o procedimento para a obtención de carnés profesionais en Galicia. Por iso, están procedendo a acreditarse para a impartición do curso de guindastre-torre (carné operador guindastre-torre) cas seguintes características:
Nº alumnos <=25
Duración: 200 horas (150 h. prácticas + 50 h. teóricas)
                   65 horas (15 h. prácticas + 50 h. teóricas) se acreditan experiencia
Lugar: Vigo e/ou arredores
Os alumnos pagan tasa de examen (20€ aprox.)
Á Consellería de Industria remitenlle os datos dos alumnos e proceden o examen teórico (as horas teóricas as toman como examen).
Necesitarán docentes co perfil de Peritos industriais o Enxeñeiros técnicos con experiencia de al menos 3 años como operador de guindastre-torre.

Máis adiante, acreditaránse tamén para o curso de Palista; en Asturias forman grupos de 10-12 alumnos, teñen 10 máquinas, proporcionan coñecementos de manexo-mantemento-mecánica (soldadura electrodo) cunha duración de 110 horas e cobran unhos 1500€/alumno. Precisa que existe maior demanda de palistas que de operadores de guindastre-torre.
','Suárez','','','2004-03-25','acefor@acefor.telefonica.net','Víctor','902101025 / 665847937',NULL,417,93),
	 ('','','','','2001-01-01','','Amalia','986379179 / ',NULL,423,139),
	 ('','','','Xerente','2004-01-08','','Arancha','986235234 / 696007532',NULL,424,139),
	 ('','','','Dpto Persoal','2004-01-11','','Felix Barreira/ Camilo Simón','986494845 / 677450107',NULL,425,139),
	 ('','Janeiro','','Delegado','2004-01-28','vigo@ungria.es','Roberto','986221159',NULL,426,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dpto. Recursos Humanos (Reclutamento e selección)','2003-12-15','ana.gay@portaventura.es','Ana Poi / Ana Gay','977779066 / ',NULL,427,93),
	 ('Visita inserción Abeiro         ','','','Socio - Responsable de personal','2004-02-06','','Jose Manuel Rodríguez','986366767 ',NULL,428,139),
	 ('','','','Trabajadora Social','2002-08-21','','Sandra Ledo','986494979 / 629693856',NULL,429,139),
	 ('Contacto inserción Abeiro.
Se lle remite listadode alumnas Abeiro para SAD.    ','','','Propietaria-Directora','2004-02-19','xentes@xentes.org           nuriacarrera@xentes.org','Nuria Carrera Pío','986641105 / 687919989',NULL,430,139),
	 ('Mantuvose contacto telefónico, pendente de visita persoal         ','García','Sánchez','Directora','2004-02-24','directorarrhh@agoleslu.com','Beatriz','986679900 / ',NULL,431,139),
	 ('Mantuvose contacto telefónico para accion de insercion de Abeiro.                          ','','','Presidente','2004-03-02','','Pablo Aradillas','986123401',NULL,432,139),
	 ('Visita inserción Abeiro           ','','','Directora-Propietaria','2004-03-04','','Pilar','986366879 / 659466565',NULL,433,139),
	 ('','','','Dpto RRHH','2004-01-20','','Mar García','915612840 / ',NULL,434,139),
	 ('','Calviño','','Administrativa','2004-02-06','','Esperanza','986374256',NULL,435,93),
	 ('','','','Directora','2002-07-02','','Madre Sorama garcía','986436266 / ',NULL,436,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita de Inserción del proyecto Abeiro.','Piñeiro','','Propietario/Gerente','2004-02-12','','Rafael','886112836',NULL,437,139),
	 ('','','','Directora','2002-10-02','','Mª Jesús Mouriño','986241775 / ',NULL,438,139),
	 ('Firmouse convenio de colaboración para a realizacion de prácticas do proxecto Asiste       ','Lacaba','Vázquez','Director','2002-09-23','','Antonio ','986240789 / 647931518',NULL,439,139),
	 ('Firmouse convenio de colaboración para a realización de prácticas do Proxecto Asiste.          ','','','Director','2002-10-16','','José Luis Rey','986272871 / 619577522',NULL,440,139),
	 ('Firmouse convenio de colaboración para realización de prácticas do proxecto Asiste.                      ','Alberte','Iglesias','Director','2002-09-05','','Vicente ','986470839 ',NULL,441,139),
	 ('Firmouse convenio de colaboración para a realización de prácticas do Proxecto Asiste           ','Cid','González','director','2002-10-01','','Francisco ','986480485',NULL,442,139),
	 ('Realizouse unha visita ó centro có fin de recabar información para enfocar o Itinerario de Lecer e Tempo Libre do Proxecto Alicerce.               ','','','Directora','2004-04-16','','Carmen Arville','986261877 ',NULL,443,139),
	 ('','Sánchez','Quiroga','Dtor. Gerente Servics. Empresariales Atlántico e Delegado Galicia Grupo Avanza','2005-06-23','','Ovidio','986481394 / 667904086',NULL,444,93),
	 ('','Varela','','','2004-03-11','','Jose Ramón','986487417',NULL,445,93),
	 ('','','','Administrativa','2004-04-14','','Aida','986490107 / ',NULL,446,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Rodríguez','Miniño','','2004-04-15','','Dolores','986354748',NULL,447,93),
	 ('Solicitase información sobre as actividades que está a facer a empresa có fin de recabar información para organizar o Itinerario 3(lecer e tempo libre na terceira idade e discapacidade) do Proxecto Alicerce.                                               ','','','Socia','2004-04-22','vandivulgacion@yahoo.es','Elisa Pereira García','986410476 / ',NULL,448,139),
	 ('Recabouse información sobre as actividades de Lecer e Tempo Libre que estén realizando na asociación , có fin de organizar o itinerario 3 do Proxecto Alicerce.                                      ','','','Directora','2004-04-21','','Isabel','986484035 / ',NULL,449,139),
	 ('Sólicitase información sobre o CS de Animación sociocultural có fin de organizar o itinerario 3 (lecer e tempo libre na 3ª idade e discapacidade) do Proxecto Alicerce                                              ','','','Profesoras do Ciclo Superior de Animación Sociocultural','2004-04-22','','Lucía/María','986335400',NULL,450,139),
	 ('Contactouse como a empresa para recabar información das actividades que realizan e as entidades coas que traballan, có fin de recabar información para organizar o itinerario 3 (lecer e tempo libre) do Proxecto Alicerce.                  ','','','Socia','2004-04-21','','Elena','986485538 / 650389112',NULL,451,139),
	 ('O señor Antón é o Xefe de persoal en AUCOSA e en FRIOYA.
A selección de persoal de dirección e comercial a fan por medio de contactos e captación. O resto de persoal o fan a través de ETT (traballan con SELECT, deixaron de traballar con Flexiplan e Adecco por falta de seriedade); solen facer contratos de 3/6 meses ca ETT e posteriormente fan eles contrato.
En xeral interesalles contratar persoal que queira quedarse na empresa e non teñen demasiado en conta a idade.
PRL o levan externamente ORP e Ibermutua en Frioya.
Interésalle a nosa información porque tamén ten unha asesoría (ANSOC).
A cantidade de traballadores que podría incorporar no require c.c.c.
Envíaselle listado de entidades que facilitan a obtención do CMA.','Antón','','Jefe de Persoal','2004-04-29','aucosa@aucosa.com','José Manuel','986291858',NULL,452,93),
	 ('','Iglesias','Conde','Directora de Recursos Humanos','2004-04-29','frivigo@frivigo.com','Adriana','986447100 / ',NULL,453,93),
	 ('','','','Responsable RRHH','2004-05-14','admin@dipsystems.com','Beatriz Rivas','912293910 / ',NULL,461,139),
	 ('Realizamos unha vista có fin de recabar información para o itinerario de lecer e tempo libre, especializado en 3ª edad e discapacidade, do Proxecto Alicerce.
Aproveitamos a visita para ver a posibilidade de realizar parte das prácticas nese centro.            ','','','Animadora Sociocultural','2004-05-28','','Raquel','986687136 / ',NULL,455,139),
	 ('','','','Dono','2004-05-10','','Basilio Rdguez',' / 629501476',NULL,460,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dpto Producción','2004-05-18','','Amelia González','918559245 / ',NULL,462,139),
	 ('','Feijoo','Covelo','Dono. Técnico Prevención de Riesgos Laborales','2004-06-28','aranfeijoo@yahoo.es','Aran','986133699 / 616017486',NULL,463,93),
	 ('','Silva','Calviño','Administrativa','2004-06-30','nsilva@cliner.com','Ninoska','981174694',NULL,464,93),
	 ('','Moreno','Nieto','Técnica selección','2004-07-02','','Mirian','915064460',NULL,465,93),
	 ('','','','Asesoría xurídica','2004-06-01','crodriguez@zonafrancavigo.com','CLara Rodríguez Fernández','986269720 / ',NULL,466,139),
	 ('','','','','2004-06-02','','Jose Manuel  Lago Arevalo','986226579 / 699087876',NULL,467,139),
	 ('Información programas do PME. Nesta empresa fan contratos por obra, necesita axudantes de encofrado, de ser o caso faríanos a oferta. Esta empresa fai as obras unha vez que alguén levalle os planos e os permisos.','','','Dpto Administración','2004-06-10','','Rosana','986277625 / 609812608',NULL,468,139),
	 ('','','','Consejero delegado','2004-06-29','','M.Angel Villar Pérez','986290559 / ',NULL,469,139),
	 ('','','','Xerente','2004-06-29','','Angel Villar Pérez','986290559 / 639886512',NULL,470,139),
	 ('','','','Administración/xerente','2004-06-30','garciventa@asemaco.es','Mariña Taracido/Gonzalo Vila','986260609 / ',NULL,471,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Lugo','de la Fuente','Responsable','2004-07-26','asefis.fic@telefonica.net','Isabel','986232542',NULL,472,93),
	 ('','Tato','Estévez','Administrador','2004-07-22','','José Manuel','659908580',NULL,473,93),
	 ('','Quintela','Cea','Gerente','2004-07-22','','Juan','986211576',NULL,474,93),
	 ('','','','Socio e administrador','2004-07-02','','José Ramírez Lemos','699035726 / ',NULL,475,139),
	 ('','Abad','Pérez','Técnica de seleccíón','2004-07-14','','Arantxa','981138000',NULL,476,93),
	 ('','','','Dpto Recursos Humanos','2004-07-27','','Sheila Escamez','647343731 / 944520210',NULL,477,139),
	 ('','','','Socia-Xerente','2004-08-06','','Pilar Fernández','986112848 / 639812422',NULL,478,139),
	 ('','Rivero','','Gerente','2004-09-23','limiar@mundo-r.com','Mario','986117447',NULL,479,93),
	 ('','Gil','Rodríguez','','2004-09-23','mjgil@infomail.lacaixa.es','Mª Jesús','677526198',NULL,480,93),
	 ('','Fernández','Iglesias','Socio','2004-09-27','jugueteriareguera@yahoo.es','José Manuel','610557571',NULL,481,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dona','2004-08-02','','Mar Novoa','986291796 / 657460920',NULL,482,139),
	 ('','','','Xerente','2004-08-30','','Mercedes Tasende Rojo','986114675 / ',NULL,483,139),
	 ('Colaboración Alicerce.Charla curso de ANIMACIÓN   ','','','Presidenta','2004-09-03','','Josefa Rguez Cara','986467263 ',NULL,484,139),
	 ('','González','','','2004-12-11','artgal@teleline.es','Manuel','981293688',NULL,485,93),
	 ('','','','Xerente','2004-11-02','','Candy Tamborino','986210863 / ',NULL,486,139),
	 ('','','','Xerente','2004-11-03','','Carmen Rodríguez Alvarez','986633663 / 627440951',NULL,487,139),
	 ('Iago ven por eiquí reunese con Elisa e Chelo.
A empresa é nova e vaise dedicar á reformas e quere dúa brigadas de tres persoas                  ','','','Xerente','2006-06-08','','Iago Prego','670707081 / ',NULL,488,139),
	 ('','','','Técnica de selección e contratación','2004-12-09','','Mercedes Castro','986443041 / ',NULL,489,139),
	 ('','','','Xerente','2005-01-03','angara@angaraservicios.net','Angeles Oya','986912461 / 619031975',NULL,490,139),
	 ('','','','Xerente','2005-01-13','','Alexander Domínguez','696152472 / ',NULL,491,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xerente','2005-01-14','','Lorenzo Portuese','626482518 / ',NULL,492,139),
	 ('Esta empresa instalarase no Pol. de Valadares. Xa están coas obras pero comezara a producir en marzo de 2006. Están recibindo CV. Moi ineteresado polas axudas á contratación.Como perfil  van pedir coñecementos de plástico e FPII    ','','','Responsable de RRHH','2005-01-27','xurxoairas@denso-ts.it','Xurxo Airas Cotobad','986247222 / ',NULL,493,139),
	 ('','','','Xestora de servizos','2005-01-28','vgestion@solgest.es','Margot Alvarez','986902696 / ',NULL,494,139),
	 ('Comezara a funcionar a mediados de xaneiro. Están facendo proceso de selección para recepcionista, camareiras...., . ata 35 anos aprox. Valorase o inglés e o portugués para as camareiras pero en recepción o inglés nivel alto é imprescindible                                             .','','','Directora de alojamiento','2006-06-08','da@pazolosescudos.com','Gabriela Alonso Reboreda','986820804 / ',NULL,495,139),
	 ('Contratan a través de Nortempo un período de tempo e logon os pasan á empresa.
Varóns ata 40 anos con vehículo propio, preferiblemente da zona.
Teñen tres turnos mañan, tarde e noite.    Traballan para Citroen e Renault, fan depósitos de combustible, conductos de aireación.','','','RRHH','2005-02-07','','Xiana García','986467000',NULL,496,139),
	 ('','','','Técnica de selección','2005-01-25','','Paula Tomé','981209015 / ',NULL,497,139),
	 ('','','','xerente','2005-01-27','','Belén','986228318 / ',NULL,498,139),
	 ('','','','Técnica de selección','2005-01-28','','Beatriz de la Oliva','917281370 / ',NULL,499,139),
	 ('','','','','2005-02-01','','Nieves','986431633 / ',NULL,500,139),
	 ('Información do PME Falase da posibilidade de poder facer formación en algunha empresa do sector naval coa que eles teñen contacto                                  ','','','Responsables de Formación','2005-02-17','','Almudena Nuñez/Ignacio Chamorro','986420541',NULL,501,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xerente','2005-03-07','','Chon ','986205909 / ',NULL,502,139),
	 ('E un almacén ao que chegan os camións grandes que descargan a mercancía para outros camións mais pequenos que son os que logo dsitribuen ás tendas. Reclutan a través dos CV das tendas. Perfil solicitado mulleres con o sen experiencia, ata 40 anos. Sirvelles con experiencia en atención ao público. En Vigo teñen 23 tendas e logo franquicias que se xestionan elas pero só poden vender a súa froita. Levan a parte de froitería nas tendas de Solofresco.','Andonegui','','','2005-02-25','juan.andonegui@frutasnieves.com','Juan Manuel ','986342634 / 696513900',NULL,503,139),
	 ('A oferta que fan é de consultor con 5 anos de experiencia e valorase ter cartera de clientes           ','','','','2006-06-08','mionica@netaccede.com','Mónica Rodríguez','986441646 / ',NULL,504,139),
	 ('','','','Axudas e oferta traballo','2002-07-24','','Geni','',NULL,35,139),
	 ('','','','Axudas contratación','2002-07-15','','Belén o Fátima','',NULL,36,139),
	 ('E amigo de Moncho (Compás) Ven por eiquí para solicitar comerciais. Quedamos en que se nalgún momento temos algunha persoa dispoñible falaremos con él               ','','','Xefe comercial','2005-03-15','','Edelmiro Otero Giráldez','986449706 / ',NULL,505,139),
	 ('Ven por eiquí para solicitar comerciais, quedamos en que se hai alguen dispoñible falaremos con ela      ','','','Xerente de equipo','2005-03-18','julia.carazo@aviva.es','Julia Carazo Rodríguez','986222625 / 628024569',NULL,506,139),
	 ('Ven por eiquí cun compañeiro para informarnos do que fan nesta consultora e ver se podemos colaborar con eles.       ','','','Técnica de selección','2005-03-03','','Rosa Cambeiro','986229728',NULL,507,139),
	 ('','','','Dona','2005-03-21','','Cruz','886117368 / ',NULL,508,139),
	 ('O obxectivo foi solicitar información sobre as súas actividades o inicio de Proxecto Alicerce         ','','','Técnica','2004-04-28','planteis@cgtrabajosocial.es','Genoveva Cordero ','986281670 / ',NULL,509,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Coordinador do centro ','2004-12-02','','Hermano José A. Donaire','986451885 / ',NULL,510,139),
	 ('','Mijares','Tuellss','Presidenta','2004-04-14','MADRO@telefonica.net','Carmen','986208874',NULL,511,139),
	 ('','','','Directora- psicóloga','2004-12-10','abad@mundo-r.com','Mariam','986436541 / ',NULL,512,139),
	 ('','','','Presidente','2004-12-13','psicomédico@terra.es','Mario Soares',' / 649883423',NULL,513,139),
	 ('','Pulido','','Técnico','2004-04-21','','Juan Antonio','986443310',NULL,514,139),
	 ('A finalidade desta entrevista foi solicitar información sobre o Programa Os Sereos              ','','','Técnica en xestión de programas','2004-05-10','','María Villaraviz','986227296 / ',NULL,515,139),
	 ('','Otero','','Director Médico','2004-04-20','uadcedro@terra.es','Francisco','986482750',NULL,516,139),
	 ('','Guimerans','','Directora Psicóloga','2004-04-28','asvidal@vigonet.com','Carmen','986226269',NULL,517,139),
	 ('','Malvido','','Coordinadora de pisos de integración social','2004-04-16','','Azucena','986250240',NULL,518,139),
	 ('','Esteso','Mesas','Coordinador Médicos del Mundo Galicia','2004-04-27','mdmvigo@eresmas.com','Ramón','630980081',NULL,519,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Impartiu formación durante un día no Proxecto Alicerce sobre adicción o xogo        ','','','Presidente','2004-11-09','agaja@mundo-r.com','Juan José Lamas','886119586 / 667648229',NULL,520,139),
	 ('','Cancelo','','Director Médico','2004-04-15','alborada@alborada.org','Jesús','986224848',NULL,521,139),
	 ('','Estévez','','Coordinador centro Vigo','2004-04-22','phg_vigo@teleline.es','Manuel','986374648',NULL,522,139),
	 ('','','','Traballadora social','2005-04-06','','Sofía','986224468 / ',NULL,523,139),
	 ('Solicita comerciales','','','xefe de grupo','2005-04-18','','Jose Luis','986435005 / 687544850',NULL,524,139),
	 ('Solicita comerciales','','','','2005-04-26','','Purificación Álvarez / Nerea','986221864 / ',NULL,525,139),
	 ('','','','','2005-04-25','','Jessica','934286981 / ',NULL,526,139),
	 ('','','','Técnico RRHH','2005-05-23','e.ruiz@nacanco.es','Eva Ruiz','936334326 / ',NULL,527,93),
	 ('solicita experta docente','Luaces','','Técnica','2005-05-31','info@formagal.com','Pilar','986866006',NULL,528,93),
	 ('','Aizpurua','','Rpble. Laboral','2005-06-08','kaizpurua@igorle.com','Karmele','943631577',NULL,529,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Gómez R.','','Secretaria','2005-06-13','','Beatriz','981557822',NULL,530,93),
	 ('','','','','2005-06-16','spainsoft@spainsoft.es','Enrique','913091490 / ',NULL,531,93),
	 ('Establécese contacto co obxectivo de recabar información respecto da próxima apertura en Vigo dun Centro Residencial para Maiores, e en concreto do proceso de selección que van a efectuar e posibilidades de colaboración co SOL.','Añón','Gómez','Director- xerente','2005-06-02','','Manuel','986377408 / 902255100',NULL,532,139),
	 ('Visita formativa para MTL de Alicerce.
Colaboración en prácticas del curso de MTL de Alicerce.                                                       ','','','Responsable de actividades','2005-04-04','emiliani@aguarda.com','Feliciano (Xiano)','986613719 / ',NULL,533,139),
	 ('Solicitude de información para Alicerce (Itinerario 3: Discapacidade)                                ','','','Programas de Ocio/Programas de deportes','2004-09-01','','Mavi//Ezequiel','981519650',NULL,534,139),
	 ('','Helguera','','Vicepresidente Vigo','2004-09-01','correo@cogami.es','Angel','986281893 / ',NULL,535,139),
	 ('Contactouse para o Alicerce o ser o único concello de Pontevedra que ten contratados "Mediadores Interculturais" (Manuel e Genma). O primeiro contacto se fixo con Angélica (TLE) e posteriomente coa Traballadora Social, Montse.                        ','','','Alcalde','2004-04-13','','Luis Poceiro (PSOE en coalición co BNG)','986708215 ',NULL,536,139),
	 ('Realizáronse varios contactos para a planificación do Alicerce antes do funcionamento da "Oficina de atención a Inmigrantes" para preparar os contactos cos colectivos de inmigrantes e para concretas aspectos do programa formativo e das prácticas; o alumnado puido facer prácticas xa que coincidiron coa posta en funcionamento  deste servizo.                             ','Thomas','','Xefa de Servizo-Benestar Social','2004-04-12','ofi.inmigracion@vigo.org','María José ','986442096 / 986442656',NULL,537,139),
	 ('O responsable é Delfín Älvarez, Subdelegado do Goberno. O contacto se fixo para presentar o Proxecto Alicerce e negocia-las prácticas dun grupo de Mediación Intercultural. O alumnado coincidíu no tempo co proceso extraordinario de regularización.     ','','','Director Provincial','2004-05-31','','Luis Pérez Álvarez','986221280 / 986221280',NULL,538,139),
	 ('A avogada que leva o servizo é Inmaculada e traballa nos períodos que contan con axuda económica da Xunta ou do Ministerio. Se lles presentou o Proxecto alicerce e acordouse a realización de prácticas. Durante as prácticas rematou o contrato de Inma e se tiveron que rematar antes do previsto. E un concello que conta con varios servizos de apoio a emprendedores e desempregados.                     ','','','Dtor. do CDL e Concellal','2004-11-25','','Gerardo','986487733 / 986487733',NULL,539,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Se contactou con eles para a preparación do Alicerce e no grupo de Mediación se fixeron prácticas no Servizo de asesoramento Laboral  que atende primordialmente a inmigrantes, SGC.     ','','','Director de Vigo','2004-05-15','empleo@cruzroja.es','Juan Carlos','986423666 / ',NULL,540,139),
	 ('O contacto realizouse para a preparación do proxecto Alicerce, itinerario de Mediación Intercultural e para a negociación de prácticas.                ','','','Presidenta','2004-04-20','cume@fundacioncume.org','Gracia Regojo','986207799 / 986298537',NULL,541,139),
	 ('Coa FSGG se fixo un primeiro contacto para perfilar o programa formativo de Mediación no proxecto Alicerce e se conveniaron prácticas.                ','','','Director Territorial de Galicia','2004-04-23','acceder.vigo@fsgg.org','Santiago González Avión','986260255 / ',NULL,542,139),
	 ('Con CC. OO. se fixo o contacto para solicitar información do seu servizo, negocia-las prácticas de Mediación do Alicerce e tamén para coñecer as posibilidades de futuras contratacións.             ','','','Secretario comarcal','2004-04-21','Vigo@galicia.com','José Cameselle','986446218 / ',NULL,543,139),
	 ('Visitas para a preparación e desenvolvemento do Alicerce no itinerario de Mediación. Na asociación contactamos con varias persoas que realizan voluntariado en tareas de mediación e acompañamento (Hortans, Fran, Ana Isabel). Ibrahima impartiu un módulo de cultura africana. Non se puideron realizar prácticas xa que coincidían as datas coa viaxe que fai Ibrahima a Africa cada ano.                                 ','Niang','','Representante da asociación e mediador','2004-05-07','','Ibrahima','986413116 / 610831031',NULL,544,139),
	 ('Se tivo con eles unha xuntanza para a preparación do Alicerce no itinerario de Mediación. O non ter persoal adicado á asociación non se fixeron prácticas conveniadas con eles; o grupo que fixo prácticas na CIG sí que estivo físicamente na sede da asociación encargándose da Base de Datos de Inmigrantes que ofertou a CIG á Confederación de Empresarios para axilizar o proceso extraordinario de regularizazón de inmigrantes. As alumnas despois das prácticas aínda estiveron unhas semanas máis encargandose dda base de datos ata que rematou o período de regularización.','','','Presidenta','2004-04-06','','Lorena Lores','620450124 / 620417393',NULL,545,139),
	 ('Alicerce contactou con eles na preparación de Mediación. No local realizan moitas actividades de tipo cultural. Non ven a necesidade de mediadores e se amosan abertos par que os visitemos cos alumnos.           ','','','asociado que contacta coa xunta, concello, masmedia, etc.','2004-05-06','','Jorge ','665086071',NULL,547,139),
	 ('','','','Rble. da oficina de asesoramento a inmigrantes','2004-04-21','','Lois','986266282',NULL,550,139),
	 ('Primeiro nos xuntamos con Susana, a presidenta saínte e logo coa nova directiva. O Alicerce contactou con eles para a preparación do itinerario de Mediación. Non teñen persoal contratado e non hai posibilidades de prácticas porque non teñen un horario estable de apertura.       ','','','Presidente','2004-05-03','','Germán Zuluaga','986135808 ',NULL,546,139),
	 ('Realizouse o contacto cando iniciaban a actividade e por iso non veian factible a realización de prácticas de Mediación do Alicerce. Os Salesianos teñen moita difusión noutros paises e a atención de inmigrantes a fan en varias cidades de España. Nun futuro terán persoal contratado.                                          ','Soto','','Traballadora social','2005-02-16','noesotosolana@yahoo.es','Noelia','886116485 / ',NULL,548,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Alicerce contactou con eles polos cursos que ofertan a mulleres inmigrantes e pola atención que prestan a este colectivo. Fixeron puntualizacións sobre a formación dos mediadores e comentaron que non tiñan un volume sinificativo de persoas atendidas como para que as prácticas resultaran enriquecedoras. Loreto é a coordinadora de formación.            ','','','Director ECCA','2004-04-21','','Rafael','986225552 / ',NULL,549,139),
	 ('Ruth está contratada por uns meses e se amosa moi receptiva, lle interesa o programa formativo e considera que os alumnos de Mediación se beneficiarian de estar neste servizo e precisamente no momento da regularización extraordinaria.            ','','','Avogada responsable da oficina','2004-04-30','','Ruth','986443458 / 986225150',NULL,551,139),
	 ('','','','Encargados','2005-07-06','dessa_03@hotmail.com','Enrique López / Ricardo','976646088 / ',NULL,552,93),
	 ('','Muñoz','','Comercial','2005-07-07','trayser2004@trayser2004.com','Jorge','916856564',NULL,553,93),
	 ('','','','Administrativo','2005-07-01','jwalvares@yahoo.es','Gonzalo','647859827 / 647859827',NULL,554,93),
	 ('','','','Dpto Persoal','2005-07-07','','Teresa Moraleda','932688300 / ',NULL,555,139),
	 ('Servicio de Axuda a domicilio.
Solicita C.V. de Abeiro para  base de datos por inicio de actividade                                      ','','','Gerente-Propietaria','2005-05-31','conchyalemany@yahoo.es','Concepción Alemany Otero','886119435 / 629217131',NULL,556,139),
	 ('','','','','2005-06-23','contacto@ibersales.com','Dina','917291256 / ',NULL,557,93),
	 ('','','','Director Xerente','2005-07-26','dmg@quality-nova.com','Diego Maraña','986222160 / 986446269',NULL,558,139),
	 ('','Pinal','','Gerente (Rpble. Admvo-financiero)','2005-07-22','benito.pinal@marcovigo.com /marta.viana@marcovigo.com','Benito ','986113900 ',NULL,559,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Lozano','','Gerente','2005-06-23','','Guillermo','986235641 / 986210022',NULL,560,93),
	 ('','Marques','','Fillo propietario','2005-08-04','','Pablo','986277868',NULL,561,93),
	 ('','García','','Gerente','2005-08-08','victor@block.es','Víctor','986120106 ',NULL,562,93),
	 ('Actividade: Marketing, promoción e merchandising.
Ten oficiña tamén en Av. Castelao, 32-1ºD (986292207) na que soe estar o xerente. No museo Quiñones radica outra persona que o coordina e que tamén fai administración e selección.
Clientes: MARCO, Museo Quiñones, Museo do Mar, Fraga, Caixa Galicia, ... (non soen organizar eventos pero sí envían persoal)
Postos máis demandados: monitor/a sala-aux.porta/taquilla-azafata-reparto publicidade-...
Titulacións máis requeridas: Hª do Arte-Xeografía e hª-Restaurador-Belas Artes-Sonido e Audiovisuais. Para as actividades didácticas poden ser de Fª e CC. Educac. con coñecementos deste ámbito.
Valoran capacidade de comunicación con nenos e adultos e coñecementos.
Poden deixar CV na taquilla do MARCO a nome de Carolina Posada e por referencia do Concello (se queremos facer seguimento destes candidatos)','Posada','González','Rpble. RRHH e Coordinadora do MARCO','2005-08-09','grandal@jazzfree.com','Carolina','986220813 / 696399963',NULL,563,93),
	 ('A xerente participou no proxecto ALICERCE. Recibíu asesoramento do SAE. Contacta con nós para obter información de traballadores participantes de Asiste e Abeiro para a súa base de datos de Auxiliares de Axuda a domicilio.                ','','','Xeerente','2005-04-22','shsvigo1@serhogarsystem.com','Mariló Fernández','986222986',NULL,564,139),
	 ('','Comesaña','','Socio','2005-09-07','pxc@pxcultural.com','Berto','986433770 / 670269945',NULL,565,93),
	 ('','','','','2005-09-09','lgonzalez@e-gri.com','Graciela Ibañez / Leire','983212140 / ',NULL,567,93),
	 ('','Galaz','','Técnica de selección','2005-09-14','info@mnemonconsultores.com','Susana','917813217',NULL,569,93),
	 ('Coñecido de José (Encargado obra BIAL)','Morgade','','Xerencia','2005-09-13','','Jesús','639707870',NULL,570,93),
	 ('','Rico','Fernández','Delegada oficina','2005-09-07','monicarico@denbolan.com','Mónica','986447037 / 677983920',NULL,566,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Reunión para falar da posibilidade de facer un curso CCC de teleoperadoras en Bosch','','','Xestora de servizos/Director de organización e RR.HH','2005-03-04','','Margot Alvarez/ Fernando González','',NULL,494,139),
	 ('Envíase información que lles parece interesante cara a Volvo Ocean Race.                  ','','','Secretaria','2005-05-09','info@acnautica.com','Amelia','986432112',NULL,597,139),
	 ('Teñen 2 departamentos: Consultoría e proxectos (Consultoría, Formación, Organización e xestión de proxectos sociais) e Asesoría (ONL-Organizacións non lucrativas e PEMES).
Impartiron algunha acción formativa no Alicerce.
Na súa páxina web ofrécese información da empresa e as súas actividades, perfís de candidatos solicitados e ofertas de traballo.
Para eles o máis cómodo é introducir cv na web.
O que máis demandan son os postos de Asesoría.
Na área de consultoría o desexable e que haxan consultores docentes.
Pódennos ter en contar en sucesivos proxectos.','Rodríguez','Malingre','Presidente/Gerente','2005-09-14','jorge@algalia.com','Jorge A.','986379587 / 667445597',NULL,568,93),
	 ('','Rubio','','Secretaria','2005-09-15','a.rubio@terraconti.com','Ana','916513681 ',NULL,571,93),
	 ('','Prego','','Xerente','2005-09-16','','Gracia','986262989',NULL,572,93),
	 ('','Díaz','','','2005-09-23','patricia.diaz@tmp.com','Patricia','914140500',NULL,573,93),
	 ('','Franco','','Gerente','2005-09-23','','Sergio','986226415',NULL,574,93),
	 ('Actividade: redacción do periódico ´A nosa terra´
Perfís maioritarios: informática (maquetadores, deseñadores, ...)
Engloban outra empresa que é a editorial ´Comercial Gráfica Nos´ que céntrase no deseño e maquetación de libros (ex. educación viaria)
Ten acordo ca universidade para cubrir as baixas de persoal nas vacacións.
A plantilla é de 20 persoas entre as dúas empresas. A última contratación foi de un mozo de almacén que costoulles atopar e non coñecían o noso servizo.','Costas','','Dtra. Admón.','2005-09-23','','Blanca','986433830',NULL,575,93),
	 ('','André','','Directora obra social en Vigo','2005-09-15','','Mª Luisa','986815081',NULL,577,93),
	 ('A súa actividade ven marcada polos estatutos da fundación. Teñen duas áreas diferenciadas:
- Deportiva (A Madroa) para o desenvolvemento de actividades deportivas non profesionais.
- Administración (no estadio) para a captación de recursos. Teñen un Call Center para a captación de socios (o persoal é contratado a través de Nortempo) e comerciais (seleccionados a través de EGA Recursos humanos). Mediante convenio ca  universidade dispon de administrativos en prácticas como apoio.
Teñen duas aulas disponibles para ceder ao concello ou alugar ás empresas que o soliciten.
Mostra interese nos ccc para teleoperadoras e queda en poñerme en contacto cunha empresa que pode estar interesada.','Fernández','Pérez','Director de Gestión','2005-09-28','gestion@fundacioncelta.com','Víctor','986213676 / 902104404',NULL,576,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Fernández','de la Cigoña Fraga','Gerente','2005-05-25','salvador.fernandez@es.issworld.com','Salvador','986493122 / 670768238',NULL,578,93),
	 ('Contacto establecido por referencia de Víctor Fdez (Fundación Celta) que é socio da empresa e amigo persoal do Sr. Glez.
Comenta que a súa actividade é servizos de marketing, pero integra 5 empresas: informática (mantenimento de software y hardware), comunicacións (páxinas web; ex.: ´demarisco.com´ que recibiu o premio ao emprendedor), protección de datos (rexistro das empresas), call center (40 traballadoras propias+ETT).
Traballa cas ETT por prezo (a que lle presente mellor presuposto en cada momento e mellores condicións para as traballadoras).
Precisa comerciais mulleres (máis fieles á empresa).
Considera que debe primarse ás empresas de Vigo. Vai a facerse cargo na feira de Navalia do call center e das acreditacións. Leva como call center empresas de fora (ex.: osasuna).
Terá en conta o noso servizo aunque non ve moita posibilidade de facer uso deste.','González','','Director General','2005-10-11','rgonzalez@espor.es','Roberto','902303323 / 659487748',NULL,579,93),
	 ('','Rodríguez','Vaqueiro','Gerente','2005-10-11','NOVA-CANELA@mundo-r.com','Juan José','986127736',NULL,580,93),
	 ('Ent. telefónica e fax
Polo xeral a asesoría coa que traballa é a que se encarga da contratación
E dificil contactar con eles pois sempre están na obra
Interesados na contratación e nas axudas á contratación','','','Respons. de mantemento','2005-05-06','','Víctor','670456349 / 986410082',NULL,581,139),
	 ('Ent. telefónica. Fan mobles de cociña e baño a medida. Para falar co responsable  de persoal (Daniel Gil) hai que chamar pola tarde','','','','2005-05-19','','Pedro Gómez','986486912 ',NULL,584,139),
	 ('Entrev telefónica
A oferta a fan a través de anuncios en prensa. Mulleres para temas de administración
Interesados','','','Enacargado','2005-06-17','','Jemrry Álvarez','617419150',NULL,586,139),
	 ('Entrev. telefónica
Polo xeral contratan persoas que levan o CV  á  propia empresa
É unha empresa proveedora do obradoiro
Envíanse CV','','','Xefe de RR.HH','2005-05-31','','Juan','986281932 ',NULL,590,139),
	 ('GUN (Gestores de Unidades de Negocio): Fan 2/3 promocións ao ano de reclutamento activo na universidade e pasivo por medio de correo (chegan de 45 a 50 cv diarios) e páxina web (por medio de infojobs fan criba de aspirantes). O perfil é de Lcdos. Económicas/Empresariais/Dereito, coñecementos de galego e de 22 a 26 anos. En cada promoción conseguen entre 600-700 cv e a consultora de Madrid Norman Brown selecciona 30 candidatos que pasan 4 entrevistas para quedar en aprox. 15 seleccionados cun contrato de 6 meses inicial e posterior contrato indefinido. Son os futuros Directores de oficiña ou Xestores de Negocio.
GIP (Gestores Integrales de Proyectos): é a saída profesional para as titulacións de enxeñería e informática.
Nas Comunidades Autónomas recurren a empresa de cazatalentos Norman Brown.
Para seleccións puntuais contratan en Vigo con SHL (para a selección de prescriptores).
Na Obra Social fan contratacións temporais de ordenanzas e persoal de mantenimento (que é por donde poderían contar co noso servizo).','Martínez','Nieto','Director Desarrollo RR.HH. Galicia y Mercados Exteriores','2005-09-29','rmartinez@caixanova.com','Rubén','986828302',NULL,583,93),
	 ('Ent. telefónica.
Interesados en formación, contratación e axudas','','','','2005-05-20','','Rodrigo','986240014',NULL,585,139),
	 ('2001Entrev. telefon.
Miriam (secretaria)
Normalmente fan formación pero fora do centro de traballo
O persoal de taller o contratan a través de coñecidos. O persoal de oficina a través de anuncio en prensa','','','Responsable de persoal','2002-01-01','','Alberto','986468508',NULL,587,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','González','López','Socio-Director','2005-10-14','mgonzalez@shl.es','Manuel','902998534 / 649944424',NULL,588,93),
	 ('Entrev. telefónica
Contratan temporalmente a través da oficina de emprego o anuncios en prensa','','','Responsable de RR.HH','2005-06-07','','Mª Carmen','986253773',NULL,593,139),
	 ('Entrev. persoal
Contratan a través de coñecidos. Non mulleres','','','Xerente','2005-06-08','','Francisco Rodríguez','986252328',NULL,594,139),
	 ('Achégase modelo oferta emprego','Fernández','','Directora oficina','2005-09-28','vigo@viajeselsontours.com','Rosa','986493603 / 635585396',NULL,595,93),
	 ('Lévase información','','','Secretaria','2005-05-20','clubnauticopanj@hotmail.com','Olalla','986366060 / ',NULL,596,139),
	 ('','Fernández','Puga','Xerente','2005-09-23','','José','986433830',NULL,575,93),
	 ('Terán en conta a información recibida.','Arias','','Gerente','2005-05-11','secretaria@mrcyb.com','Debora','986385000',NULL,598,139),
	 ('Enviada información; xa nos coñecen a través de Víctor o monitor de actividades nauticas.       ','Barciela','','','2005-05-09','kailua@kailuarule.com','Javier','986227533',NULL,599,139),
	 ('','','','Xerente','2005-05-05','ncarrerayates@mundo-r.com','Humberto Cervera','986220219  ',NULL,600,139),
	 ('Recibiron a documentación pero non necesitan nadie agora.                                       ','Barciela','','Gerente','2005-05-05','info@orkavelas.com','Chicho','986376543',NULL,601,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Montes','','Gerente','2005-05-06','tapiceriapascual@hotmail.com','Mª Isabel','986486305',NULL,602,139),
	 ('','Alonso','','','2005-05-05','innaval@terra.es','José','986232202',NULL,603,139),
	 ('','Pérez','Vázquez','Administrador','2003-02-27','hanaga@hanagasl.com','José Luis','986293737',NULL,606,93),
	 ('Enviada información.         ','','','','2005-05-10','pdiaz@tridentesl.com','P. Díaz','986447446',NULL,607,139),
	 ('','Iglesias','García','Apoderado','2003-04-11','','Casiano','986298711',NULL,608,93),
	 ('','','','Xerente/ Administrativa','2005-08-22','ascend@ascendrmm.com','Manuel Pérez Moure/ Margarita','986483156 / 986493273',NULL,612,139),
	 ('','','','Técnica de selección','2005-08-18','','Ana Pérez','986348228 / ',NULL,613,139),
	 ('','','','Dtor Económico-financieiro','2005-08-12','','Manuel  Estrella','916364946 / ',NULL,614,139),
	 ('','','','Delegado','2005-10-19','','Jose Manuel Carmona','915532446 / ',NULL,615,139),
	 ('','','','','2005-10-19','','Dolores Pérez','986425372 / ',NULL,616,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Pérez','','','2005-11-07','ainhoa.perez@ibv.es','Ainoha','944235277',NULL,618,93),
	 ('','Rodríguez','','Técnica de selección','2005-11-08','','Ana','986242694',NULL,619,93),
	 ('Contactado para completar información sobre as concesionarias do Concello. Na entrevista aportei información do noso servizo e mostrouse interesado pero non pudemos intercambiar moita información porque tiñan inundado o parking de urzáiz.
Ata agora subcontratan con APC (Ferrol) para os postos de Operario/Controlador cabina e de limpeza.','Fortes','','Administrativo','2005-11-09','','José Manuel','986093010',NULL,620,93),
	 ('Contáctase para ampliar información relativa ás concesionarias do Concello de Vigo. A forma de acceso é enviando cv por correo Att. Dpto. Persoal. Os postos máis ofertados, aunque non de maneira frecuente, son o de lector de contadores (FPII), fontaneiro e na administración. Envíase información do noso servizo por correo electrónico.','Díaz','','Dpto. Persoal','2005-11-07','ldiazg@fcc.es','Lucas','986371178',NULL,621,93),
	 ('Facilita o contacto ca responsable de RRHH de Ferrovial.','Rodríguez','Figueira','Gestor Técnico','2005-11-16','afigueira@ferrovial.es','Alberto','986376749 / 630957028',NULL,622,93),
	 ('','Torre','Galán','Director General','2005-11-22','dgeneral@mainsercontrol.com','Miguel Angel','914618500 / 636410700',NULL,623,93),
	 ('','Pérez','Pamies','Administrador','2005-11-18','','Juan Manuel','986487333',NULL,624,93),
	 ('','Rey','','Directora Fundación (Coruña)','2005-11-29','srey@fbarrie.org','Marta','981221525',NULL,625,93),
	 ('','López','','Xerente','2005-11-29','antonio.lopez@securitas.es','Antonio','986434549 / ',NULL,626,93),
	 ('A través da web ofrécese o teléfono de atención ao cliente 902423423 e por medio deste informan que o señor Vázquez de recursos humanos é quen vai a responsabilizarse da selección en Vigo.
O señor Vázquez indica que o proceso vai a iniciarse o próximo mes de febreiro; primeiro porán anuncio no Faro de Vigo para seleccionar o equipo xerencial (Xefe de equipo, Subxerente, ...) que terán que recibir unha formación previa de varios meses antes da súa incorporación ao posto de traballo; despois procederán á selección do persoal de sala e cociña, entre 40 e 50 persoas, aos que se farán contratos de 40 e 20 horas.
Infórmame a grandes rasgos porque aún non teñen nada concretado.
Quedo en achegarlle información sobre o noso servizo e con ela poda retornarme información da súa empresa.','Vázquez','','Rpble. Selección persoal en Vigo','2005-12-19','nvazquez@grupovips.com','Nicolás','912758239',NULL,627,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Dona','2005-09-05','','Cándida Tamborino Carrera','986210863 / 667944916',NULL,630,139),
	 ('','','','Responsable de RR.HH','2006-01-02','','David Melero','953700363 / 690851001',NULL,634,139),
	 ('Remítolle información do noso servizo ao señor Muñoz que está na sede central (Av. Aragón 328, Pol. Ind. ´Las Mercedes´. 28022 Madrid) e que me facilita a seguinte información:
Os postos ofertados en Vigo son de Axente Técnico de Mantenemento e de Axente Técnico de Limpeza con carné B1, condicións físicas e destreza manual e boa actitude. O salario oscila entre 2,1 ata 2,7 millóns das antigas pesetas. Non ten limitacións por idade (menor de 50 anos), sexo ou nacionalidade (sempre que falen o idioma e teñan os permisos en regra). Soen presentarse con autocandidatura ao enderezo en Vigo. 
O índice de rotación na empresa é do 22-25%. Proporcionan formación en: PRL, xestión de cargas, soldadura, carne camións, ...
O señor Muñoz remíteme amplia información dos perfís profesionais y características da empresa que arquivo.
Acceso: cv ao e-mail do señor Muñoz.','Muñoz','Rodríguez','Dtor. RRHH (Madrid) ','2005-12-16','josec.munoz@jcdecaux.es','José Carlos','913290443',NULL,628,93),
	 ('','Santos','','RRHH','2005-12-16','e.santos@interparking.com','Esperanza','914364680',NULL,629,93),
	 ('','','','','2005-09-13','','Juan Rodríguez Rodríguez','986485570 / 605893340',NULL,631,139),
	 ('','','','Dono','2005-07-04','','Francisco Mosquera','986253273 / ',NULL,632,139),
	 ('','','','','2006-01-02','','Pablo Estévez','886123487 / ',NULL,633,139),
	 ('','Loures','','Propietaria','2006-01-10','pililoures@yahooo.es','Pilar','635466056 / 615583149',NULL,635,93),
	 ('','','','Administrador','2006-01-16','','Tomás Legido / Mónica','981140045 / ',NULL,636,139),
	 ('Enviouse información.      ','','','','2005-05-15','administracion@cmcanido.com','Emilio','986460684',NULL,638,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Enviouse información.','Pereira','','Comodoro','2005-05-11','info@licebouzas.com','Javier','986232442',NULL,639,139),
	 ('Envío de documentación por internet e entrevista persoal co xerente                            ','Barreras','','Xerente','2005-05-06','','Javier','986443341',NULL,642,139),
	 ('Envío de fax con información','','','','2005-05-12','','Gloria','986213673',NULL,643,139),
	 ('Envío de dcumentación. Non necesitan persoal de momento','Román','','Xerente','2005-05-05','','Celso','986355812',NULL,644,139),
	 ('Proveedor da EO Mar de Vigo II','','','','2005-05-05','jesus@jbetanzos.com','Jesús','986232212',NULL,645,139),
	 ('Envío documentación','','','','2005-05-09','','Pablo','986470577',NULL,646,139),
	 ('Envío información','Leirós','','Director administrativo','2005-05-11','','Avelino','986339414 ',NULL,647,139),
	 ('','','','Axudas contratación','2002-07-15','','Armando','',NULL,29,139),
	 ('Envío de documentación. Apenas traballan con poliéster, adicase ao montaxe de p.deportivos e habilitación de barcos. De momento non necesitan persoal                 ','Rocha','','Xerente/Directora de fábrica','2005-05-13','info@aister.es','Mª Jesús','986486010',NULL,648,139),
	 ('Envío de información. La tendrán en cuenta','López','','','2005-06-05','c.n.nieto@telefonica.net','Javier','986235238',NULL,649,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('E  unha empresa de aislamento
Enviouselle documentación ','','','','2005-05-09','','Pili','986485773',NULL,650,139),
	 ('E unha empresa que so leva un ano, ven por mediación da EO. Necesita empastadores-laminadores xa que ainda que realizan traballos de carpintería, necesitan persoas que podan facer traballos de pintura, empastación ...                                             ','','','Dono','2006-01-23','','Cándido da Silva Graña','686270430 / ',NULL,651,139),
	 ('','Lázaro','','','2006-02-17','mlazaro@euroquality.es','Marta','915640219',NULL,652,93),
	 ('','De la Peña','','Xerente','2006-02-17','eldedal@mundo-r.com','Mónica','986415945',NULL,653,93),
	 ('','Názara','','Xerente','2006-02-06','gonvedraselec@hotmail.com','Patricia','986896043',NULL,654,93),
	 ('','','','Dona','2006-02-08','enteca@homail.com','Encarnación Alonso de Paz','986119414 / 616234769',NULL,655,139),
	 ('','','','Reponsable administración','2006-02-16','info@escuelasocastro.es','María Rego','986416916 / 986471383',NULL,656,139),
	 ('','','','Responsable RR.HH','2006-02-17','alexander75es@yahoo.es','Alexander Vidal','696152472 / ',NULL,657,139),
	 ('Contactamos pola apertura dun novo centro comercial en Gran Vía.O persoal primero fai formación a través da Xunta para poder comenzar a traballar. Hai unha folla de solicitude dos cursos nas oficinas de emprego ata o 3 de marzo.Vai haber cursos de reponedores, caixeiros, formativos e vendedores de productos frescos e seccións. Enviannos o perfil destes postos, a idade é ata 25 anos.','','','Xefe RR.HH / Técnica RR.HH','2006-06-12','','Fernando Álvarez González/Verónica Diego','986265486 / ',NULL,658,139),
	 ('Ante a información pola prensa (suplemento Expansión& Empleo) do 19/2/2006 da busca de 200 empregados/as para distintos postos. Solicítase envío de perfiles demandados e cartel para colocar no taboleiro de anuncios.                        ','','','Coordinador de Selección e Desarrollo','2006-06-09','joseluis.casado@warnerbrospark.com','Jose Luis Casado','918211279 / ',NULL,659,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Teñen a exclusiva da contratación do persoal das concesións que obten o grupo de empresas Corporación Masaveu.
Levan a delegación en Galicia desde fai 3 anos. As localidades donde teñen o maior nº de clientes son Vigo e A Coruña. En Vigo os postos máis solicitados son os de controlador de parking (prefiren persoas a partir de 40 anos de idade e con responsabilidades familiares. Traballan 6 días de seguido (2 de mañana, 2 de tarde e 2 de noite) e descansan 2 días.

A forma de acceso é entregando cv directamente na empresa ou ao persoal dos parking (parKing do Concello, da pza. da Estrela, da Laxe-robotizado e o de AENA). Solen facer 2 contratos de 6 meses e despois indefinido.

Pretenden a concesión do novo parking do CC. da Laxe.
Na Coruña tamén contratan conserxes e secretarias.
A súa empresa acaba de comprar unha empresa de limpeza e é a nova actividade que van a iniciar e donde habería posibilidades de c.c.c.
','Andrés','Díaz','Delegado Galicia ','2006-03-02','cm.andres@seguriber.es','Carlos Manuel','986441689',NULL,660,93),
	 ('','Rego','','Xerente','2006-02-28','eudervigo@hotmail.com','Luis','685676766 / 685676766',NULL,661,93),
	 ('Empresa independente de Contenur e Otto. Parécelle moi interesante o noso servizo e é probable que recurran a nós a partir de maio-xuño para as contratacións de xuño a setembro para cubrir vacacións.
Nas contratacións teñen en conta a mulleres e a maiores de 45 anos (polas reduccións de SS), o único que requiren é carne de conducir. Facilita cuestionario de solicitude de ingreso.','Callejo','García','Xerente','2006-03-13','ccalle@contenur.es','J. Carlos','986480093',NULL,662,93),
	 ('','','','','2006-03-01','sliste@uvigo.es','Kino Mosquera','986299563 / 629824409',NULL,663,139),
	 ('Fai unha oferta de emprego e logo ven para informarse do PME, ve moi positivo  facer un curso con compromiso de contratación.
Na empresa so traballan homes.','','','Responsable de administración','2006-03-13','jamiguez@imes.es','Jose Antonio Miguez Bastos','986213611 / ',NULL,664,139),
	 ('','Campo','Figueroa','','2006-03-17','','Juan Carlos','626123262',NULL,665,93),
	 ('','','','Xerente','2006-03-21','','Patricia Fernández',' 678866460',NULL,666,139),
	 ('O móvil é de Jose Manuel quen foi o que fixo a oferta persoalmente, el traballa nunha notaría. Maika é a súa muller e a que está na inmobiliaria.','','','Donos','2006-06-12','','Jose Manuel / Maika','986139292 / 645806070',NULL,667,139),
	 ('','','','Xefe de departamento','2006-03-23','','Luis Prados Anaya','986415111 / ',NULL,668,139),
	 ('','','','Xefa Persoal','2002-02-02','230','Begoña Domínguez','',NULL,1,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xefe de caixeiras','2002-02-02','','José María Acosta','',NULL,1,139),
	 ('','Ballesta','','Xefe persoal','2002-02-24','','Javier ','',NULL,4,139),
	 ('','','','','2002-07-16','','Pilar Paz','',NULL,94,139),
	 ('','','','Técnica de selección','2002-11-29','','Macarena Quintero','',NULL,72,139),
	 ('','','','Adxunto secretaría xeral','2002-02-06','986469301','Jose Carlos Castro','',NULL,31,139),
	 ('','','','Dpto Formación','2002-01-29','986432400','Francisco Nieto','',NULL,36,139),
	 ('',' ',' ','Orientadora laboral','2002-06-26','','Susana Rodríguez','asime@asime.es',NULL,28,139),
	 ('','','','','2002-07-24','986393016','Tomás','',NULL,174,139),
	 ('','','','Axudas Contratación','2002-07-23','','Lucía','',NULL,10,139),
	 ('','','','Axudas contratación','2002-07-24','','Ninfa','',NULL,11,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Axudas  contratación','2002-07-24','','Manuel Ayude','',NULL,13,139),
	 ('','','','','2006-05-19','','Ana','',NULL,21,139),
	 ('','','','Axudas contratación','2002-07-24','','Eva','',NULL,24,139),
	 ('Axudas á contratación','','','Oficiña','2002-06-27','','Marta','',NULL,66,139),
	 ('','','','Axudas contratación','2002-06-06','','Juan Vázquez','',NULL,73,139),
	 ('','','','Axudas contratación','2002-07-16','','Leonardo','',NULL,74,139),
	 ('','','','Axudas contratación','2002-07-24','','Pilar','',NULL,94,139),
	 ('','','','Axudas contratación','2002-07-22','','Rogelio','',NULL,109,139),
	 ('','','','Axudas contratación','2002-05-31','','Antonia Mouriño','',NULL,113,139),
	 ('','Peón','','oficina','2006-03-02','','Paco','986441689',NULL,660,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Axudas contratación','2002-06-11','','Dolores','',NULL,145,139),
	 ('','','','Axudas contratac.','2002-07-24','','Ana','',NULL,25,139),
	 ('','','',' PosibleFormación','2002-02-04','','Armando','',NULL,29,139),
	 ('Facemos visita e recollemos información sobre os cursos de carretilleiros','','','Formación','2002-07-25','627558109','Bernardo Dorrego','',NULL,147,139),
	 ('','','','Axudas contratación','2002-05-31','','Manuel','',NULL,148,139),
	 ('','','','Axudas contratación','2002-06-13','','Ramonita','',NULL,158,139),
	 ('','','','Axudas contratación','2002-06-03','','Santiago Labrador','',NULL,150,139),
	 ('','','','Axudas contratación','2002-07-17','','Carmen Campos','',NULL,151,139),
	 ('','','','respons. persoal','2002-10-15','986393016','Eva Costas','',NULL,174,139),
	 ('','','','Selección / Formación','2003-02-10','','Sonia Castro e Jorge González','',NULL,116,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xefe de Recursos Humáns','2002-09-06','','Carlos Martul','',NULL,1,139),
	 ('','','','RRHH','2003-02-06','986 481100','Manuel Martínez','',NULL,230,139),
	 ('','','','Axudas contratación','2003-03-18','','Manuel Ayude','',NULL,13,139),
	 ('','','','Axudas contratación','2003-03-18','','Clara','',NULL,31,139),
	 ('','','','Axudas ccontratación','2003-03-18','','Clara','',NULL,103,139),
	 ('Axudas á contratación 03','González','','','2003-03-25','','Araceli','',NULL,212,139),
	 ('Concesionaria do Concello de Vigo para o asfaltado.
Os postos de traballo máis solicitados son:
- Mecánicos recién titulados
- Peóns/oficiais obra pública
- Chófer camión
O acceso é por coñecidos/as ou achegando cv por fax ou correo electrónico.','Carrasco','','Rpble. RRHH','2006-01-10','laboral@sercoysa.es','José Luis','986876544',NULL,1040,93),
	 ('','','','Oferta C. compromiso contratac.','2003-05-08','','Jose Luis Rubianes','',NULL,184,139),
	 ('22/11/06 informan na entrevista mantida que o señor Freire está de Delegado na Coruña.','Freire','','Delegado','2006-06-05','986222906','Juan','Contactou Elisa Casal',NULL,130,139),
	 ('Fai oferta para docente de un curso de electricidade e un curso de fontanería que presentarán en proposta á Cruz Roja','','','Coordinadora','2003-09-03','645839846','Mª Jesús Bendaña','sisifo@mundo-r.com',NULL,193,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Achega oferta de Montador de mobles.
Xa non traballa na empresa.','Mezquita','Fernández','Técnica Selección','2003-09-24','','Esther','',NULL,72,93),
	 ('desde 2006 traballa en Solgest','','','Técnica Selección','2003-10-02','patricia.davila@adecco.es','Patricia Davila Canabal','',NULL,116,93),
	 ('Achégaselle información relativa ó PME e as axudas á cotratación.
O Grupo Base inclúe as empresas: Mix ETT, Herman´s Systems, s.a. (Merchandisisng & azafatas), Firdis (limpeza e mantemento) e Profeico Atlántico(Outsourcing).','Marzoa','Vázquez','Rpble. Comercial','2003-05-14','986481169','Manuel','m.marzoa@grupobase.com',NULL,125,93),
	 ('presenta oferta de emprego de xardinero','Castiñeiras','Rodríguez','Encargado de obra','2003-04-09','616575000','Manuel','',NULL,65,93),
	 ('Fai oferta de emprego de Comercial','','','Promotor Comercial','2003-04-24','986449854','Jorge López Guimarey','jorgelo@mapfre.com',NULL,89,93),
	 ('Fago seguimento e asesoramiento da documentación precisa para solicitar curso de compromiso de contratación.','','','Colaboradora','2003-05-15','639828884','Lali Pérez Cabral','lpcabral@mundo-r.com',NULL,217,93),
	 ('chama para recabar información para coñecer como facer unha oferta de traballo.','','','Administrativa','2003-06-12','913598402','Amelia Gómez','',NULL,276,93),
	 ('Amosa interés por cursos de compromiso de contratación para Carpinteiro naval e para Aislamento Naval.','','','Office Manager','2003-06-13','986223317','Emilia Fernández Goce','manager_vigo@randstad.es',NULL,128,93),
	 ('Pideselle presuposto para a limpeza da nave do Vao para o curso de laminador de poliéster.','','','','2003-06-09','','Pilar','',NULL,94,139),
	 ('A persoa coa que falo non consigo que se identifique. Establécese contacto para informar acerca del curso de Laminador/a de poliéster. Neste momento están ocupados co Salón Nautico de Barcelona e as posteriores vacacións. Considera que teñen máis necesidade de carpinteiros navais. Enviamos mailing informativo do curso.','','','','2003-10-16','986404202','Contacto telefónico','',NULL,176,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Chamo por si teñen neste momento algunha oferta de traballo. Quedo en enviarlle o c.v de Roberto Varela ','','','','2003-12-03','986266313','Ruth','cligama@retemail.es',NULL,168,139),
	 ('Prospección proxecto Asiste','Fresco','','Directora de programas','2003-03-12','986227103','Sonia','',NULL,345,139),
	 ('Negociación de prácticas proxecto Abeiro','Fresco','','Directora de programas','2003-07-08','986227103','Sonia ','',NULL,345,139),
	 ('Contacto a través da orientadora da E.O. Mar de Vigo II ','','','Gerente','2005-05-16','986374305','Estanislao Durán','pablo.yatesport@telefonica.net',NULL,184,139),
	 ('Centro de xogos. Só traballan pola tarde. Intentaron facelo pola mañan pero non tiveron éxito.
Tamén traballan sábados e domingos, mañan e tarde.
As contratacións as fan por amigos e familiares, son por horas.
Esta interesada no proxecto. Ela mesma atopou o seu  traballo a través do servicio de orientación Laboral.','','','Directora','2003-03-12','986241958','Begoña','',NULL,104,139),
	 ('Prospección prácticas Abeiro','Fresco','','Directora de programas','2003-06-08','986 22 71 03','Sonia','',NULL,345,139),
	 ('Oferta de traballo','','','Técnica de selección','2004-06-02','eva.rodríguez@adecco.es','Eva Rodríguez','986481210',NULL,116,139),
	 ('Información axudas contratación','','','Presidenta','2003-04-23','','Elena Piñeiro','',NULL,356,139),
	 ('Curso de palista','','','Responsable formación','2004-02-18','','Juan Vázquez','',NULL,73,139),
	 ('Visita inserción Abeiro','','','T. Social / Socia Xerente','2004-02-12','','Alba/María','',NULL,397,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita inserción Abeiro','','','Responsable SAD','2004-02-03','','Angela García','',NULL,375,139),
	 ('Visita Inserción Asiste','','','Responsable SAD','2003-03-10','','Angela García','',NULL,375,139),
	 ('','Vázquez','Noguerol','Rpble. de psiquiatría','2003-09-15','','Raul','',NULL,387,139),
	 ('Visita Inserción ASISTE','','','Directora','2003-03-06','','Beatriz Macías','',NULL,357,139),
	 ('Negociación prácticas Abeiro','','','Directora','2003-07-31','','Beatriz Macías','',NULL,357,139),
	 ('Visita Inserción ABEIRO','','','Directora','2004-02-24','','Beatriz Macías','',NULL,357,139),
	 ('Visita de Inserción Proxecto Asiste','','','trabajadora social','2003-03-10','','Sandra Ledo','',NULL,429,139),
	 ('Visita de Inserción do Proxecto Abeiro. quedouse con ela en remitirlle un listado da xente que estivera interesada en traballar en Axuda a Domicilio.','','','Trabajadora Social','2004-02-03','','Sandra Ledo','',NULL,429,139),
	 ('Visita Inserción Asiste','','','Directora','2003-03-12','','Angeles Alvarez','',NULL,323,139),
	 ('visita de insercion do Proxecto Asiste','','','Directora','2003-03-06','986262570','Loli','',NULL,362,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita Conveniar Practicas Abeiro.
Se anulan as prácticas do mes de Diciembre de 2003 por  considerar-as non axeitadas áformación e por problemas alleos ó Proxecto','','','Trabajadora Social','2003-07-14','','Sandra Ledo','',NULL,323,139),
	 ('Contacto telefonico para gestión de prácticas de Abeiro.
Finalmente non se levaron a cabo.','','','Directora-Gerente','2003-07-10','','Carmen','',NULL,349,139),
	 ('Visita inserción Abeiro. Quedamos en remitirlle un listado de alumnas para SAD','','','Directora-Gerente','2004-02-11','','Carmen','',NULL,349,139),
	 ('Visita conveniar practicas. No se concretan.','','','Resp. Vigo/Gerente Santiago','2003-09-23','','Ruth Blanco/Eduardo Teijeiro','',NULL,366,139),
	 ('Visitaconveniar Prácticas. No se concretan','','','Directr','2003-07-07','','José Antonio Atienza','',NULL,83,139),
	 ('Visita inserción Abeiro. Se lle remite listado de alumnas para SAD.','','','Directora de Programas','2004-01-29','','Sonia Fresco','',NULL,345,139),
	 ('Visita inserción Abeiro','','','Apoderado','2004-01-16','','Luis Suarez Filgueiras','',NULL,346,139),
	 ('Se convenian prácticas para Abeiro','Cores','','Jefa de Enfermería','2003-07-04','','Delia ','',NULL,332,139),
	 ('Visita Inserción Asiste','','','Presidenta','2003-03-12','','Elena Piñeiro','',NULL,356,139),
	 ('Visita conveniar practicas Abeiro','','','trabajadora Social','2003-07-03','','Angeles ','',NULL,356,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita Inserción Abeiro','','','T.Social','2004-02-17','','Angeles','',NULL,356,139),
	 ('Visita inserción Abeiro','Banda','','Directora','2004-02-02','','Carmen','',NULL,372,139),
	 ('Visita Inserción Abeiro','Somoza','','Directora','2004-02-03','','Concepción','',NULL,373,139),
	 ('Visita inserción Asiste','','','Directora','2003-03-11','','Dolores Novo','',NULL,370,139),
	 ('Visita convenio prácticas Abeiro. Non se concretan','','','Directora','2003-07-04','','Dolores Novo','',NULL,370,139),
	 ('Visita inserción Asiste. Se lla remite listado coasalumnas que teñen aux. de Clínica','','','Directora','2003-03-10','','Esther Silva','',NULL,368,139),
	 ('Visita conveniar prácticas Abeiro.','','','Directora','2003-07-02','','Esther Silva','',NULL,368,139),
	 ('Visita inserción Abeiro','','','Directora','2004-01-26','','Esther Silva','',NULL,368,139),
	 ('Visitas conveniar prácticas Abeiro','','','Madre Superiora','2003-07-10','','Madre Orosia','',NULL,376,139),
	 ('Viista inserción Abeiro','','','Supervisora de Enfermeras','2004-01-21','','Hermana Consuelo','',NULL,376,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita inserción Abeiro','','','Copropietaria','2004-01-26','','Anunciación Barciela Castro','',NULL,377,139),
	 ('Visita conveniar prácticas Abeiro','','','T. Social','2003-07-29','','Luz','',NULL,352,139),
	 ('Visita inserción Abeiro','','','T. Social','2004-02-10','','Luz ','',NULL,352,139),
	 ('Visita inserción Abeiro,
Realizouse a contratación de Justa Quiñones, participante del Proxecto Asiste.','Alvarez','','Directora/Propietaria','2004-01-28','','Angeles','',NULL,380,139),
	 ('Visita conveniar practicas Abeiro. Realízanse','','','Directora','2003-06-26','','Concepción Martinez Rguez','',NULL,378,139),
	 ('Visita conveniar practcas Abeiro','','','Directora','2003-07-02','','Alicia Pedrosa','',NULL,382,139),
	 ('Visita inserción Asiste
O longo de 6 meses traballou neste Centro a alumna de Asiste: Olga Glez Rivera','','','Directora','2003-03-12','','Mª Jesus','',NULL,369,139),
	 ('Visita conveniar prácticas Abeiro','','','Dtra','2003-07-01','','Mª Jesus','',NULL,369,139),
	 ('Visita Inserción Abeiro.','','','Dtra.','2004-02-04','','Mª Jesus','',NULL,369,139),
	 ('Contacto convenio prácticas Abeiro','','','Director','2003-06-17','','Miguel Angel','',NULL,383,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita Inserción Asiste','','','Directora','2003-03-06','','Nuria Pascual','',NULL,367,139),
	 ('Convenios practicas Abeiro','','','Dtra.','2003-07-08','','Nuria','',NULL,367,139),
	 ('Visita inserción Abeiro.
A Alumna de Abeiro Elisa López Ballesteros, comeza a traballar o día 18/02/04, para unha sustitución.','','','Dtra.','2004-01-23','','Nuria ','',NULL,367,139),
	 ('Visita para conveniar prácticas de Abeiro','Somoza','','Directora','2003-07-04','','Concepción','',NULL,373,139),
	 ('Visita conveniar prácticas Asiste. ','','','Socio-Director','2003-01-21','','Luis Barros','',NULL,203,139),
	 ('Visita coveniar pra´cticas Abeiro. No se concretan','','','Socio','2003-07-16','','Luis Barros','',NULL,203,139),
	 ('Visita inserción Abeiro.
Tienena 2 alumnas de Abeiro trabajando como A.A.D','','','Socio','2004-01-16','','Luis Barros','',NULL,203,139),
	 ('Visita de información para Abeiro','','','Directora','2003-04-29','','Fina Otero','',NULL,371,139),
	 ('Visita conveniar prácticas Abeiro','','','Dtra.','2003-07-11','','Fina Otero','',NULL,371,139),
	 ('Visita inserción Abeiro','','','Psicóloga','2004-02-26','','Silvia','',NULL,371,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita inserción Asiste','','','Directora','2003-03-07','','Mariem Moure','',NULL,353,139),
	 ('Visita conveniar prácticas Abeiro','','','Dtra.','2003-07-08','','Mariem Moure','',NULL,353,139),
	 ('Visita conveniar prácticas Abeiro','','','Trabajadora social','2003-08-25','','Mercedes López ','',NULL,374,139),
	 ('Visita inserción Abeiro','','','T. Social','2004-02-10','','Mercedes Lopez','',NULL,374,139),
	 ('Visita inserción Abeiro','','','Director','2004-02-19','','Pablo Muñiz ','',NULL,393,139),
	 ('Visita insercion Proxecto Asiste','','','Trabajadora Social','2003-03-10','','Luz','',NULL,352,139),
	 ('Visita de inserción Proxecto Asiste','','','Coordinadora de proyectos','2003-03-03','','Montse Lamas/ Amparo','',NULL,355,139),
	 ('','','','Técnica de selección','2004-02-25','','Eugenia García','',NULL,77,93),
	 ('Elxamex é a concesionaria para o mantenemento das zoas verdes nos cemiterios. Leonardo é o encargado en Vigo. Ten previsto a apertura dunha oficiña en Pontevedra. Os perfís máis demandados como persoal eventual son os de xardineiro o de oficiais da construcción.
A forma de acceso é achegando cv ao departamento de Persoal.','','','Encargado','2006-01-18','','Leonardo','615036590',NULL,1032,93),
	 ('visita de inserción do proxecto Asiste','','','Directora','2003-03-06','986.437.609','Flora Alonso','',NULL,363,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita de inserción no proxecto Asiste.
Concepción Sánchez Álvarez ha estado trabajando durante un periodo de 90 meses en este centro con contrato de jornada parcial.
Monica Rodriguez Cabezas está trabajando desde el 07/01/04 con contrato de jornada parcial.
','','','Directora','2003-03-05','986377726','Marta Bonar','',NULL,364,139),
	 ('Visita de inserción do proxecto Asiste','','','docente','2003-03-11','986.277370','Conchi','',NULL,359,139),
	 ('Realizouse a visita co fin de extraer información para enfocar o Proxecto Alicerce.','','','Trabajadora Social/TASOC','2004-04-13','','Cristina/Arantaxa','',NULL,351,139),
	 ('Realizouse visita có fin de extraer información para o enfoque do Proxecto Alicerce','Somoza','','Directora','2004-04-15','','Concepción','',NULL,373,139),
	 ('Realizouse visita có fin de extraer información para o enfoque do Proxecto Alicerce','','','Traballadora Social','2004-04-15','','Begoña','',NULL,382,139),
	 ('Realizouse visita có fin de reacabar información sobre o itinerario 3 (ocio e lecer na terceira idade) do Proxecto Alicerce.','Alvarez','','Propietaria/Directora','2004-04-22','','Angeles','',NULL,380,139),
	 ('Solicitouse información sobre o que se está a facer na área de Lecer e Tempo Libre, có fin de organizar o itinerario 3 do Proxecto Alicerce','','','Traballadora Social','2004-04-19','','Mercedes López','',NULL,374,139),
	 ('Recabouse información sobre o que se está a facer no centro na área de lecer e tempo libre có fin de organizar o itinerario 3 do Proxecto Alicerce','','','Directora','2004-04-20','','Beatriz Macías','',NULL,357,139),
	 ('Representa á empresa en Vigo e Pontevedra co nome de FYSER XXI, S.L.','','','Coordinadora de Formación','2004-04-30','616438811','Natalia Hernández Molero','',NULL,272,93),
	 ('','','','Orientadora Laboral','2003-07-29','formaron@asime.es','Yolanda Agra','986410139',NULL,28,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Preséntamoslle o Proxecto Alicerce, e solicitámoslle información sobre o que están a facer na área de Lecer e Tempo Libre','','','Presidenta/Trabajadora Social','2004-06-01','','Elena Piñeiro/Angeles','',NULL,356,139),
	 ('Ven por aquí para demandar comerciais','','','Asesora','2004-03-10','','Duvi','',NULL,89,139),
	 ('Viu por eiqui para demandar comerciais','','','','2004-04-05','','Alberto Mouriño','',NULL,161,139),
	 ('Ven para solicitar información do que facemos, xa que traballa en Ayubi unhas horas e en Aras outras.','','','Traballadora social','2004-05-11','','Lara','',NULL,346,139),
	 ('A visita ten como obxectivo presentarlles o Proxecto Alicerce, ver o que están a facer eles na área de lecer e Tempo Libre en Terceira Idade, e ver a posibilidade de colaborar con eles na fase de prácticas.','Barros','','Director','2004-04-24','','Luis','',NULL,372,139),
	 ('Negociación prácticas ALICERCE','','','Directora','2004-09-20','','Beatriz Macías','',NULL,357,139),
	 ('Negociación prácticas Alicerce','Barros','','Director','2004-09-02','','Luis','',NULL,372,139),
	 ('Negociación prácticas Alicerce. Fanse efectivas','Somoza','','Directora','2004-08-25','','Concepción','',NULL,373,139),
	 ('Negociación prácticas Alicerce. Fanse finalmente','','','Presidenta','2004-09-13','','Cristina','',NULL,456,139),
	 ('Negociación prácticas Alicerce','','','Gerente','2004-09-21','','Ana Tejada','',NULL,454,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Negociación prácticas Alicerce. Fanse finalmente','','','Anim. Sociocultural','2004-08-25','','Raquel','',NULL,455,139),
	 ('Negociación practicas Alicerce. Fanse finalmente','Alvarez','','Directora','2004-09-16','','Angeles','',NULL,380,139),
	 ('Reunión con Hugo e David veñen por eiquí para solicitar comerciais.Informoslle do servizo de orientación da Universidade','','','Comercial','2005-03-01','986493400','Hugo Fernández García','hfernandez@fibanc.es',NULL,259,139),
	 ('Presentación do Plan Municipal de Emprego
Visita as instalacións. As empresas de automoción resultalles moi difícil facer formación con compromiso porque é moi difícil facer previsión da necesidade de traballadores.','','','RR.HH/ Secretaria dirección','2005-02-18','','Karina Fdez/ Carmen Carneiro','',NULL,25,139),
	 ('O obxectivo foi para concretar a realización de prácticas na entidade.','Rivas','','Psicólogo','2004-10-05','986208874','Lesmes Manuel','MADRO@telefonica.net',NULL,511,139),
	 ('Contacto mantido para conveniar práctica formativas. Firmouse convenio de colaboración para a realización de prácticas do Proxecto Alicerce. 
Impartiron o módulo formativo de " Asistencia "         correspondente o itinerario de Adiccións e Conductas de risco dentro do P. Alicerce.     ','Otero','','Director Médico','2006-06-15','986482750','Francisco','uadcedro@terra.es',NULL,516,139),
	 ('Convenio prácticas formativas Proxecto Alicerce','Guimerans','','Directora Psícóloga','2004-11-18','986226269','Carmen','asvidal@vigonet.com',NULL,517,139),
	 ('Convenio prácticas formativas Porxecto Alicerce','Malvido','','Coordinadora de pisos de integración social','2004-09-28','986250240','Azucena','',NULL,518,139),
	 ('Convenio de prácticas formativas Proxecto Alicerce','Esteso','Mesas','Coordinador Médicos del Mundo Galicia','2004-10-28','630980081','Ramón','mdmvigo@eresmas.com',NULL,519,139),
	 ('Convenio de prácticas foramativas Proxecto Alicerce','Cancelo','','Director Médico','2004-10-07','986224848','Jesús','alborada@alborada.org',NULL,521,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Convenio de prácticas formativas Proxecto Alicerce','Estévez','','Corrdinador','2004-10-14','986374646','Manuel','phg_vigo@teleline.es',NULL,522,139),
	 ('Na reunión estaban presentes Ignacio Ojea( Xefe de Servizo), Chelo (técnica de inserción/prospección) e Rosa (coordinadora Proxecto Alicerce). O obxectivo era intercambiar información (ante a próxima apertura da residencia de Euxa en Vigo) e ver posibilidades de  colaboración. Resumo da reunión en ficha de empresa.','','','Director Euxa Vigo Centro Gerontológico','2005-05-18','','Andrés Vázquez','',NULL,429,139),
	 ('','','','Técnico selección','2005-05-24','986348228','Ana Pérez','recepcionp@absiderh.com',NULL,114,93),
	 ('','','','Técnica de selección','2005-06-03','986493131','Noemí','',NULL,126,93),
	 ('Actualización de datos da ETT','','','Administrativa','2004-02-17','986434988','Sonia','',NULL,118,93),
	 ('Presentación do PME 2004-2007','','','Respons. formación','2005-04-07','','Fátima Varela','',NULL,36,139),
	 ('Contacto para a posible realización de practicas dunha alumna do curso de MTL do Proxecto Alicerce','','','Madre Superiora','2005-04-18','','Madre Teófila','',NULL,376,139),
	 ('Visitas conveniar prácticas Alicerce (MTL y Animación)','','','Directora','2005-04-14','','Mª Jesús','',NULL,369,139),
	 ('Contacto para practicas dunha alumna do curso de MTL (Alicerce)','Alvarez','','Directora','2005-06-13','','Angeles','',NULL,380,139),
	 ('Contacto cara  a posibilidade de facer practicas do curso de MTL (Alicerce)','','','Trabajadora Social','2005-04-18','','Mercedes','',NULL,374,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Visita para conveniar prácticas de Alicerce. Finalmente fanse.Abril 2005: Cambia a dirección. Novo director: Alberto Pereira                                        ','','','Director','2005-04-26','','Alberto Pereira','',NULL,386,139),
	 ('','Alvarez','Ilarri','Xerente','2005-06-20','659480259','Pilar','',NULL,521,93),
	 ('','','','Secretario Comarcal','2004-10-27','','José Cameselle','',NULL,543,139),
	 ('','','','','2006-07-06','GAPSI@mundo-r.com','Milagros','986114685',NULL,1049,93),
	 ('Para as prácticas de Mediación do Alicerce se contactou con Cáritas e a Traballadora Social que se encarga deste servizo, Rocio, nos comenta que ela leva un mes no posto (antes estivera Charo) e que pensa que os usuarios non van queres ter unha persoa máis nas entrevistas e que entón a persoa de prácticas se tería que quedar no pasillo. ','','','Traballadora Social (atende inmigrantes)','2004-05-05','986223086','Rocio','',NULL,514,139),
	 ('Enderezo en Ibiza, 7. 28229 Villanueva del Pardillo. 
Fax: 918100718','','','','2005-06-21','918100716','Mónica Porto','trabajosocial@centroelabed???',NULL,210,93),
	 ('','','','Delegado','2005-07-08','986222906','Jorge Sieiro Froiz','jsieiro@trabatem.es',NULL,130,93),
	 ('Contacto a través da orientadora da E.O. Mar de Vigo II','','','Xerente','2005-05-09','986244612','Robert Baer','rbaer@davilasport.es',NULL,187,139),
	 ('Veu a presentar unha oferta de emprego. Recibiu información sobre as axudas á contratación e a creación de empresa, que supostamente desconñecía.','Ramirez','Lemos','Xerente','2005-07-20','journeytherapies@hotmail.com','José','686468772//607430495',NULL,475,93),
	 ('Solicita modelo de ficha de oferta de emprego e descoñecía o SOL, cando o Delegado fixera unha oferta este mes. Envío correo co modelo','','','Técnica selección','2005-07-22','986222906','Olalla Martínez','vigo@trabatem.es',NULL,130,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('A orientadora da E.O. Mar de Vigo II enviou documentacion.','','','Rpble. RRHH','2005-05-09','986494177','Jaime Fdez.','',NULL,225,139),
	 ('A orientadora da E.O. Mar de Vigo II enviou documentación','','','Dpto. Persoal','2005-05-09','986231362','Mario Cardama','info@astilleroscardama.com',NULL,234,139),
	 ('A orientadora da E.O. Mar de Vigo II enviou información por fax.','','','','2005-05-18','986403152','Sr. Castro','',NULL,175,139),
	 ('A orientadora da E.O. Mar de Vigo II enviou información por correo e infórmanlle que por agora non precisan persoal.','','','Persoal','2005-05-19','986372011','Julio Varela','j.varela@hrg.es',NULL,239,139),
	 ('A orientadora da E.O. Mar de Vigo II enviou información por correo e informáronlle que non precisan persoal por agora.','','','Dpto. Persoal','2005-05-13','986207798','Ana','lapin@lapin.es',NULL,245,139),
	 ('Contacto María EO Mar de Vigo
Non lle interesa','','','','2005-05-05','986360380','-','',NULL,177,139),
	 ('Contacto María EO Mar de Vigo.Enviouselle documentación por fax, xa que non descarta contratar a alguén, a pesar de que non resultou ben o contratado da EO MV I.','','','Xerente','2006-06-15','986472030','Fidel','',NULL,178,139),
	 ('Tendrán en conta a documentación recibida.','','','Xerente','2005-05-18','986338042','Carlos Pazó','comercial@astipol.com',NULL,152,139),
	 ('Tendrán en conta a documentación recibida.','Maseda','','Xerente','2005-05-16','986434711','Fernando','tranasa@futurmat.es',NULL,254,139),
	 ('Enviouselles documentación por internet','','','RRHH','2005-05-09','986393964','Cecilia Mariño','marketing@rodman.es',NULL,21,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Contactou María de EO Mar de Vigo.Coñecen a escola. Desde febreiro 2005 traballa Iago Carballido (alumno-traballador de carpintería de ribeira)','','','','2005-05-18','986404202','J. Antonio Vázquez','comercial@astinor.com',NULL,176,139),
	 ('Confirmo que Iago Carballido segue contratado e infórmolle das axudas á contratación. Envío fax ca información das axudas.','','','Dtor. Admvo. Financeiro','2005-08-02','986404202','Carlos Pousa','',NULL,176,93),
	 ('Enviouselle información por internet e resposta que por agora non precisan persoal, aunque o terán en conta.','','','Gerente','2005-05-19','986224878','José Barreras Sanjurjo','irijo@oceanosl.com',NULL,180,139),
	 ('Estudiarán a información que se lles enviou e chamarán eles.','','','-','2005-05-18','986471133','-','copermasa@mundivia.es',NULL,53,139),
	 ('Terán en conta a información recibida.','','','-','2005-05-13','986337200','Angel','poliesterporrino@hotmail.com',NULL,191,139),
	 ('Estudiarán a información recibida.','','','secretaria','2005-05-23','986212767','Begoña','',NULL,226,139),
	 ('Dende fai 1 ano Isabel Piñeiro (antiga xerente) traballa en Aister e o novo xerente é Andrés Lago Sánchez.','','','secretaria','2005-08-08','986212767','Begoña','',NULL,226,93),
	 ('Contáctase para confirmar e ampliar información sobre a oferta de mariñeiro.','','','Xerente','2005-09-22','600556625','Robert Baer','rbaer@davilasport.es',NULL,187,93),
	 ('Designada polo señor Pazó para tratar de poñer en marcha un c.c.c. de mantemento de parques eólicos. Quedamos en contacto para concretar a viabilidade deste proxecto.','','','','2005-09-09','986338042','Patricia','',NULL,152,93),
	 ('Chama para recibir información sobre a bolsa de traballo.','','','Técnica de selección','2005-09-27','986473456','Paula','vigo@select.es',NULL,129,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Chama con premura porque a psicóloga do centro deixa a empresa e precisa incorporar de forma inmediata outra persoa.','','','Responsable','2005-09-29','627350022','Carmen Ramirez','',NULL,300,93),
	 ('visítase para actualizar datos da ETT.','','','Asesora comercial','2003-12-23','986238449','Dolores Rodríguez Alonso','cenpla36c@cenpla.es',NULL,119,93),
	 ('Esta empresa pasa a chamarse ISS Facility Services. Dáse de alta na base de datos co ID 578','','','Gerente','2005-05-25','986493122','Salvador Fernández de la Cigoña Fraga','',NULL,94,93),
	 (' Contactou Mónica OE Vigozoo.
A partir do mes de abril contratan persoal. Os CV entreganse directamente','','','','2005-04-28','','Araceli González','',NULL,212,139),
	 ('Indicou os perfís profesionais cos que traballan e queda en enviar un correo con información máis detallada. Envíolle información das axudas á contratación e ccc.
Próximamente VAN A CAMBIAR DE ENDEREZO.','','','Consultora','2005-10-13','986473456','Paula Cortegoso Follente','vigo@select.es',NULL,129,93),
	 ('Entrev. persoal
En selección CV e referencias. Pouca demanda de traballalladores/as','','','','2005-04-28','','Araceli','',NULL,262,139),
	 ('O enderezo que aparece na ficha de Euxa é Carerretera Arteixo. Pto. km 1.8 A Grela 15008 Entrevista telefónica
Selección a través de entrevista persoal e poñen anuncios en prensa','','','Xerente','2005-04-26','981162953','Juanjo Castro','',NULL,429,139),
	 ('Entrev. telefónica O empresario está a punto de xubilarse. Non está interesado en ningunha acción do PME','','','Dono','2005-05-05','','Enrique Alonso Cebreiro','',NULL,52,139),
	 ('Entrev. telefónica e fax
So contrata traballadores formados','','','','2005-05-05','','J. Lorenzo','',NULL,173,139),
	 ('Interesado na contratación e nas axudas á contratación','Pérez','','Encargado','2005-05-05','','Jose Carlos','',NULL,53,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Ent. telefónica e fax
Moi interesado no programa de axudas','','','','2005-05-06','','Ramón','',NULL,69,139),
	 ('Entrev. telef, Fálase coa secretaria en varias ocasións pero non se consigue falar co xerente.','','','','2005-05-12','','Secretaria','',NULL,47,139),
	 ('','Cominges','','Xerente','2012-03-07','','Alberto','',NULL,25,93),
	 ('Entrev. telefón. Interesados en formación e nas axudas á contratac.pero é unha empresa que viu a menos
Contratan a través de anuncios de prensa e do SGC','','','','2005-05-12','','Mª Carmen','',NULL,106,139),
	 ('Entrev. persoal
Interesados na bolsa e nas axudas. Os postos que requiren é  vendedores e xardineiros','','','Xefe persoal','2005-05-19','','Manuel Castiñeiras','',NULL,65,139),
	 ('Entrev telefónica
Interesados na contratación','','','Secretaria','2005-05-20','','Marta','',NULL,71,139),
	 ('Entrev. telefon.
Teñen a plantilla cuberta, interesalles información sobre subvencións','','','','2005-05-19','','Mª José','',NULL,51,139),
	 ('Teñen plan de formación de empresa
Envíanse CV do obradoiro','','','RR.HH','2005-05-30','','Rafael Martínez','',NULL,281,139),
	 ('Chama para coñecer si dispoñemos de inxectadores de poliuretano, non se leva a cabo a oferta porque informo que acabo de deixar vacante unha oferta igual. Envíase modelo de ficha de oferta de emprego.','Martínez','','Administrativa','2005-09-15','986377037','Isabel ','isabel@regenasa.com',NULL,308,93),
	 ('Facilítame o contacto con Ruben Martínez que é a quen fai chegar a súas necesidades de persoal.','','','Rpble. Actividades obra social','2005-09-22','986120073','María Pereira','',NULL,583,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Enviada información','Domínguez','','Dpto. Persoal','2005-05-13','986279282','Charo','regenasa@regenasa.e.telefonica.net',NULL,308,139),
	 ('Enviada información e imposible establecer contacto posterior co señor Mera.','','','RR.HH','2005-05-09','986296000','Sr. Mera','mera@balino.es',NULL,237,139),
	 ('Terán en conta a información remitida, nese caso chamarán eles.','','','','2005-05-18','986231333','Carmen / Margarita','carpnavaljperez@telefonica.net',NULL,49,139),
	 ('Recibiron a información pero, por agora, non teñen necesidade de persoal.','','','Gerente','2005-05-29','986290559','Manuel Angel Villar','krugcomercial@mundo-r.com',NULL,469,139),
	 ('Entrev. con Eva e envío de información
Mándanse  5 Cv para carpinteiro naval. Non son contratados por necesitar xente con mais experiencia','','','RRHH/ Director de producción','2005-05-09','','Eva Costas/ Tomás Pérez','',NULL,174,139),
	 ('Fixeron entrevistas para persoal en poliester (para facer flotadores en pantalanes) e contrataron a Luis Alberto Lago, non descartando contratar máis adiante a Oscar Lago.','','','Gerente / ','2005-05-27','619469974','Rodolfo Andrade / Estela','rodolfo@ronautica.com',NULL,153,139),
	 ('Envíase de novo a documentación porque non a recibiran.','','','','2005-05-26','986293737','Beatriz','hanaga@hanagasl.com',NULL,606,139),
	 ('Recibiron a documentación que se lles achegou, pero non precisa persoal por agora.','','','','2005-05-13','isa@chorronaval.com','Isabel','986298711',NULL,608,139),
	 ('Belén xa non está na empresa. Envío modelo de oferta de emprego.','','','Administrativa','2005-11-04','981208990','Julia','globalazaga@globalzaga.com',NULL,342,93),
	 ('Cargo incluído na concesión.
Adícase a xerencia do centro comercial (xestión, arrendamentos, subcontratas de limpeza-APC/seguridade-Securitas/mantemento-Ferroser) e do parking (subcontratas de limpeza e cobradores-APC Servigalicia/seguridade-Securitas/mantemento-Ferroser). Infórmolle do noso SOL.','Martínez','','Xerente','2005-11-23','marcos.martinez@plazae.cc','Marcos','986485650',NULL,624,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Quedan en enviar por email documentación da nova convocatoria.','','','','2005-11-29','977779192','Ana','',NULL,427,139),
	 ('','','','Coordinadora','2004-03-03','986441022','Mª Jose Fernández/ Raquel','',NULL,85,139),
	 ('Ven por eiquí para solicitar comerciais. Trae un cartel que poñemos no taboleiro de anuncios','','','Xefe de equipo','2005-12-14','652091773','Sebastián Romero','',NULL,207,139),
	 ('Enviouse información que van a estudiar e poránse eles en contacto.','','','','2005-05-18','986262354','Enrique Cameselle','carmad@retemail.es',NULL,592,139),
	 ('Representa ás empresas Ferrovial Servicios, S.A. e Eurolimp.
A forma de acceso é levando CV e cubrindo ficha solicitude, por persoas coñecidas, na web: www.ferrovial.es ou respondendo aos seus anuncios na Voz de Galicia e no Faro de Vigo (só si o posto é só para Vigo).
Optan ás empresas por concurso público e os postos máis requiridos son de oficiais de mantemento (FP Electrónica/Electricidade/Frigoristas) sen límites de edade. Entre outras teñen as contratas dos centros penitenciarios galegos, da base militar de Figueira, de Faurecia, ...
O Delegado en Galicia é Alberto López e dependendo deste está un Xefe de Area (do que dependen os Xestores de cada contrata) e a Xefa de Admón (baixo ela está a Rpble. RRHH que reporta directamente a Madrid).
Cando ten que contratar con ETT o fan con Randstad -monitores- (que é unha das tres que recomenda a central).','Martin','','Rpble. RRHH Ferroser','2005-12-05','986376749','Cristina','',NULL,622,93),
	 ('Chama para facer oferta de emprego de Auxiliar de Servicios','Chapela','','','2005-12-07','696483392','Juan','juan.chapela@securitas.es',NULL,626,93),
	 ('Leva ela soa a empresa, a súa socia Sonia aprobou a oposición de maxisterio en Sevilla. Actualizo enderezo, teléfonos e e-mail.','Quiroga','','Xerente','2006-01-19','609100809','Celia','celia@fervellos.com',NULL,314,93),
	 ('Chamada de seguimento e actualización de datos. Fai oferta de emprego','','','Rpble. RRHH','2006-01-30','986494177','Jaime Fdez. Arrabal','rrhh@gonsusa.es',NULL,225,93),
	 ('Reunión Elisa e Chelo, intercambiamos información da sua empresa e do Concello','','','Coordinadora de servizos','2006-02-09','','Olalla Vázquez','non está na empresa',NULL,415,139),
	 ('','Formoso','','','2006-04-19','','Liliana','',NULL,1002,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Axudas á contratación','','','','2002-07-23','','Ana','',NULL,21,139),
	 ('','Pintado','','','2004-01-28','','Marcos','986221159',NULL,426,93),
	 ('Na reunión mantida informa: 98% de contratacion indefinida.O convenio colectivo da empresa especifica que a forma de acceso a determinados postos é por promoción interna e tamén favorecen o acceso mediante recomendación de achegados á empresa. Cando solicitan perfís técnicos (p.ex. PRL) recurren a anuncio no Faro de Vigo e poderían contar co noso servizo. O que teñen máis dificultade en conseguir é candidatos para o posto de peón-chofer carné C polivalente. As incorporacións que estánse dando na empresa é debido ás xubilacións.','Guerra','Martin','Jefe de Relaciones Laborales Delegación Galicia M.A.','2006-02-02','986485300','Miguel A.','maguerram@fcc.es',NULL,115,93),
	 ('','Millán','Fernández','xerente','2006-05-09','','Victoria','986128548',NULL,1003,139),
	 ('','Picos','','Técnica de selección','2006-04-10','administración@responlabor.com','Carlota','615910746',NULL,497,139),
	 ('Recibiron a documentación pero non necesitan nadie agora.                                       ','Barciela','','','2005-05-05','','Ana','986376543',NULL,601,93),
	 ('recibiron a información; por agora non necesitan persoal, só ten un traballador a tempo parcial. Se necesita persoal poráse en contacto co SOL.                        ','Montes','','Gerente','2005-05-18','','Mª Isabel','',NULL,602,93),
	 ('Ven por eiquí cun compañeiro para informarnos do que fan nesta consultora e ver se podemos colaborar con eles. Deixannos información sobre as súas actividades                        Ven por eiquí cun compañeiro para informarnos do que fan nesta consultora e ver se podemos colaborar con eles. Deixannos información sobre as súas actividades                        Ven por eiquí cun compañeiro para informarnos do que fan nesta consultora e ver se podemos colaborar con eles. Deixannos información sobre as súas actividades                        ','Cambeiro','Técnica de selección','','2006-05-09','','Rosa','986229728',NULL,507,139),
	 ('','Del Río','Bermúdez','xerente','2006-05-09','','Luis Miguel ','607446401',NULL,1004,139),
	 ('','Souto ','Vázquez','Técnica de selección','2006-04-20','lsouto@grupovips.com','Lydia ','912758239',NULL,627,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Actividade: selección e contratación no sector sanitario e científico.
Fai unha oferta de emprego e envíase e-mail informando que non temos candidatos dispoñibles e outros enderezos aos que pode dirixirse para as contratacións do resto de Galicia.','Rodríguez','','Técnica selección','2006-05-25','rmaria.rodriguez@adecco.es','Rosa','902197135',NULL,1022,93),
	 ('','Acosta','','Xefe de caixeiras','2002-02-02','','Jose Mª ','',NULL,1,139),
	 ('','Ballesta','','Xefe persoal','2006-05-19','','Javier ','',NULL,4,139),
	 ('','Piñeiro','','Xerente','2003-02-11','','Isabel','986212767',NULL,226,93),
	 ('','Prados','Anaya','Xefe de dpto selección e formación personal','2006-03-23','','Luis','',NULL,20,139),
	 ('','Mariño','','Rpble. RRHH','2003-10-06','','Cecilia','',NULL,21,93),
	 ('','Silva','','Rpble. Personal','2003-03-04','','Marcos','986493100',NULL,242,93),
	 ('','Riveiro','','Gerente','2003-03-06','','Visitación','986207798',NULL,245,93),
	 ('','Díez','Alonso','Dtor. Gerente','2003-03-06','','Julián','986213693',NULL,246,93),
	 ('','Palmero','','Dpto. Personal','2003-03-14','','Carlos','986377111',NULL,250,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Amoedo','','','2003-04-24','rmamoedo@fibanc.es','Rosa','986443454',NULL,259,93),
	 ('esposa Pedro Pazó','','','','2003-07-09','','Loli','630145016',NULL,287,93),
	 ('Contacto no Foro de Dinamizac. Area metropolitana Vigo-Oporto, para envío de información PME','Sande','','xerente','2006-03-30','','Andrés ','986462021',NULL,26,139),
	 ('O proxecto Cidade + solicitoulles un curso.Solicitude de formación con compromiso de contratación. Propón 2 o 3 persoas por empresa. E un sector masculino. Adsime está propoñendolles que se asocien e a cambio darialles formación (Formega) e un servizo de prevención mancomunado','Mathieu','','Xerente','2005-02-24','','Armando','',NULL,29,139),
	 ('','Cazorla','','Rpble. área laboral','2003-07-21','','Miguel','986439470',NULL,292,93),
	 ('','López','','Becario','2003-02-19','','David','',NULL,87,139),
	 ('Solicitude de comerciais
','López','','Asesor de clientes','2006-04-11','','Jorge','',NULL,89,139),
	 ('Persoa de contacto en Vigo','','','contacto en Vigo','2004-12-11','','Heriberto','670521892',NULL,485,93),
	 ('Prospección','','','Técnica selección','2004-11-15','','Paula Rey','',NULL,136,139),
	 ('','Viana','Tomé','Rpble. Comunicación e Didáctica','2005-07-22','','Marta','986113908',NULL,559,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Grandal','','Gerente','2005-08-09','','Enrique','986292207',NULL,563,93),
	 ('','Lago','','Técnica selección','2005-09-07','','Verónica','',NULL,566,93),
	 ('','Panete','','Técnico de formación e emprego','2005-09-16','','Miguel','986262989',NULL,572,93),
	 ('','','','Administrativa','2005-09-16','','Luz','986262989',NULL,572,93),
	 ('','Barreras','','Rpble. Prevención riscos laborais','2003-02-27','','Sonia','986293737',NULL,606,93),
	 ('Informac. sobre o PME, non estaba moi disposta a dar información ','Canda ','Pereira','Responsable de selección e contratación','2006-03-09','','Marta ','986443041',NULL,489,139),
	 ('Despois de coincidir en Franquiatlántico, veñen por eiquí para solicitar comerciales e volven a informarme do seus productos de seguros.','','','Xerentes de equipo','2006-03-14','','Julia Carazo/Begoña Díaz','',NULL,506,139),
	 ('Envía un correo electrónico informándo dos postos que necesitan. Colocase a información no taboleiro','Rueda','','','2006-05-30','elena.rueda@parquewarner.com','Elena','',NULL,659,139),
	 ('Responsable para a recollida e transmisión de información e concertar visitas.','','','Representante en Vigo','2005-11-29','','Mirian','986110220',NULL,625,93),
	 ('','','','Selección','2006-02-06','','Beatriz','986896043',NULL,654,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Envianos correo co resultado da selección dos comerciales.','Novo','Iglesias','Responsable delegación','2006-04-12','rpvigo@seguroseci.es','David ','986223410',NULL,668,139),
	 ('Envía correo co resultado de dúas persoas da oferta de marzo de comerciales.','Martín ','De Antonio','Dpto Formación-selección','2006-05-30','','Raquel','914023883 ext.3295',NULL,668,139),
	 ('Fai unha oferta de meprego de aux. administrativa.','Ruas','','','2006-04-05','paularuas@valglass.es','Paula','',NULL,1001,139),
	 ('Reunión Julia e Chelo. Neste momento van facer un curso co programa Cidade +, dependendo dos resultados farían con outras entidades. Quédase de volver a falar a mediados de maio. 
O perfil que demandan é FP de mecánica... ou experiencia en automoción. Non traballan con ETTs.','Casal','Nuñez','Director RR.HH','2006-04-05','','Carlos ','',NULL,1006,139),
	 ('Envío información PME
Instalaranse no CC Gran Vía.
1º fan formación 160 horas pero xa estarían contratadas. Farán contratos de 6 meses (2 meses de proba)+ 6 meses e logo contrato indefinido.','Peña','','Responsable de ventas','2006-06-13','','Mónica ','',NULL,1007,139),
	 ('Fan fundas para asientos para automoción. Están no sector textil. Fixeron cursos co FSE (100 horas para desempregados). Están un pouco cansados coa formación polo tema da burocracia. A formación ten que adaptarse os turnos d etraballo de mañan e tarde. A idade non importa moito, o que necesitan é experienncia como maquinista e sobre todo para traballo en cadea.','Fernández','Lago','RR.HH','2005-04-22','','Esperanza','',NULL,1008,139),
	 ('Traballan para Citroen, Seat e Renault. Agora están intriducindose no sector ferroviario. Traballan con Ranstad e Laborman. REclutan a través destas ETTs e da recepción de CV. Tres quendas de traballo. Teñen 218 traballadores dos cales en planta so teñen 2 mulleres

6/3/2012: xa non traballa na empresa.','Prieto','(non traballa na empresa)','RR.HH','2004-05-13','','Sandra','',NULL,1009,93),
	 ('Envíase información que lles parece interesante cara a Volvo Ocean Race.             ','Andrade','','Gerente','2005-05-09','','Oscar','986432112',NULL,597,93),
	 ('A casa matriz de Adecco en Bruselas comprou o Grupo Human que integra a Alta Gestión ETT; Alta Gestión segue funcionando con ese nombre e en competencia con Adecco.                     ','Lemos','','Técnica selección','2005-06-09','','Teresa','',NULL,118,93),
	 ('por agora non lles interesa a información recibida, xa que só reparan motores.        ','Alonso','','','2005-05-13','','José','986232202',NULL,603,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('E unha empresa pequena de calderería e montaxes industriales.A formación podería facerse de xeito compartido con outras empresas. Parecelles interesante o tema da formación, así como solicitar traballadores en caso necesario. Eles teñen xente que fai os cursos de soldadura de Salvador (Escola de soldadura en Valadares)','','','Donos','2004-05-24','','Toñi/Ramón','',NULL,1010,139),
	 ('Posibilidade de realizar un curso no sector medioambiental en Toysal para mulleres. Toysal montou unha empresa de reciclaxe de residuos pero neste momento non hai persoal formado','','','Técnicas de selección','2005-01-26','','Sonia/Dolores','',NULL,116,139),
	 ('Contacto para solicitude dun novo curso dre formación','González- Puelles','Casal','Xefe de caixas','2006-02-01','m.gzlez-puell@alcampo.es>','Miguel ','',NULL,166,139),
	 ('Contacto para solicitude curso caixeiro/a','','','','2006-02-01','coordinadoras.vigo1@alcampo.es','Tensi','',NULL,166,139),
	 ('Acceso á empresa entregando cv ou polo SGC.
Postos máis demandados (verano):Operarios e Maquinistas de pintura de tráfego. Outtros perfís na empresa: admvo., delineante, enxeñeiro camiños e operarios de carga e manexo.
Fan contrato por obra e solicitan referencias.','Martínez','','Delegado','2006-02-15','api-vigo@apisa.net','José Manuel','986420624',NULL,1014,93),
	 ('Fainos unha oferta de limpadores/as porque pode ser que lle den a concesión para o novo centro comercial de Gran Vía, pero falando con él comentolle qeu cando a oferta sexa firme que nos chame para confirmalo','Lorenzo','Herrera','Xefe de persoal','2006-04-26','','Eduardo','',NULL,1015,139),
	 ('Fai unha oferta de asesores financieiros para Coruña, falando con ela comentame que o salario é de 700€ mais comisións de luns a sábado.','','','Coordinadora','2006-05-03','','Aida','',NULL,1016,139),
	 ('Tiveron plan FIP hai moitos anos, pero logo cambiaron os cursos e xa non quixeron volver a plantearselo. Teñen instalacións para desenvolver cursos de patronaxe por ordenador. Non está intersada en recibir información do PME ','','','','2005-04-11','','Carmen','',NULL,1011,139),
	 ('Neste momento teñen 22 empresas, sobre todo de enxeñería de novas tecnoloxías. No teñen coñecemento de empresas que podan facer formación no Polígono. Interesalle o tema das axudas á contratac. porque as empresas que comenzan alí pode necesitar traballadores.No CIE asesoran no plan de empresa, na busca de financiación, na xestión de subvencións...','Novoa ','Miñambre','Xerente','2005-04-20','','Pelayo','',NULL,1012,139),
	 ('En Vigo o enderezo é en García Barbón 22, entreplanta. Explicame o plan experimental de emprego. Traballarán con 90 persoas, o INEM envioulles 200.O perfil son inmigrantes 10%, discapacidade 10%, parados de longa duración e mozos/as sen cualificar. Remata o 31/3/2005','Terlera','','Técnica de selección','2005-10-14','','Ana ','986221672',NULL,567,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Poñemonos en contacto con eles ante unha solicitude que lle fan a concelleira para participar nun concurso de teleoperafdoras que celebrarase en Vigo. Os premios son contratos e metálico. Ante esto busco información sobre a empresa e fago un informe que se lle pasa a concelleira, no que se lle cnta a información recollida.','','','Responsable do dpto de comunicación/ director','2005-08-23','','Angeles Testas/ Franck Sastre','',NULL,1013,139),
	 ('','Taboada','Duro','','2006-05-08','','Beatriz','',NULL,1017,139),
	 ('Informolle de como traballamos porque a dúas ofertas de emprego que fixeron era para recollida de C.V','','','','2006-05-10','','Manuel','',NULL,1017,139),
	 ('','Aguirre','','','2006-05-09','','Montse ','',NULL,1018,139),
	 ('Envía unha oferta de comercial pero as persoas que se envían di que son moi maiores cxanod falando con el dixo que non lle importaba
a idade','Delgado','','','2006-04-25','','Victor','',NULL,1020,139),
	 ('','Fernández','','','2006-05-15','','Jacinto ','',NULL,1021,139),
	 ('Como non se pode saber do resultado da selección, informanos das persoas que contrataron por tres meses e ningun dos nomes coincide coas persoas enviadas polo SOL.','','','Supervisora de tendas Vigo e Coruña','2006-06-21','','Belén','986471728/881927141',NULL,1018,139),
	 ('Facilita este contacto o xerente da Tapería Bocatín. Chámase para obter información sobre a relación de empresas que van a estan no C.C. Gran Vía. Queda en facilitarme esta listaxe.
Eles levan a xestión inmobiliaria do centro comercial e a apertura está prevista para maio-xuño. Posteriormente, a división de Auxideico formará a xerencia (normalmente alguén da entidade) que xestionará o centro comercial e as zoas comúns (estes servizos contrataránse pola xerencia).','Castro','','Comercial (División desarrollo y promoción)','2006-02-21','monica@granviavigo.com','Mónica','986447500',NULL,1023,93),
	 ('','López','','Directora General','2005-12-16','','Isabel','913290443',NULL,628,93),
	 ('Achega oferta de emprego que poñemos no taboleiro.','Pazos','','','2006-05-29','juanpazos@telefonica.net','Juan','986727091/605992250',NULL,1026,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Veu xunto ca xerente do Colexio para solicitar información relativa ao noso servizo e así poder asesorar e no seu caso dericar aos seus usuarios/as.','Coello','','Vocal do Colexio','2006-06-20','cograsop@telefonica.net','Mª José','986200918',NULL,1027,93),
	 ('Lidia Souto é a nova responsa (o anterior reponsable deixou a empresa)
Aínda non iniciaron o proceso, polo que non concretaron as súas necesidades, dependen da execución das obras que estánse demorando.
Facilito os nosos datos para que poda contactar en canto sexa factible.
','Souto','Vázquez','Técnica de selección','2006-03-02','lsouto@grupovips.com','Lydia','912758239',NULL,627,93),
	 ('Ven por eiquí para facer unha oferta de emprego','Domínguez','Villanueva','','2006-04-19','','Marta','',NULL,1024,139),
	 ('Fai unha oferta de traballo','Varela','','','2006-05-30','','Tomás','',NULL,1019,139),
	 ('Contacto en SICO (feira da construción). Queda en enviar información sobre actividades formativas','Domínguez','','','2006-06-23','','Sara','986430619',NULL,1031,139),
	 ('Concesionario do servicio da grúa e depósito.
O posto máis demandado é o de chófer para facer substitucións.
A forma de acceso é cubrindo ficha de solicitude de emprego na empresa.','Rodríguez','Comesaña','','2006-02-06','','Ernesto','986470133',NULL,1033,93),
	 ('','Gómez','Cerón','','2007-02-22','david.gomez@eurocontrol.es','David','687975278',NULL,1096,93),
	 ('Veu xunto ca vogal do Colexio para solicitar información relativa ao noso servizo e así poder asesorar e no seu caso dericar aos seus usuarios/as.','Fonseca','','Gerente','2006-06-20','cograsop@telefonica.net','Isabel','986200918',NULL,1027,93),
	 ('Aínda que é a rpble. RRHH de Pescavega fai a oferta de emprego de outra das súas empresas que é Vigo Seafood. Chamo para concretar perfil solicitado.','Pérez','','Rpble. RRHH Pescavega','2007-02-28','rrhh@pescavega.es','Miriam','626481511',NULL,1097,93),
	 ('','Martínez','','Gerente','2006-03-16','','Germán','986202052',NULL,1028,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Entrevista mantida con Ana: Teñen a concesión do parking soterrado da rúa Pintor Laxeiro baixo a denominación de empresa: Seromar, S.A. e o parking de P. Xoan Piñeiro (Concello-López Mora). O perfil correspondente é de Taquillero/a; a única posibilidade  de acceso é en vacacións (xuño a outubro) polo que habería que entregalo cv a partir de maio.
A súa actividade principal é a de promoción inmobilidaria e están pendentes da aprobación do PXOU (teñen moito solo comprado en Vigo), que implicaría maior nº de contratacións.
','','','Dpto. RRHH','2006-03-16','','Ana','986202052',NULL,1028,93),
	 ('Contacto en SICO ( feira da construción). Tewñen necesidade de electricistas. Esta empresa adicase os cadros eléctricos.','Galiñanes','González','Dirección técnica','2006-06-23','oftec@sielvigo.com','Eladio','649817962',NULL,1030,139),
	 ('A oficiña de Olga Pérez sitúase no parking de Fernando Católico.
A empresa leva as concesións dos parking de Fernando Católico, da rúa Coruña e o da rúa Venezuela.
As contratacións que fan coinciden cos períodos de rebaixas, navidades, IRPF, ... segundo a localización do parking. Os perfís máis demandados son os de Controlador/a de cabinas e de Persoal para dirixir tráfego. A forma de acceso é achegando cv.','Pérez','','Rpble. Persoal','2006-03-27','','Olga','986473556',NULL,1029,93),
	 ('Concesionario do 010 no Concello de Vigo.
A súa actividade son servizos e consultoría: telemarketing, task force e marketing relacional.
Mantén actividades similares con outras administracións públicas.
Pode achegarse o cv por e-mail. Seleccionan por infojobs e o SGC, e fan campañas ao longo do ano.
Os postos máis ofertados son de teleoperadores e de comerciais.','Garrido','Porto','Director GSS Atlántico','2005-12-15','pgarrido@grupogss.com','José','981217373',NULL,1034,93),
	 ('Fai unha oferta de operario de limpeza de coches na que o requisito imprescindible é a responsabilidade dos candidatos. Recibiu queixas dos seus clientes  polas persoas que ten contratadas (falta e/ou mal coidado de obxetos persoais dos clientes)','Rodríguez','López','Xerente','2006-06-27','','Carmen','627440951',NULL,487,93),
	 ('Envío de oferta de emprego. Nesta empresa fan selección de todos os perfís profesionais.','Alvarez','','','2006-06-08','','Yolanda','',NULL,1037,139),
	 ('Elisa e Chelo mantemos unha entrevisat con ela para informarnos son¡bre o que se fai neste centro e informarlle do PME','Martín','Pardo','Coordinadora de formac. ´ A Aixola´','2005-06-08','gmartin@cetmar.org','Guadalupe','',NULL,1036,139),
	 ('Envía oferta de emprego','Dika','','Técnica en RR.HH','2006-06-29','ldike@aramark.es','Lorena','',NULL,1041,139),
	 ('O grupo de empresas emprega a máis de 1500 traballadores entre persoal de terra e tripulaciós dos barcos. Teñen factorías en Arxentina, Namibia, Chile e en Vigo (que é a liña de procesado do produto Ricomar). Teñen frigoríficos en Arxentina, Namibia, Chile e en España en Cáceres (Vigoca = planta de elaboración de peixe branco) e en Vigo (Frigoríficos de Rande = centro loxístico para a distribución no mercado europeo). Teñen unha rede de tendas propias La Plaza de Congelados, S.A. (5 tendas: 2 en Vigo e 2 en Extremadura).
Pódese achegar o cv á empresa a través da web no apartado de ofertas de emprego.
Dou a coñecer ao señor Bermúdez o noso servizo e o teré en conta.','Bermúdez','Pérez','Director RR.HH.','2003-03-07','','Antonio','986210034',NULL,1042,93),
	 ('Traballou na antiga Emprex Ett (que xa non existe).','Porto','Nartallo','Técnico selección','2006-07-07','seleccionp@absiderh.com','Manuel','986348228',NULL,613,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Concesionario do Concello de Vigo para o mantenemento do alumeado público e túneles (limpeza electromecánica).
Os postos máis ofertados son de especialistas, peóns e oficiais de electricidade (requiren coñecementos, non necesaria titulación).
Acceso cubrindo ficha de solicitude na empresa ou a través de coñecidos dos traballadores.','Comesaña','','','2006-02-14','rcomesana@imes.es','Ramón','986214373',NULL,664,93),
	 ('Contacto en Franquiatlántico
Agrupa  a Mix (traballo temporal),Hermans Systems (marketing& merchandising), Firdis (limpeza, mantenemento), Profeico Atlántico (Contrata de servizos)','Marzoa','Vázquez','','2006-01-28','','Manuel','630972224',NULL,1038,139),
	 ('Falamos do tema da formac.. Hai problemas de monitores. Traballan con ASIME, Citroen, Ideas posibles, Centro de Mos, de Bamio, de Ribeira, Marín. Posibiliodades dun curso de de soldadura 200 horas e de electrodo de 500 horas. Neste mes de abril notaron unha baixada de traballo no naval.
','','','Director técnico','2003-05-08','','Javier Pérez','',NULL,17,139),
	 ('Ven polo Concello para solicitar persoas para o novo supermercado na zona de Travesas
Recibirán CV ata finais de maio
Perfil ata 35 anos, graduado escolar, valorase ser da zona
Unha vez seleccionadas terán formación e ofrecen contrato inicial indefinido e quendas intensivas de traballo','Gil','','RR.HH','2005-03-08','','Juan Carlos','',NULL,1035,93),
	 ('Sede central en Av. Aragón, 328 Pol. Ind. ´Las Mercedes´-28022 Madrid.
Facilita o contacto co Dtor. de RRHH: José Carlos Muñor.','López','','Directora General','2006-01-10','','Isabel','913290443',NULL,1039,93),
	 ('Actividade: Ocupación da vía pública por mobiliario urbano.
Empresa que pertenece ao grupo de empresas JC DECAUX.
Os postos máis solicitados son: 
- Axente técnico de mantenemento (mantén, fixa e limpa o mobiliario urbano e require carné B)
- Limpeza
Acceso achegando cv a josec.munoz@jcdecaux.es
Teñen horario de 7:00 a 14:00 horas.
Facilita a persoa de contacto e o enderezo en Vigo:
José Mª García (Supervisor Vigo) en Cmno. da feira, 8 baixo nave. Xestoso/Bembrive.
Queda en enviar por correo información da empresa e dos perfis profesionais.','Muñoz','','Dtor. RRHH','2006-01-10','josec.munoz@jcdecaux.es','José Carlos','913290443',NULL,1039,93),
	 ('enderezo: Cmno. da feira, 8 baixo nave. Xestoxo/Bembrive.

Facilita este contacto o Dtor. de RRHH - José Carlos Muñoz.','García','','Supervisor en Vigo','2006-01-10','','José Mª','986374031',NULL,1039,93),
	 ('','Barros','','Rpble. Admón.','2006-01-10','','Julio','986876544',NULL,1040,93),
	 ('Irmán de Victor da Escola Obradoiro Mar de Vigo','Robleda','','','2006-06-20','','Margarita','',NULL,187,139),
	 ('','Molinos','Lentijo','Director Gerente','2005-05-12','comercial@idega.es','Angel R.','986485206',NULL,1043,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Fabricas as bolsas con sus estampacións para o sector comercio. Non precisa empregados e de ser necesario require experiencia específica ou ter que formalos eles.','Rodríguez','Fernández','Administradora Gerente','2003-07-04','','Ana-Rosa','986273113',NULL,1044,93),
	 ('Antonio foi Rpble. de Persoal en Exconsa.
Recolle a nosa información.','Regades','Fernández','Gerente','2004-07-03','','Antonio','670392621 // 986223090',NULL,1046,93),
	 ('Ven polo vestiario do curso de laminador de poliéster','Villanueva','Masenlle','Técnico comercial','2003-08-01','','Francisco','649988845',NULL,1047,139),
	 ('Contacto no Foro de Dinamización da Area metropolitana Vigo-Oporto.
A central está en Vilagarcía. Están asociados a ASEMACO','','','Director xerente','2006-03-30','','Antonio G. Nebot','',NULL,1048,139),
	 ('','','','Xerente','2003-01-07','','Raquel Robledo','',NULL,204,139),
	 ('Envia unha oferta de emprego de FP automoción para Lalín. Oferta que colocase no taboleiro','','','','2006-06-26','','Eva','',NULL,1050,139),
	 ('Envía oferta de emprego. Contestamoslle que non temos candidatos/as dispoñibles.','','','','2006-06-28','','Milagros','',NULL,1051,139),
	 ('','Sempere','','','2006-07-06','vanesasempere@grupoabedul.es','Vanesa','',NULL,1052,139),
	 ('Margarita Robleda informa que o señor Ocampo é o responsable de persoal.','Ocampo','','Dtor. Administración','2006-07-19','','Agustín','',NULL,187,93),
	 ('','','','','2006-07-20','','dsas','',NULL,1053,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Achega a través de ofiemprego unha oferta de Aux. axuda a domicilio e ponme en contacto con Elena (traballadora social)','Fernández','','Gerente','2006-08-03','jf.servidomicilios@yahoo.es','Juan','619539278',NULL,1054,93),
	 ('informa que están constituíndo a empresa e que necesitan ter 2 aux. axuda a domicilio na súa base de datos para empezar a traballar en setembro; indico que traballamos sobre ofertas concretas e que poden achegar cartel informativo para o noso taboleiro.
Informo sobre o SAE e dase cita.','','','Traballadora social','2006-08-03','','Elena','',NULL,1054,93),
	 ('solicito ampliar información sobre a oferta de emprego recibida por e-mail e resposta que son unha multinacional con sede na Alemania, dedicada ás colas industriais, e concreta os datos da oferta.','King','','Jefe de ventas de la zona ibérica','2006-07-27','aida.king@kleiberit.com','Aida','49 724462158',NULL,1055,93),
	 ('Infórmolle que non temos candidatos dispoñibles co perfil de Mecánico Industrial requerido, pero que temos carretilleiros con ampla experiencia e coñecementos de mantenemento básico.','Reboredo','','Director Comercial','2006-07-21','xoan@vascogallega.com','Xoan M.','649292908',NULL,1056,93),
	 ('','Salgueiro','Orihuela','','2006-07-17','codaveiga@hotmail.com','Jesús','667527324',NULL,1057,93),
	 ('','Alvarez','González','','2006-07-17','codaveiga47@hotmail.com','Manuela','627896428',NULL,1057,93),
	 ('','Pérez','','Rpble. Persoal','2006-08-07','ascend@ascendrmm.com','Vanessa','986264996',NULL,612,93),
	 ('fai unha oferta de esteticista para cubrir as vacacións do mes de agosto. Comunícaselle que non temos candidatas neste momento.','','','Propietaria','2006-07-20','','Chara','617785866//986265415',NULL,1059,93),
	 ('Fai oferta de empregada do fogar','Fernández','','Coordinador','2006-08-02','vigo@Bbserveis.com','Vicente','986114938',NULL,415,93),
	 ('','Fernández','','Xerente','2006-08-08','susanaferlo@mundo-r.com','Susana','650957747',NULL,1060,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Pereira','','Técnica selección','2006-08-10','spereira@denbolan.com','Sandra','986447037',NULL,566,93),
	 ('Presenta oferta de emprego de dependente/a para a Casa del libro.','Carrillo','','Técnico RRHH','2006-09-05','acarrillo@espasa.es','Angel','917848334',NULL,1061,93),
	 ('Cristina Merino fai a oferta de emprego e pon a súa xefa como referente.','Monje','','Responsable','2006-09-05','seleccion@griker.es','Nuria','914444929',NULL,1062,93),
	 ('Técnica que fai a oferta de Comercial grandes contas','Merino','','Técnica selección','2006-09-05','seleccion@griker.es','Cristina','914444929',NULL,1062,93),
	 ('Preséntase como a nova técnica de selección e infórmame de que Ingrid xa non está na empresa. Quedo para entrevista para o 19/09/06 para informarlle do noso servizo.','Pérez','Calzado','Técnica de selección','2006-09-18','vigo@denbolan.com','Verónica','986447037',NULL,566,93),
	 ('Solicita información relativa ás axudas á contratación e a xestión de ofertas de emprego. Envío por e-mail modelo de oferta de emprego.
Ten interese en facer 2 ofertas de aux. admvo. para eles e un cliente.','Castroseiros','','Economista','2006-09-22','ecastroseiros@segestion.com','Enma','986430144',NULL,1067,93),
	 ('Solicita fisioterapeuta.','Somoza','Torres','Directora','2006-09-15','apamp@correo.cop.es','Concepción','986294422',NULL,1068,93),
	 ('Contacto feito a través de Alberte.','Alonso','Comesaña','Coordinadora','2006-09-29','makivigo@hotmail.com','Macarena','606627511',NULL,1070,93),
	 ('Patricia antes estaba como técnica de selección en Adecco.
As ofertas de traballo que fai son para Bosch (confidencial).','Davila','','Técnica selección','2006-09-14','vigo@solgest.es','Patricia','986902696',NULL,494,93),
	 ('Oferta de traballo que chega a través do contacto con Ignacio Ojea.','Díaz','Martínez','','2006-09-11','','Antonio','986229472',NULL,1071,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Figura como persoa de contacto na oferta de emprego.','Fernández','','','2006-09-08','','José Carlos','986470507',NULL,1072,93),
	 ('Traballadora ca que contactei para ampliar datos da oferta e da súa empresa.','','','Administrativa','2006-09-08','','María','986470507',NULL,1072,93),
	 ('','Búa','','Rpble. RRHH','2006-09-27','','Pablo','638168158',NULL,262,93),
	 ('Informaselle que neste momento non temos candidatos dispoñibles','','','','2006-08-27','','Juan Carlos','',NULL,1065,139),
	 ('','Ramos','','','2006-08-23','','David','',NULL,1063,139),
	 ('Informaselle que neste momento non temos candidatos dispoñibles para a oferta de responsable de marketing','','','','2006-08-24','','Jose Luis','',NULL,1064,139),
	 ('Fai unha oferta de terapeuta ocupacional, pero non lle valen psicólogos con experiencia en terapia ocupacional xa que teñen un programa no que se esixe  un/unha terapeuta ocupacional','Pérez','','Traballadora social','2006-08-24','','Luz','',NULL,352,139),
	 ('Asesora Rosa,  e  a empresa pasa unha oferta dun analista programador que fará en firme cando a empresa esté constituida.','Rey','','Socio fundador','2006-08-18','','Domingo','',NULL,1073,139),
	 ('','García','Sáez','Consultor','2006-10-03','selección@grupoclave.es','Rosa','981145159',NULL,1074,93),
	 ('Van a abrir delegación en Vigo próximamente. Son fabricantes de alarmas coñecidos polo que quere que o nome da súa empresa ´Guardal´ sexa confidencial e proporciona o nome dunha filial.','González','','','2006-09-21','ea4dwa@gmail.com','Bernardo','649827875',NULL,1075,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Casas','','Asesora pedagóxica','2006-11-09','','Angeles','',NULL,1076,139),
	 ('Temos unha reunión na escola de soldadura de Salvador Comesaña para ver a posibilidade de facer un curso con compromiso de contratación','','','Socio traballador','2006-07-18','','Jesús','',NULL,1077,139),
	 ('No ano 2004 manteño un primer contacto para informarlle do Plan municipal de emprego e das posibilidades de facer cursos.
Volve a contactar en xullo de 2006 e mantemos unha reunión cos responsables de Mondelnort e Renosa para cursos de soldadura con compromiso de contratación.','Comesaña','','Dono','2006-07-18','','Salvador','',NULL,1078,139),
	 ('Seguimento da Ett.','Gabián','','Técnica selección','2003-12-05','vigo@creyfs.es','Ana','986220403',NULL,120,93),
	 ('','Morris','Castro','Xerente','2006-10-25','','Grace','986449213',NULL,1079,139),
	 ('Mantemos unha reunión par facer a prospección de Ett en canto perfís e sectores, forma de acceso...','Castro','','Directora de delegación','2006-10-31','sonia.cvivero@adecco.es','Sonia','',NULL,116,139),
	 ('Mantemos unha reunión para detectar perfís solicitados e sectores cos que traballan, e forma de reclutamento.
Traballan co naval e solicitan soldadores, caldereiros, peóns..., non importa a idade pero teñen que ter experiencia.','','','Comercial-administrador','2006-10-26','','Gonzalo','',NULL,457,139),
	 ('7/11/06: non traballa na empresa','Barreiro','','Técnico de selección','2004-02-17','','Gema','986422477',NULL,124,93),
	 ('','Piñeiro','','Rpble. RRHH/Admón.','2006-11-07','micofer@micofer.com','Rocío','986607046',NULL,124,93),
	 ('Actualizo datos relativos á empresa, ver seguimento correspondente.','Calle','','Directora','2006-11-07','','Montserrat','',NULL,253,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Cortegoso','Follente','Consultora','2006-11-08','','Paula','986473456',NULL,129,139),
	 ('é filla do dono e facilita os datos que figuran no seguimento','Mañas','','','2006-11-03','pma@aemos.es','Arancha','',NULL,1080,93),
	 ('Presidente da Asociación de empresarios de Mos.','Mañas','Gómez','Xerente','2006-11-03','','José','986288120',NULL,1080,93),
	 ('','Giráldez','','Director','2004-02-05','guillermo.giraldez@manpower.es','Guillermo','986294612',NULL,123,93),
	 ('','Hernández','','','2006-11-13','ruben@vitaesalud.com','Rubén','615157868',NULL,1081,93),
	 ('O contacto con esta empresa faise por unha entrevista na Feira de Conxemar con José Estors Carballo (departamento de exportación). Nesta empresa, en fábrica só traballan homes e en administración mulleres. 
En fábrica só requiren boa actitude e ganas de traballar, di que non traballan mulleres porque é un traballo físico de carga de sacos. Marta é moi receptiva e está pola labor de incorporar mulleres pero di que non teñen vestiarios e o encargado é reacio a este tema, polo que coméntolle da posibilidade de poñerse en contacto co proxecto Conta con Elas.

O horario é en fábrica:  Quendas M (6:00 a 14:00), T (14:00 a 10:00) e  N ( 22:00 a 6:00).
Administrac. xornada partida ou enteira dependendo da necesidades das persoas.

','Díaz','Almeida','Responsable de administrac. e RR.HH','2006-11-08','','Marta','',NULL,1082,139),
	 ('Información sobre unha formación teórico-práctica de 2 semanas que comenzan o día 20 de novembro, logo teñen unha beca de 850 euros cando comenzen a traballar ademais da comisión das ventas.
O perfil que solicitan é persoas ata 40 anos cun nivel de formación a nivel bacharelato e vehículo propio.','','','Asesora/Director','2006-11-10','','Duvi Gándara/Jose Manuel Santos','',NULL,89,139),
	 ('Esta oferta é a través de Victor da EO Mar de Vigo','Barciela','','','2006-10-09','','Chicho','',NULL,601,139),
	 ('Fai unha oferta de emprego só por catro días. Falamos varias veces para concretar a oferta.','','','','2006-11-09','','Román','',NULL,1069,139),
	 ('entrevista mantida para actualizar datos relativos a súa actividade que figuran nas correspondentes listaxes e sintetizada no seguimento.','Lemos','Domínguez','Técnico de selección','2006-11-15','vig1004@altagestion.es','Teresa','986434988',NULL,118,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Entrevista persoal para actualización de datos mantida nesta data.','Díaz','','Técnica de selección','2006-11-17','','Cristina','986493131',NULL,126,93),
	 ('Información facilitada por Cristina Díaz','Liste','','Directora oficina','2006-11-21','','Sofía','986493131',NULL,126,93),
	 ('Recollida de información sobre perfís e sectores cos que traballan. Automoción, conxelados, conserveiro','Portela','','Becaria Feuga','2006-11-20','','Paula','non está na empresa',NULL,114,139),
	 ('Entrevista persoal para prospección e actualización de datos.
Dámola de baixa ao cambiar a empresa de denominación: ´Startpeople´ e faise o seguimento baixo a nova denominación.','Gabián','','Gestor de cuentas','2006-11-10','','Ana','',NULL,120,93),
	 ('','García','','Técnica de selcción','2006-11-16','','Chus','',NULL,131,139),
	 ('Entrevista persoal mantida para a actualización de datos.','Gabián','','Gestor de cuentas (selección)','2006-11-10','','Ana','986220403',NULL,1083,93),
	 ('Na entrevista persoal mantida para actualizar os datos do grupo informa que LinK pasou a denominarse Manpower Bussines Solutions e é a consultora do grupo Manpower.','Giraldez','','Gestor Grandes Cuentas','2006-11-17','','Guillermo','986294612',NULL,619,93),
	 ('entrevista persoal mantida para actualizar datos da empresa.','Giráldez','','Gestor Grandes Cuentas','2006-11-17','guillermo.giraldez@manpower.es','Guillermo','',NULL,123,93),
	 ('Fai unha oferta de emprego de asesor pedagóxico para centro comercial Eroski en Ponteareas (1 mes) . Non hai candidatos dispoñibles para esta oferta polo que pasamoslle a oferta a Alberto do Plan experimental de Porriño.','Cabo','','','2006-11-22','','Susana','',NULL,1084,139),
	 ('','Rodríguez','López','Técnica selección','2006-11-27','eva.rodriguez@adecco.es','Eva','637764255',NULL,116,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('No seguimento correspondente figuran os datos máis significativos da entrevista mantida.','Serantes','','Técnico de selección','2006-12-01','seleccionvigo@eulen.com','Chema','986493081',NULL,72,93),
	 ('entrevista persoal. No seguimento correspondente reflíctese os datos máis significativos.','Marzoa','Vázquez','Director General','2006-11-30','m.marzoa@grupobase.com','Manuel','902400171',NULL,125,93),
	 ('entrevista persoal. No seguimento correspondente reflíctese os datos máis significativos.','Sousa','Lemos','Directora Recursos Humanos','2006-11-30','direccionpersonal@grupobase.com','Begoña','690841723',NULL,125,93),
	 ('Mantida entrevista persoal, no seguimento correspondente reflíctense os datos máis significativos.','Alvarez','Miguez','Consultora (Delegada oficina)','2006-11-22','','Beatríz','986432980',NULL,130,93),
	 ('Mantida entrevista persoal, no seguimento correspondente reflíctense os datos máis significativos.','García','Cernadas','Consultora','2006-11-22','','Lucía','986432980',NULL,130,93),
	 ('Mantida entrevista persoal para prospección e actualización de datos. Información no seguimento correspondente.','Fernández','Goce','Delegada de oficina','2006-11-10','manager_vigo@randstad.es','Emilia','986223317',NULL,128,93),
	 ('Pregunta sobre a selección do Obradoiro de Emprego','','','Traballadora social','2006-11-30','','Lara','',NULL,517,139),
	 ('','Rodríguez','','Técnica de selección','2006-11-28','','Sonia','',NULL,136,139),
	 ('','Domínguez','','Consultora','2006-12-12','mdominguez@azetanet.com','Marta','902922822',NULL,1085,93),
	 ('Oferta de emprego de enxeñeiro técnico industrial','','','','2006-11-30','','Arán Feijo Covelo','',NULL,463,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Presenta, a través de Ignacio Ojea, oferta de emprego.','Neira','Lamas','Socio-consultor','2006-12-20','aneira@eosaconsultores.com','Adolfo','986419922',NULL,1086,93),
	 ('Especifícase na oferta como tutor no posto de becario/a ofertado para Santiago.','De la Cruz','De la Rosa','Socio-director','2006-12-20','','Antonio','',NULL,1086,93),
	 ('manteño entrevista telefónica de prospección. Ver seguimento correspondente.','','','Rpble. Persoal','2006-12-21','','Ana','986480077',NULL,1087,93),
	 ('','','','','2006-11-28','','Esther','',NULL,1088,139),
	 ('Incorpora unha nova actividade a súa empresa relativa a tintorería','López','Mosquera','Dono','2007-01-10','flopezmosquera@yahoo.es','Fran','615644024',NULL,632,93),
	 ('','Costas','','','2007-01-17','administracion@la-moa.com','Eva','986393016',NULL,174,93),
	 ('Paula deixou a empresa e Miguel é o novo contacto.','Misa','','Técnico selección','2007-01-18','info@siottemp.com','Miguel A.','',NULL,114,93),
	 ('Entrevista telefónica para prospección e actualización de datos.','Rodríguez','Alonso','Asesora comercial','2007-01-18','cenpla36@cenpla.es','Dolores','986238449',NULL,119,93),
	 ('Contacto establecido a través de José Manuel Davila (Actívate), ver seguimento correspondente.','Añón','Gómez','Director Gerente','2007-01-22','','Manuel','986374611 al 14',NULL,532,93),
	 ('Neste momento non hai director/a na residencia.
Reunión Ana (está na subdirección), Jose Manuel e Chelo. Presentación do proxecto Actívate co obxectivo de acadar prácticas no itinerario de auxiliar de axuda a domicilio  e de lavandería e presentación do Plan Municipal de Emprego 2004-2007 (cursos con compromiso de contratación e axudas á contratación). O persoal traballador desta residencia é auxiliar de clínica e agora van a ter persoas en prácticas do ciclo de Atención Sociosanitaria.
Neste momento hai unhas 130 persoas aloxadas con previsión de ampliar as prazas.
Moi receptiva, móstranos as instalacións (oratorio, aula de formacion, aula de psicomotricidade, perruquería, aula de psicomotricidade, aula de actividades que leva unha educadora social,enfermería...','Fieira','','Psicóloga','2007-01-24','','Ana','986265732',NULL,1089,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Esposo de Carmen','','','Dono','2007-01-20','alberto@deorigen.com','Alberto','',NULL,301,93),
	 ('','Fernández','','','2007-01-22','nelfg@vodafone.es','Manuel','687760605',NULL,525,93),
	 ('mantivemos entrevista para ampliar información relativa a súa oferta de comerciais que poñemos no taboleiro.','López','Guimarey','Asesor de clientes','2007-01-18','jorgelo@mapfre.com','Jorge','986371853',NULL,89,93),
	 ('Oferta de emprego de axudante de cociña','','','','2007-01-02','','Sana','',NULL,1090,139),
	 ('Oferta de emprego','Gómez','','','2007-01-25','','Enrique','',NULL,1093,139),
	 ('Dono da empresa','Fernández','Sesto','Gerente','2007-01-26','','Fernando','607584818',NULL,1092,93),
	 ('Concerto entrevista para o día 6 de febreiro de 2007.','Feijudo?','','Directora','2007-01-31','','Mª Jesús','986438972',NULL,369,93),
	 ('Ver seguimento correspondente da visita de prospección mantida.','','','Madre Superiora','2007-02-05','','Madre Teófila','',NULL,376,93),
	 ('Tres centros:
Alondra Mos Vivenda (12 prazas)+ Centro de día (25 prazas). Cheque asistencial
Alondra Mos II (Peinador) Vivenda
A Casiña (Petelos) Vivenda.
Postos de traballo: director, animadores socioculturais, aux. de enfermería- xeriatría e médico, enfermeira e fisioterapeuta (estos tres últimos para os tres centros)
Coménta que estarían interesados nas axudas a contratación e en ter xente para facer prácticas. Teñen pensado contratar persoas  de axuda a domicilio
Infórmolle do proxecto Actívate e dos proxectos de outros anos e pásolle o contacto  a Jose Manuel (Actívate)
Asociación de 3ª idade a nivel autonómico recien constituida. O presidente é Pablo Muñiz da Residencia La Palmera, poñeremonos en contacto mais adiante.','Escudero','','Director e accionista','2007-02-09','','Miguel Angel','',NULL,1094,139),
	 ('','','','','2007-02-08','','Montse','',NULL,1095,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','','','Xerente','2007-02-14','','Mónica Vázquez','',NULL,387,139),
	 ('Entrevista de prospección, ver o seguimento correspondente.','','','Socio','2007-02-15','','Francisco','986470936',NULL,203,93),
	 ('Informo do anuncio da formación con compromiso de contratación e envíolle o texto do anuncio por e-mail.','Búa','','Rpble. RRHH','2007-02-20','pablobua2002@yahoo.es','Pablo','',NULL,262,93),
	 ('Ver seguimento','Alonso','','Dona','2007-02-16','','Encarna','',NULL,655,139),
	 ('ya me puedo borrar
','','','','2007-02-22','','elisa','',NULL,1025,139),
	 ('','','','Directora de RR.HH','2007-02-26','luciadelcampo@geriatros.com','Lucía del Campo','986227103',NULL,345,139),
	 ('','García','','Dono','2007-02-28','','Miguel','',NULL,1098,139),
	 ('E unha empresa de asistencia domiciliaria sanitaria (limpeza e aseo persoal , movilidade, medicación, acompañamento...)e doméstica ( colada, plancha, cociña, limpeza por horas...), servicios a empresas (garderías, trasnportes puntuales, recados...) asistencia domiciliaria social (canguro, profesores a domicilio, asistencia informática a domicilio...), servizo clínicas hospitais (contratación de persoal externo para clínicas, xeriátricos, hospitais, saidas culturais...)','Alvarez','Carneiro','Directora','2007-02-28','','Mª José','',NULL,1099,139),
	 ('Figura como representante da fundación na solicitude de axuda á contratación 2006','Moreno','Diéguez','Representante legal','2006-09-29','','Luis Eulogio','',NULL,1100,93),
	 ('Persoa de contacto para a xestión da axuda á contratación.','Yanes','','Dpto. RRHH','2006-09-07','','Sonia','',NULL,1100,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Remedios é a Directora Xeral de Ideas Posibles e recíbeme nesta empresa porque a sede da asociación é un despacho arrendado dun centro de negocios.','Loureiro','','Presidenta','2006-10-31','','Remedios','',NULL,1101,93),
	 ('','','','Administrativa','2007-03-05','','Milagros','',NULL,1049,93),
	 ('','Tasende','Rojo','Xerenta','2007-03-05','','Mercedes','619124637',NULL,1049,93),
	 ('Oferta de emprego de becario informática','','','','2007-03-02','ferroplast@mp.maier.es','Belén Obelleiro','',NULL,16,139),
	 ('Presentación de solicitude cursos compromiso contratación Condutor/a de carretillas elevadoras','Vázquez','Fernández','','2007-03-09','','Sandra','',NULL,1102,93),
	 ('A entrevista a teño en Simón Bolivar, 12 entrechán, xa que esta é a empresa de multiservicios de Solgest, o teléfono tamén é de Solgest. Falamos da posibilidade dun curso con compromiso de contratación de carretilleros/as . Traballan con Maderas Iglesias, Antolín, Vulcano e Barreras (nesta empresa levan o almacén como servizo externo, o persoal aquí na maioría de casos é indefinido).','Vázquez','Fernández','Xestora de selección','2007-03-05','','Sandra','',NULL,1102,139),
	 ('Fai unha oferta de emprego de tecedor','','','','2007-03-26','','Cristina López','',NULL,1103,139),
	 ('Fai unha oferta de emprego de condutora de reparto','','','','2007-03-26','','Michael','',NULL,1104,139),
	 ('','Moure','','Directora (propietaria)','2007-03-01','info@alzdem.com','Marien','986485543',NULL,353,93),
	 ('','Rodal','','Gerente - Propietaria','2006-09-28','','Isabel','986290080 (particular)',NULL,1105,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Posibilidade dun curso de formación con compromiso','Castro','','','2007-01-07','','Susana','',NULL,98,139),
	 ('A oferta de traballo pásase a Susana BIAL','','','','2007-03-25','','Oscar','',NULL,1106,139),
	 ('','Buceta','Santana','Propietario','2012-11-07','alberto@aevigo.es','Alberto','','639826694',1211,93),
	 ('Fai unha oferta de emprego  por correo electrónico, intentamos falar con él e envío correo electrónico pero non conseguimos falar con él','','','','2007-04-03','','Antonio','',NULL,1107,139),
	 ('Fai unha oferta de fontaneiro. Informamoslle dos institutos onde existe o ciclo de construción e tamén que se dirixa á Fundación Laboral da Construción','Saborido','','Administradora','2007-04-11','','Mercedes','',NULL,1108,139),
	 ('','De Cal','Zapata','Directora','2007-04-18','','Silvia','699454079',NULL,1109,139),
	 ('Fai unha oferta de odontólogo. Comunicamoslle que non temos candidatos/as ao que nos envía e-mail comunicando que a oferta está aberta ao longo do ano.','','','','2007-04-18','','Gonzalo','',NULL,1110,139),
	 ('Oferta de emprego de enxeñeiro técnico naval','Fernández','','RR. HH','2007-04-19','','Jaime','',NULL,225,139),
	 ('Solicitude de orzamento para formación en limpeza de ACTÍVATE','González','Manzano','Responsable de Prevención, Calidad e M. Ambiente','2006-03-20','araceli@linorsa.es  linorsa@linorsa.es','Araceli','606 952 153',NULL,262,139),
	 ('Oferta de monitor/a de tempo libre','','','','2007-05-24','','Yolanda Pereira/Angeles','',NULL,1112,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Establecemos contacto para a posible realización de prácticas de ACTIVATE (Lavandería) na súa empresa SERVIMGAL','Blanco','','Responsable de Operaciones','2007-02-07','elena.blanco@grupomaconsi.com','Elena','986211534//647395520',NULL,248,139),
	 ('Establecemos contacto para solicitar prácticas de LAVANDERÍA para ACTÍVATE.','Domínguez','Arias','Subdirectora de D+I+i+C','2007-01-16','begoña.dominguez.arias@sergas.es','Begoña','986816000 ext 16137',NULL,384,139),
	 ('Realizamos contacto para determinar a posibilidade de realizar prácticas de Teleoperador/a ACTIVATE','Ferreira','Vázquez','Responsable RRHH','2006-10-31','','Manuel R.','986 900 111',NULL,1113,139),
	 ('Sondeamos a posibilidade de realizar prácticas como acompañantes de transporte adaptado para o itinerario de condutor/a de ACTÍVATE.','Pérez','Santiago','Responsable Local','2007-01-31','jcarlos@cruzroja.es','Juan Carlos','986 423666',NULL,540,139),
	 ('Xunto coa negociación de prácticas para transporte adaptado, negociamos o acordo para a realización de practicas do grupo de AAD-Actívate.','','','Responsable SAD','2007-01-31','','Maribel','986 423666',NULL,375,139),
	 ('Contactamos a traves de Euroresidencis coa empresa de Catering que leva a súa cociña. Propoñemos prácticas para Axudante de cociña en centros escolares e sociosanitarios-ACTÍVATE','Casal','','Responsable da Cociña de Euroresidencias','2006-11-24','bcasal@aramark.es','Belen','618 707 257',NULL,1041,139),
	 ('Visitamos para establecer a posibilidade de realizar prácticas ACTIVATE nos itinerarios de ´cociña´ e ´AAD´','Pascual','','Directora','2006-10-17','','Nuria','986240336 // 986240363',NULL,367,139),
	 ('Contacto para establecer a posibilidade de realizar prácticas de Axudantes de cociña en centros escolares e sociosanitarios de ACTÍVATE, no CEE Menela de Alcabre.','Giménez','Casas','Director Xeral','2006-10-04','','Cipriano Luis','986423433// 609817807',NULL,374,122),
	 ('Ao dispoñer de cociña e persoal propio, solicítase a posibilidade de realizar prácticas dO itinerario de axudante de cociña en centro escolares e sociosanitarios de ACTÍVATE.','Pascual','Baladrón','Directora','2006-10-02','cmariaadmon@terra.es','María del Carmen','',NULL,1114,139),
	 ('Visita para establecer a posibilidade de realizar prácticas de axudante de cociña en centros escolares e sociosanitarios de ACTÍVATE.','Toyos','Pérez','Directora','2006-10-02','divinosalvador@telefonica.net','Lydia','986490320',NULL,1115,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Contactamos para a posible realización de practicas de axudante de cociña en centros escolares e sociosanitarios de ACTIVATE. Derívanos a empresa Torres de Agrelo do mesmo grupo, que realiza o serviciode catering no colexio.','Armiño','','Subdirector','2006-10-05','','Miguel','',NULL,1116,139),
	 ('Derívanos o Colexio Marcote como empresa do Grupo que lle leva a cociña e o comedor. Negociamos a posibilidade de prácticas para  Ax. de cociña de ACTÍVATE','Marcote','Núñez','Xerente','2006-11-03','','Pablo','986408021',NULL,1117,139),
	 ('','Gándara','Vieitez','','2007-05-28','','Sonia','',NULL,1118,139),
	 ('','Del Olmo','','Xerente','2007-05-02','','Rubén','',NULL,1111,139),
	 ('','','','','2007-06-04','','Mónica Campos/Sonia','',NULL,1119,139),
	 ('','Rodríguez','','RRHH','2007-06-04','roberto.rodriguez@grupominor.com','Roberto','986343434',NULL,249,93),
	 ('Oferta de xardineiro','','','Consultor RR.HH','2007-05-16','','Eduardo','',NULL,128,139),
	 ('','González','','Producción','2007-06-04','gesinco.es@telefonica.net','Amelia','918559245',NULL,462,93),
	 ('Realizamos contacto para determinar a posibilidade de realizar prácticas de Ax. de cociña..., condutor...., e Aux. de axuda a domicilio de ACTIVATE, en calquera dos dous centros de que dispón na cidade (Residencia e Centro de Día).','Añón','Gómez','Director Xerente','2006-10-17','doralresidencias@doralta.com','Manuel','9986374611',NULL,1121,139),
	 ('Realizamos contacto para determinar a posibilidade de realizar prácticas de axuda a domicilio de ACTIVATE','Barros','Rios','Director','2007-02-23','lbarros@euroresidencias.es','Luis','986485610',NULL,372,139);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Realizamos contacto para determinar a posibilidade de realizar prácticas de axuada adomicilio de ACTIVATE','Álvarez','Pereira','Directora','2007-03-19','','Angeles','986242706',NULL,380,139),
	 ('Contáctase para establecer a posibilidade de realizar prácticas de auxiliar de axuda a domicilio de ACTIVATE.','Gutierrez','','Responsable de formación','2007-02-09','','Mariano','986374141',NULL,383,139),
	 ('Contacta ACTIVATE, para determinar a posibilidade de realizar practicas do itinerario de condutor...., nos vehículos que dispoñen para persoas de mobilidade reducida.','Pérez','Bravo','Jefe Dpto RR.HH.','2007-01-11','fjpbravo@vitrasa.es','Francisco Javier','986291600',NULL,1122,139),
	 ('','Callejo','García','Xerente','2007-06-11','','J. Carlos','619925010',NULL,662,93),
	 ('','Caro','Perdigón','Jefe oficina técnica','2007-06-04','pedrocaroperdigon@gmail.com','Pedro','660983232',NULL,1123,93),
	 ('Informa que Luis Méndez xa non traballa na empresa.','Negro','','Contable','2007-06-13','makropool7@hotmail.com','Marga','986294711',NULL,80,93),
	 ('','Castro','Carrera','','2007-06-12','antademoura@antademoura.com','Juan Carlos','654504865',NULL,196,93),
	 ('Selecciona as persoas para o curso de Caixeira','Bregua','','Técnica de RR.HH','2007-06-04','nbregua@vegalsa.es','Nuria','981179360/618094267',NULL,98,139),
	 ('','','','Consultora RR.HH','2007-06-13','','Charo Redomero','',NULL,588,139),
	 ('','Rodríguez','López','Técnica de selección','2007-07-27','','Eva','637764255',NULL,1132,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Novo','','Xerente','2007-07-27','','Rogelio','625813054',NULL,1135,93),
	 ('','Villalobos','De Santos','Dpto. Admón y RRHH','2007-07-27','lorenavillalobos@superalia.es','Lorena','615366516',NULL,1136,93),
	 ('Ven por aquí. E unha empresa con base en Santiago onde traballa con organismos oficiais (Xunta, Universidade...). En Vigo é unha aposta de funcionamento pretenden o mesmo que están facendo en Santiago. Quería ter unha base de azafatas (ata 35 anos) para poder dispoñer de persoas ante un evento. Explícolle como traballamos dende o SOL. Se ten unha oferta concreta envíaranos a solicitude. E enviaranos un cartel para poñer no taboleiro','','','Directora','2007-06-14','','Eugenia Fdez Rebollido','',NULL,1124,139),
	 ('','López','','Desarrollo, Innovación','2007-06-13','esteban@uvigo.es','Esteban','678810181',NULL,1125,93),
	 ('Contacto feito a través de Adela (ASIME).
María Castro pertence á Comisión de seguimento da ABE, e informa do seguinte: inicia a súa actividade o 19/3/07; xurde a partir da disposición adicional 5ª do convenio colectivo do metal que conleva a creación dunha bolda de emprego co acordo entre Asime e Instalectra xunto con CCC.OO, CIG e UXT.
Os traballadores eventuales, con experiencia laboral no sector metal e industrias auxiliares do sector naval que traballaran en asteleiro, terán que inscribirse e cubrir unha ficha de demanda.','Castro','','Comisión seguimiento (ASIME)','2007-03-15','','María','',NULL,1126,93),
	 ('Oferta desde a zona de Castilla- León','','','Responsable de RR.HH','2007-05-28','mi.puente@grupoelarbol.com','Isabel Puente','',NULL,1127,139),
	 ('Fai unha oferta para solicitar asesores financeiros. Falara con él unhos días antes e comentarame xa a oferta, explicaralle como funciona o servizo e que que si quería enviara un cartel para poñer no taboleiro.','','','','2007-05-24','antonio.tadeu@aviva.es','Antonio','',NULL,506,139),
	 ('','','','','2007-06-06','','María Fernández','',NULL,1128,139),
	 ('','Gutierrez','','Directora Delegación','2007-07-04','ggutierrez@solgest.es','Greta','986902696',NULL,494,93),
	 ('Presenta oferta de Técnico/a Dpto. de Compras.','Fernández','Arrabal','Rpble. RR.HH','2007-07-01','rrhh@gonsusa.es','Jaime','986494177',NULL,225,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Barros','','Orientador SGC','2007-06-21','laboral@feprohos.org','Daniel','986432400',NULL,36,93),
	 ('','Gosende','','Técnica selección','2007-07-17','monica.gosende.estratexias@gmail.com','Mónica','981519888',NULL,1129,93),
	 ('','Novegil','Blanco','Xerente','2007-07-17','victornovegil@hotmail.com','Víctor','680660676',NULL,1130,93),
	 ('','Carpintero','','Consultor comercial','2007-07-16','','Marisa','986493131',NULL,126,93),
	 ('','Fernández','','Traballadora social','2007-07-24','','Alejandra','986224468',NULL,1131,93),
	 ('','García','','Encargada xestión','2007-07-24','','Almudena','986224468',NULL,1131,93),
	 ('','','','','2007-07-24','trabajosocial@grupoabedul.es','Mónica','',NULL,1052,93),
	 ('','','','','2007-07-20','','María','972751630',NULL,1133,93),
	 ('oferta de emprego e contacto derivado a través de José Manuel Davila (Actívate)','Martínez','de Arellano','Dpto. Dirección','2007-07-24','gerencia@elmolinovigo.com','Bárbara','986480077',NULL,1134,93),
	 ('Falo co Sr. Cuiña para ofrecerlle información sobre a posibilidade de realizar prácticas de transporte escolar. Envíolle a información por correo electrónico e me cotesta dicindo que reenviou dita información a tódolos asociados.','Cuiña','','','2006-11-15','','Miguel','',NULL,1137,127);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Contacta ACTÍVATE coa intención de determinar a posibilidade de facer prácticas da especialidade de teleoperador.','Alonso','Fernández','Administrador','2006-11-13','','Manuel','986467090',NULL,1138,139),
	 ('','Alvarez','','Copropietario','2006-11-29','','Roberto','986377026',NULL,1139,127),
	 ('ACTIVATE sondea a posibilidade de facer prácticas de transporte adaptado (CONDUTORA) e de auxiliar de axuda a domicilio.','','','Traballadora Social','2007-01-16','apamp_direccion@mundo-r.com','Patricia','986294422',NULL,373,139),
	 ('','López','','','2006-11-16','slopez@monbus.es','Sandra','600966671',NULL,1140,127),
	 ('','Estévez','','Gerente','2006-11-16','','Perfecto','986471789',NULL,1141,127),
	 ('Sondeamos a posibilidade de facer prácticas de auxiliar de axuda a domicilio de ACTÍVATE.','Macías','','Directora','2007-04-26','','Beatriz','986208395',NULL,357,139),
	 ('Ponse en contacto conmigo tras recibir información de TRAVIBUS sobre as prácticas de Transporte Escolar. Non chegamos a colaborar por dar prioridade ás empresas de Vigo.','','','Gerente','2006-11-23','','Jorge','',NULL,1142,127),
	 ('Sondeamos a posibilidade de realizar practicas de Auxiliar de axuda a domicilio de ACTIVATE','','','Director','2007-04-17','','Gonzalo','986229069',NULL,1143,139),
	 ('','Salmerón','','Rpble. Selección','2007-07-19','luisi@grupomenmon.com','Luisi','',NULL,569,93),
	 ('Contacta para solicitar axuda á contratación de Maho Koma por 6 meses.','Blanco','','','2007-08-08','','Ana','986480077',NULL,1134,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Caro','Perdigón','Responsable técnico','2007-07-30','pedrocaroperdigon@gmail.com','Pedro','660983232',NULL,1144,93),
	 ('Oferta de emprego achegada por Fran (Empece).','Teixeira','Alvarez','Gerente','2007-07-31','','Venancio','691785825',NULL,1145,93),
	 ('','Barco','','RRHH','2007-08-09','','Jose Manuel','986288191',NULL,1146,139),
	 ('','Nieto','','','2007-08-02','mcarmen.nieto@adecco.com','Mª Carmen (Maica)','',NULL,116,93),
	 ('','Balwin','','Xerente','2007-08-14','','Hermes','',NULL,1147,139),
	 ('María é técnica local de emprego en Mos e precisa empregada do fogar, fixo a oferta a través da web.','Torea','Priegue','Domicilio particular','2007-08-02','mtorea@mundo-r.com','María','',NULL,1148,93),
	 ('','Blanco','','Xerente','2007-08-23','galaureasl@mundo-r.com','Marta Blanco','690934419',NULL,1149,122),
	 ('Informa do resultado da seleccion dunha limpadora, oferta que foi xestionada por Maika e Xandra. Informo das axudas á contratación.','Fanjul','','Selección','2010-02-02','cristina.fanjul@fuertesservicios.com','Cristina','986266531',NULL,1151,93),
	 ('','Pérez','','Rpble. Dpto. RRHH','2010-03-30','','Silvia','',NULL,1152,93),
	 ('','Freire','Gestoso','Cofrade Maior','2007-10-02','','Paulino','',NULL,1163,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Gómez','','','2007-10-10','info@nexo-global.com','Isabel','',NULL,1164,93),
	 ('','Quintela','','Asesora','2010-05-12','','Elida','616406029',NULL,1177,93),
	 ('','Garrote','Covelo','Direcc. Relacs. Sociales y Humanas – Contratación y Empleo','2008-10-03','antoniomanuel.garrote@mpsa.com','Antonio','986215421',NULL,137,93),
	 ('Contacto establecido a partir de proposta formativa plantexada ao Xefe do servizo.','Concheiro','','Project Manager','2010-05-20','iconcheiro@trainingchannel.es','Ignacio','902104647 (ext. 205)',NULL,1178,93),
	 ('Ocúpase da proposta e deseño da formación.Queda en formularnos proxectos formativos en base a convocatorias con fondos europeos.','Rodríguez','','Dtor. Operaciones','2010-05-20','','Javier','902104647 (ext.204)',NULL,1178,93),
	 ('','Núñez','','Responsable RRHH','2012-03-07','angel.nunez@plasticomnium.com','Angel','986408054',NULL,10,93),
	 ('Establece contacto para facer unha oferta de emprego de dependenta e infórmaselle das axudas á contratación.

Acaban contratando a unha candidata súa.','Maquieira','','Administrativa','2010-06-29','eva.pineiro.sport@gmail.com','Eva','986530005 - ext. 10',NULL,1179,93),
	 ('','','','','2010-08-09','','Susana','',NULL,1180,148),
	 ('Persoa que realiza a oferta','','','','2010-08-10','','Ramón','',NULL,1181,148),
	 ('','','','Dpto. laboral','2010-08-18','asesoriag5@asesoriag5.com','Ramón','',NULL,1182,148);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','González','Costas','','2010-08-20','','Charo','',NULL,1183,148),
	 ('','Hernández','','Gerente','2010-10-21','','Estefanía','986122155',NULL,1185,148),
	 ('','Martínez','','Director Vigo','2012-02-22','mio.dir@kiabi.com','Guillermo','986406516',NULL,1186,93),
	 ('E a persoa que inicia o contacto co concello.','Robles','','Directora Oleiros','2012-02-22','moe.dir@kiabi.com','Beatriz','981619340',NULL,1186,93),
	 ('','Gil','','Rpble. RRHH','2012-02-29','selepont@mercadona.es','Juan Carlos','660985865',NULL,1035,93),
	 ('É a interlocutora de RRHH con nos.','Sánchez','','Técnica RRHH','2012-03-06','alicia.sanchez@grupoantolin.com','Alicia','986823800',NULL,1009,93),
	 ('Ata despois do verano seguro que non contratan a ninguén e despois ten dúbida. Solicita que lle achegue modelo de oferta de emprego e información por email.','Casal','Núñez','Director RRHH','2012-03-06','carlos.casal@benteler.es','Carlos','986268800',NULL,1006,93),
	 ('Centro Especial de Emprego.','Guinaldo','','Técnica de la unidad de apoyo','2012-03-23','unidadapoyo@fuertesservicios.com','Isabel','647564917',NULL,1188,93),
	 ('','Martínez','','Delegado','2012-03-15','xmartinez@imesapi.es','Xosé Manuel','619247064',NULL,1014,93),
	 ('ILE (Tramitada por Mónica López Coronado)','Durán','','Gerente','2012-02-21','electrohipy@gmail.com','Marco','672230545',NULL,1189,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Mantuvimos entrevista persoal na que informa da súa actividade e dos perfis requiridos. Quedamos en publicar a súa oferta no noso taboleiro.','Rodríguez','','Consultor Banca Personal Supervisor','2012-02-21','drodriguez@bancomediolanum.es','Davinia','692628484',NULL,1190,93),
	 ('','Barreiro','','Consultora','2012-02-21','porrino_unidad_1@randstad.es','Ana Mª','986331656',NULL,1191,93),
	 ('','López','','Administración','2012-02-13','vlopez@yntegraservicios.es','Virginia','916580007',NULL,1192,93),
	 ('','Caamaño','','Consultora','2012-02-10','cv@gesconsultores.com','Catuxa','981122625',NULL,1193,93),
	 ('','Soler','','','2012-04-09','','Rafael','965495676 - ext.55715',NULL,1194,93),
	 ('','Pardo','','Técnica Selección','2012-04-10','seleccion@hogarlin.es','Beatriz','986213905',NULL,233,93),
	 ('','Haz','','Becaria','2012-04-17','victoria.haz@grupoantolin.com','Victoria','986829704',NULL,1195,93),
	 ('Por apertura de oficina achega oferta aberta solicitando Asesor comercial.','López','López','','2012-04-02','rlopez@almudenaseguros.es','Raquel','699549704',NULL,1196,93),
	 ('','Guisande','Pereira','Responsable selección','2012-04-19','seleccion.vigo@ader.net','Lucía','986439571',NULL,117,93),
	 ('','Ferreño','López','Consultora','2012-04-27','sferreno@azetanet.com','Silvia','981277222',NULL,1085,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Treus','','Técnico selección','2012-04-19','seleccionvigo@grupoalliance.com','Guillermo','986443041',NULL,489,93),
	 ('','Fernández','','Ingeniero Técnico','2012-05-14','dfernandez@inelsazener.com','David','618350740',NULL,1197,93),
	 ('','Gutiérrez','','Administración','2012-05-14','esther.gutierrez@cmpg.es','Esther','986228124',NULL,1198,93),
	 ('','Martín','Osuna','Rpble. de Selección de Personal','2012-05-21','rociomartinosuna@azafatasankara.com','Rocío','915632296',NULL,1199,93),
	 ('Contacto inicial realizado desde Barcelona, aínda que o referente sexa a oficina de A Coruña.































































































































































































































































































































































































  














','Herrera','','Técnico Selección','2012-05-23','seleccion.cmp2@expertus.es','Alicia','932173530',NULL,1200,93),
	 ('','Montes','','Dpto. Selección','2012-05-23','mtmontes@legariaett.com','Maite','981247344',NULL,1201,93),
	 ('Persoa que establece o contacto telefónico inicial e indica que dirixamos as candidaturas a Irene Tornero.','Machín','Pérez','Administración','2012-05-30','emachin@fuerzacomercial.es','Emilio','672202550',NULL,1202,93),
	 ('','Tornero','','Consultora','2012-05-30','itornero@fuerzacomercial.es','Irene','663389293',NULL,1202,93),
	 ('','González','','Técnico','2012-06-12','agonzalez@idearainvestigacion.com','Abraham','986225844',NULL,1203,93),
	 ('','Bustelo','','Xerente','2012-06-12','','Arturo','986225844',NULL,1203,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Ares','','Xerente zona','2012-07-09','mcagonzalez@certitec.eu','Maika','',NULL,1204,93),
	 ('','Márquez','','Xerente','2012-09-10','rrhh@solucionesgallegas.com','Juan Luis','605789960',NULL,1205,93),
	 ('','Martín','','Administrativa','2012-10-01','yolanda@crambo.es','Yolanda','916487283',NULL,1206,93),
	 ('','Barros','Ríos','Director Comercial','2012-10-03','oficina@atendo.es','Luis','986412341',NULL,203,93),
	 ('Solicita despacho para facer entrevistas de selección para un posto de comercial (fixeron a selección a través do Inem e ofrecen contrato indefinido, fixo+incentivos, vehículo empresa e dietas). Facilítanse datos de contacto neste sentido e infórmase da actividade da nosa concellería en materia de emprego. Achégase información por email.','Serra','','Director Comercial','2012-03-05','ricardserra@seyart.com','Ricard','973533290',NULL,1187,93),
	 ('A interlocutora é Alicia Sánchez','Sánchez','','Rpble. RRHH Vigo e O Porriño','2012-03-06','','Alejandro','',NULL,1009,93),
	 ('','Airas','Cotovad','Rpble. RRHH','2012-03-06','xurxoairas@denso-ts.it','Xurxo','986247222',NULL,493,93),
	 ('Causou baixa por enfermidade fai días, e prevén que esté unhos 3 meses polo que non e posible establecer contacto porque non teñen outro interlocutor que a substitúa.','Fernández','','RRHH','2012-03-07','','Karina','',NULL,25,93),
	 ('','Pastor','de la Cruz','Director Comercial','2013-02-19','rpastor@harinaslapalentina.es','Raúl','','648253275',1207,93),
	 ('','Villanueva','Abilleira','Xerente','2012-03-07','','Eduardo','',NULL,10,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Ruano','','','2013-08-20','jruano@seprotec.com','José Francisco','912048726','',1208,127),
	 ('','Domínguez ¡','Bautista','Presidenta','2012-11-28','','Esperanza','986363061','',484,93),
	 ('','Piñeiro','Cide','Director','2012-12-19','director@lexgalformacion.es','Manuel','881892132','',1212,93),
	 ('Grema - Asociación de Empresarios Autónomos de España','Pardo','Becerra','Secretaria','2012-12-19','secretaria@grema.eu','Cristina','881892732','628765170',1212,93),
	 ('','Rodríguez','','Gerente','2013-01-21','rodriguezpascual@rodriguezpascual.com','José','','607400051',1213,93),
	 ('','Gallego','','Técnica de Selección','2012-02-07','mireia.gallego@gruposoledad.net','Mireia','966919187','',1194,93),
	 ('','Gallego','','Responsable selección','2013-02-12','mireia.gallego@gruposoledad.net','Mireia','','966919817',1194,93),
	 ('','','','','2013-02-19','vigo@eacnur.org','Ismael','','683198632',1214,93),
	 ('','N´Diaye','Salvador','Responsable de Recursos Humanos','2013-02-12','andiaye@timeroad.es','Aissa','','659048653',1209,93),
	 ('Interese nas Axudas municipáis á contratación.','Morales','','Dpto. Contratación','2013-02-12','','Mª Carmen','','648038330',1209,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Aporto información das Bases e convocatoria das Axudas Municipáis á Contratación 2013 pero non as solicita por falta de tempo.','Núñez','Galán','Xerente-Propietario','2013-03-26','donavigo1@hotmail.com','Fabricio','','660337948',1215,93),
	 ('','Vázquez','Muñoz','Responsable Administración de Persoal','2013-03-18','info@icepremium.es','Marta','986092510','',1216,93),
	 ('','Figueirido','','Xerente','2013-04-25','','Angel','','635563201',1218,93),
	 ('','Camarelles','Cabañas','Traballadora Social','2013-04-25','macarena@entuhogar.es','Macarena','965549967','670626923',1219,93),
	 ('','Rodríguez','Santano','','2013-05-09','instalectra@instalectra.org','Carolina','986224903','',74,93),
	 ('','Silva','','Dirección Operaciones','2013-06-05','silva@iform.es','Jorge','656481828','607651484',1220,93),
	 ('','Otero','','Traballadora Social','2013-06-06','soledad@idades.es','Soledad','986854996','',1221,93),
	 ('','de Achaga','Arana','Responsable Zona Norte','2014-02-14','oscar.deachaga@vexia.es','Oscar','','680938526',1222,93),
	 ('Acude ao noso servizo porque segundo a prospección realizada desde a súa empresa as localidades de Vigo e Salamanca son nas lque se produce máis movilidade laboral a outras cidades.','García','Martin','Dtor. RRHH','2013-05-20','david.garcia-martin@cashdiplo.es','David','605850897','682917856',1223,93),
	 ('','Prieto','Alvarez','Propietario','2013-06-13','jesusprieto@tecsel.es','Jesús Manuel','986265354','6777525962',135,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Gándara','Estévez','Gerente','2013-06-17','jgandara@dovalvigo.es','Josue','986192339','627192339',1224,93),
	 ('','López','Vigo','Propietario','2014-05-21','aamlopez@gmail.com','Marcos','986441944','677219508',1225,93),
	 ('O primeiro contacto foi por unha solicitude de axuda á contratación.
En agosto 2013 causou baixa na sociedade e na empresa e pasou a traballar noutra empresa do sector.','Rodríguez','Cordero','Gerente','2009-09-30','','Marco Antonio','986441944','',1225,93),
	 ('Persoa habitual de contacto ao residir en Galicia.','Varela','','Supervisor (Galicia, con sede en Santiago)','2013-12-03','roberto@araburger.es','Roberto','','662624368',1226,93),
	 ('','Cuesta','','Director de Operaciones','2013-12-03','josemiguel@araburger.es','José Miguel','','628128462',1226,93),
	 ('','Mejías','','Director de Proyectos','2014-05-23','rrhh@dinnove.eu','David','931184295','',1227,93),
	 ('Foi quen realizou o primeiro contacto con este concello.','Colomer','','Técnico de Proyectos','2014-05-23','','Javier','931184295','',1227,93),
	 ('','Mera','','Gerente','2013-08-08','telemenu.vigo@gmail.com','Faustino','','622443777',1228,93),
	 ('','','','','2014-03-03','','Iván','','',1229,81),
	 ('','','','','2014-03-03','','Virginia','','',1229,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Jiménez','','Admin. General - RRHH','2013-04-09','j.jimenez@ntdesign.es','Jennifer','932956478','',1217,93),
	 ('','Mauriz','Pereira','Coordinador Comercial','2013-08-05','oscar.mauriz@dezeroconsultores.com','Oscar','981535768','646742382',1230,93),
	 ('','Martínez','','Consultor','2013-08-08','antonio.martinez@hays-response.es','Antonio','914430766','',1231,93),
	 ('','González','','Adxunta Dirección','2014-01-16','silvia.gonzalez@megasistemas.es','Silvia','986233194','',1232,93),
	 ('','Castiñeira','Fernández','Administrador (propietario)','2003-06-30','promagal@mundo-r.com','Oscar','986117744','629414412',282,93),
	 ('Achega oferta de emprego por referencia de Ana de Piñeiro Pedrido Asesores.','Manzano','González','Encargado','2014-06-09','frutasmanzano@hotmail.com','Angel','986492559','652933660',1233,93),
	 ('','Castro','','Socio - Administrador','2014-06-12','javiercastrodolores2@gmail.com','Javier','','670256551',1234,93),
	 ('','Jiménez','','Dpto. Contable-Administrativo','2014-06-12','grupocasago@telefonica.net','Antonia','934264342','',1234,93),
	 ('','','','Traballadora Social','2014-06-24','agonzalez@sociser.org','Ana','','607565030',1235,93),
	 ('','Martínez','','Consultora','2014-07-04','veronica@ncs.es','Verónica','968350200','',1236,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Esposa Fabricio Núñez e traballadora na cafetería.','Ojea','Bermúdez','Propietaria','2013-03-26','donavigo1@hotmail.com','Olivia','986435010','',1215,93),
	 ('','Rial','','Auxiliar administrativa','2014-07-31','administracionc1@gruponexoinfinity.com','Nerea','986115750','',1237,93),
	 ('Achégase ficha de oferta de emprego que devolve cuberta e asinada.','Ramunno','','Gerente','2015-11-13','giovannar@koitub.com','Giovanna','910258801','615280174',1238,93),
	 ('Fago seguimento da oferta de Técnico reparador e comenta que vai a empezar a chamar aos candidatos. Que retrasou a selección porque, ao non ter candidaturas suficientes, consiguiu que o técnico que está agora estivese uns días máis.','Ramunno','','Gerente','2015-11-24','giovannar@koitub.com','Giovanna','910258801','615280174',1238,93),
	 ('Achega oferta de Xestor Comercial para Vigo','González','González','Director Comercial','2016-02-03','impulsaplushispania@gmail.com','Carlos','','629689766',1239,93),
	 ('','Briones','','Administrativo','2016-02-25','administracion@sertranconservacion.com','Fernando','981589816','',1240,93),
	 ('Fago seguimento e confirma a selección da candidata proposta e que estará cun contrato mercantil durante 1 mes e pasará a estar contratada pola empresa a continuación.','González','González','Director Comercial','2016-02-26','impulsaplushispania@gmail.com','Carlos','','629689766',1239,93),
	 ('Achega oferta de emprego','','','Administrativa','2015-11-25','comercial@elaservicios.com','Alejandra','','622227764',1241,93),
	 ('Presentan oferta de emprego e solicitan no informar do nome da súa empresa.','Maneiro','Crespo','Técnica RRHH','2016-03-03','rrhh@grupoboreal.es','Tamara','981679769 - EXT. 452','',303,93),
	 ('Teléfono de contacto en Francia.','Ferrer','','Dpto. RRHH','2016-03-14','virginia.ferrer@billabong.fr','Virginia','0033558700518','',1242,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Díaz','','Selección','2016-03-03','seleccion.samsa@vectalia.es','Gregorio','965269372','',1243,93),
	 ('','Orcajo','','Departamento RRHH','2016-04-28','PRACTICAS@sonaesr.com','Javier','910323841','',1244,93),
	 ('Son unha empresa distribuidora de máquinas de vending que queren volver a ter delegación en Vigo (na rúa Zaragoza) polo que queren presentar unha oferta de emprego dun Técnico en electrónica para Vigo para a instalación e servicio técnico, segundo a súa idade e experiencia pode ser contratado cun contrato de formación ou temporal.
Achégolle email co enlace para a consulta das Axudas municipáis á contratación e mellora do emprego da mocidade viguesa e Anexo V. Oferta de emprego.','Rodríguez','','','2016-05-26','emilio@olevending.es','Emilio','','678654106',1245,93),
	 ('Presentan solicitude de Axuda á contratación e mellora do emprego da mocidade viguesa a nome do Grupo Sémola, SL','','','Asesoría Fisela, SL','2015-09-25','laboral@fisela.es','Idoia','986281045','',1246,93),
	 ('Encargada da selección do posto de dependenta (cara a solicitude de axuda a contratación da mocidade viguesa 2016)','','','Encargada','2016-05-26','semola@semola.es','Estefanía','','626453921',1246,93),
	 ('','Coutado','Portal','Responsable Area Electricidad','2016-05-20','castelaoservicios@gmail.com','Lorenzo','','654167756',1247,93),
	 ('','Moure','','','2016-05-20','castelaoservicios@gmail.com','Beatriz','','625918661',1247,93),
	 ('','Devesa','','Gerente','2016-06-21','sistemas@favensis.com','Camilo','','691775909',1248,93),
	 ('Sigue siendo contacto también Macarena.','Fernando','Carreres','Trabajadora Social','2016-06-28','mutuasad@dependentias.net','Anabel','965549967','',1219,93),
	 ('Participación na entrevista mantida co concelleiro.','De la Cruz','Jaramillo','Responsable de Expansión','2017-03-02','dolores-alejandra.delacruz@leroymerlin.es','Alejandra','','660673085',1249,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('','Molina','','Técnico Dpto. Servicios','2016-06-20','lmolina@alares.es','Luz','912750555','',1250,93),
	 ('','González','','Administración de Personal','2016-07-20','ygonzalez@grupofaro.com','Yolanda','986487828','',1251,93),
	 ('','Cerro','','Consultora de Selección','2016-07-21','ncerro@fuerzacomercial.es','Naiara','','663806776',1252,93),
	 ('','Guisande','Pereira','Técnico de Selección','2016-08-01','seleccion.vigo@ader.net','Lucía','986439571','',117,93),
	 ('','Hermo','','Administrativa','2016-08-09','irenehermo@cliner.com','Irene','981174694','',464,93),
	 ('','Otero','','Traballadora Social','2016-09-19','ts@atendo.es','Patricia','986412341','',203,93),
	 ('Presentan oferta de emprego a través da Asesoría Fisela na intención de solicitar Axuda á contratación da mocidade viguesa 2017.','Pérez','','Administrador','2017-03-20','tecoinre@hotmail.com','Manuel Vicente','','661397038',1253,93),
	 ('Presentan oferta de emprego para optar a Axuda á contratación e mellora do emprego da mocidade viguesa 2016.','Rodríguez','','Responsable RRHH','2016-05-27','emilio@olevending.es','Luis Emilio','902444001','',1184,93),
	 ('','Villar','Fonseca','Titular empresa','2016-06-10','loremeloso@hotmail.com','Lorena','','607804712',1254,93),
	 ('Reciben Axuda á contratación e mellora do emprego da mocidade viguesa 2016.','Rivera','Grela','Gerente / Médica','2016-06-27','helgarivera@gmail.com','Helga','986220920','',1255,93);
INSERT INTO public.empresa_contactos (anotacions,apel1,apel2,cargo,"data",email,nome,tfnofixo,tfnomovil,id_empresa,orientador_id) VALUES
	 ('Se contacta con Lucia por oferta de Soldador','Guisande','','Técnico de Selección','2017-04-03','seleccion.vigo@ader.net','Lucia','986439571','',117,134),
	 ('Chama para facer oferta de emprego para novo centro na rúa Pizarro.','Fernández','','Gerente RRHH','2017-04-28','mpfernan@mercadona.es','Pilar','','669444157',1035,93),
	 ('Realiza oferta de Comercial de alquiler para o seu novo centro de traballo na rúa Urzáiz.','Gándara','Estévez','Gerente','2017-06-06','josuedoval@comprarcasa.com','Josué','','627012918',1224,93),
	 ('Achega oferta de emprego de Técnico Decoración cos requisitos necesarios para solicitar a correspondente Axuda á contratación e mellora do emprego da mocidade viguesa.','Sirvent','','Administrador','2018-01-22','administracion@sirventvigo.com','Nacho','986424422','',1260,93),
	 ('presenta oferta de emprego de Chofer-repartidor coa idea de solicitar a correspondente Axuda Municipal á Contratación 2020','','','Esposa representante (cargo?)','2020-06-12','stupayan@gmail.com','Beatriz','','699974051',1267,93),
	 ('Interese en contactar coa concellaría para incorporación de persoal no novo centro Vigo-Vialia e poder optar a axudas á contratación. Solicita entrevista co concelleiro para a posibilidade de formación con compromiso de contratación.','Magdaleno','','Dtor. RRHH','2021-01-18','j.magdaleno@alcampo.es','J.','986201010','609864444',1268,93);